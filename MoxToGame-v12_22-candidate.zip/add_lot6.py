import json,re
from pathlib import Path
p=Path('/mnt/data/mox/lot6work/src/data/cards-database.js')
s=p.read_text()
entries=[
('Subdue','{1}{W}',2,['W'],'Instant',None,None,None,'common'),
('Sunastian Falconer','{3}{R}{G}',5,['R','G'],'Legendary Creature','Human Shaman',4,4,'uncommon'),
('Sword of the Ages','{6}',6,[],'Artifact',None,None,None,'rare'),
('Sylvan Library','{1}{G}',2,['G'],'Enchantment',None,None,None,'uncommon'),
('Sylvan Paradise','{G}',1,['G'],'Instant',None,None,None,'uncommon'),
('Syphon Soul','{2}{B}',3,['B'],'Sorcery',None,None,None,'common'),
('Takklemaggot','{2}{B}{B}',4,['B'],'Enchantment','Aura',None,None,'uncommon'),
('Telekinesis','{U}{U}',2,['U'],'Instant',None,None,None,'rare'),
('Teleport','{U}{U}{U}',3,['U'],'Instant',None,None,None,'rare'),
('Tempest Efreet','{1}{R}{R}',4,['R'],'Creature','Efreet',3,3,'rare'),
('Tetsuo Umezawa','{U}{B}{R}',3,['U','B','R'],'Legendary Creature','Human Archer',3,3,'rare'),
('The Abyss','{3}{B}',4,['B'],'World Enchantment',None,None,None,'rare'),
('The Brute','{1}{R}',2,['R'],'Enchantment','Aura',None,None,'common'),
('The Lady of the Mountain','{4}{R}{G}',6,['R','G'],'Legendary Creature','Giant',5,5,'common'),
('The Tabernacle at Pendrell Vale','',0,[],'Legendary Land',None,None,None,'rare'),
('The Wretched','{3}{B}{B}',5,['B'],'Creature','Demon',2,5,'uncommon'),
('Thunder Spirit','{1}{W}{W}',3,['W'],'Creature','Spirit',2,2,'uncommon'),
('Time Elemental','{2}{U}',3,['U'],'Creature','Elemental',0,2,'rare'),
('Tobias Andrion','{3}{W}{U}',5,['W','U'],'Legendary Creature','Human Advisor',4,4,'uncommon'),
('Tolaria','',0,[],'Legendary Land',None,None,None,'uncommon'),
('Tor Wauki','{2}{B}{B}{R}',5,['B','R'],'Legendary Creature','Human Archer',3,3,'uncommon'),
('Torsten Von Ursus','{3}{G}{G}{W}',6,['G','W'],'Legendary Creature','Human Soldier',5,5,'uncommon'),
('Touch of Darkness','{B}',1,['B'],'Instant',None,None,None,'uncommon'),
('Transmutation','{1}{B}',2,['B'],'Instant',None,None,None,'common'),
('Triassic Egg','{4}',4,[],'Artifact',None,None,None,'rare'),
('Tuknir Deathlock','{R}{R}{G}{G}',4,['R','G'],'Legendary Creature','Human Wizard',2,2,'uncommon'),
('Tundra Wolves','{W}',1,['W'],'Creature','Wolf',1,1,'common'),
('Typhoon','{2}{G}',3,['G'],'Sorcery',None,None,None,'rare'),
('Undertow','{2}{U}',3,['U'],'Enchantment',None,None,None,'uncommon'),
('Underworld Dreams','{B}{B}{B}',3,['B'],'Enchantment',None,None,None,'uncommon'),
('Unholy Citadel','',0,[],'Land',None,None,None,'uncommon'),
('Untamed Wilds','{2}{G}',3,['G'],'Sorcery',None,None,None,'uncommon'),
('Ur-Drago','{3}{U}{U}{B}{B}',7,['U','B'],'Legendary Creature','Elemental',4,4,'rare'),
('Urborg','',0,[],'Legendary Land',None,None,None,'uncommon'),
('Vaevictis Asmadi','{2}{B}{B}{R}{R}{G}{G}',8,['B','R','G'],'Legendary Creature','Elder Dragon',7,7,'rare'),
('Vampire Bats','{B}',1,['B'],'Creature','Bat',1,1,'common'),
('Venarian Gold','{X}{U}{U}',2,['U'],'Enchantment','Aura',None,None,'common'),
('Visions','{U}',1,['U'],'Sorcery',None,None,None,'uncommon'),
('Voodoo Doll','{6}',6,[],'Artifact',None,None,None,'rare'),
('Walking Dead','{1}{B}',2,['B'],'Creature','Zombie',1,1,'common'),
('Wall of Caltrops','{1}{W}',2,['W'],'Creature','Wall',2,1,'common'),
# Wall of Dust already exists: merged below.
('Wall of Earth','{1}{R}',2,['R'],'Creature','Wall',0,6,'common'),
('Wall of Heat','{2}{R}',3,['R'],'Creature','Wall',2,6,'common'),
('Wall of Light','{2}{W}',3,['W'],'Creature','Wall',1,5,'uncommon'),
('Wall of Opposition','{3}{R}{R}',5,['R'],'Creature','Wall',0,6,'uncommon'),
('Wall of Putrid Flesh','{2}{B}',3,['B'],'Creature','Wall',2,4,'uncommon'),
('Wall of Shadows','{1}{B}{B}',3,['B'],'Creature','Wall',0,1,'common'),
('Wall of Tombstones','{1}{B}',2,['B'],'Creature','Wall',0,0,'uncommon'),
('Wall of Vapor','{3}{U}',4,['U'],'Creature','Wall',0,4,'common'),
('Wall of Wonder','{2}{U}{U}',4,['U'],'Creature','Wall',1,5,'rare'),
]
# Fix expected current count and merge Wall of Dust.
# All additions get placeholder effect status, preserving exact metadata only.
maxid=max(map(int,re.findall(r'"id":\s*(\d+)',s)))
assert maxid==897, maxid
# merge Wall of Dust sets
pat=r'("name":\s*"Wall of Dust"[\s\S]*?"sets":\s*\[\s*)"LEB"(\s*\])'
m=re.search(pat,s)
assert m, 'Wall of Dust not found'
s=s[:m.start()]+m.group(0).replace('"LEB"','"LEB",\n      "LEG"',1)+s[m.end():]
# remove duplicate LEG if any
new=[]
nextid=maxid+1
for name,cost,cmc,colors,typ,sub,pow_,tough,rar in entries:
    obj={"name":name,"cost":cost,"cmc":cmc,"color":colors,"type":typ,"rarity":rar,"text_fr":"Carte de l'édition LEG. Effet à implémenter.","id":nextid,"sets":["LEG"],"keywords":[],"triggers":[],"isLand":typ.endswith('Land'),"isCreature":'Creature' in typ,"isPermanent":('Creature' in typ or typ.endswith('Land') or 'Enchantment' in typ or typ=='Artifact' or typ=='Artifact Creature'),"__c88Applied":True,"effectStatus":"unimplemented"}
    if sub: obj['subtype']=sub
    if pow_ is not None: obj['power']=pow_; obj['toughness']=tough
    new.append(obj); nextid+=1
# insert before closing ];
block='\n'+',\n'.join(json.dumps(o,ensure_ascii=False,indent=2) for o in new)+'\n'
s=s.replace('\n];\n\nexport default CARDS.map(normalizeCard);',',\n'+block+'\n];\n\nexport default CARDS.map(normalizeCard);')
p.write_text(s)
print('added',len(new),'new, final raw ids',nextid-1)
