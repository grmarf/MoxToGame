import assert from 'assert';
import { CombatService } from '../src/core/combat.js';
import { StateBasedActions } from '../src/core/state-based-actions.js';

function makeState() {
  return {
    player: {
      battlefield: [], graveyard: [], hand: [], library: [], exile: [],
      life: 20, mana: {W:0,U:0,B:0,R:0,G:0,C:0},
    },
    ai: {
      battlefield: [], graveyard: [], hand: [], library: [], exile: [],
      life: 20, mana: {W:0,U:0,B:0,R:0,G:0,C:0},
    },
    activePlayer: 'ai',
    phase: 'combatBegin',
    priorityHolder: 'ai',
    turnNumber: 1,
  };
}

const sba = new StateBasedActions({ zones: null });

// --- R-TEST-01b-1 : mustBeBlocked nécessite un bloqueur obligatoire ---
// SCÉNARIO A : un SEUL bloqueur normal (pas mustBlock) sur le champ de bataille.
// Avec l'ancien stub #isMandatoryBlocker(b){ return !!b; }, ce bloqueur serait
// accepté par #canBlock et le blocage passerait silencieusement.
// Avec la vraie implémentation, #canBlock rejette normalBlocker car il n'a pas
// mustBlock → "Blocage illégal par Soldier".
{
  const state = makeState();
  const combat = new CombatService({ state: () => state, sba });
  const mustBeBlocked = {
    name: 'Giant', type: 'Creature', power: 5, toughness: 5, uid: 'g1',
    mustBeBlocked: true, summoningSickness: false, tapped: false,
    cantAttack: false, attacksDisabled: false, controller: 'ai'
  };
  const normalBlocker = {
    name: 'Soldier', type: 'Creature', power: 1, toughness: 1, uid: 's1',
    keywords: [], summoningSickness: false, tapped: false,
    cantBlock: false, cantBlockThisTurn: false, controller: 'player'
  };

  state.ai.battlefield.push(mustBeBlocked);
  state.player.battlefield.push(normalBlocker);

  combat.begin();
  combat.confirmAttackers([mustBeBlocked], 'ai');

  let threw = false;
  let errorMessage = '';
  try { combat.assignBlockers({ g1: ['s1'] }); } catch (e) { threw = true; errorMessage = e.message; }
  assert.ok(threw, 'normalBlocker sans mustBlock ne doit pas pouvoir bloquer mustBeBlocked');
  assert.ok(
    errorMessage.includes('Blocage illégal') || errorMessage.includes('mustBlock') || errorMessage.includes('obligatoire'),
    `Message d'erreur doit indiquer un blocage illégal, reçu : "${errorMessage}"`
  );
}

// SCÉNARIO B : un SEUL bloqueur avec mustBlock sur le champ de bataille.
// Ce bloqueur doit être accepté.
{
  const state = makeState();
  const combat = new CombatService({ state: () => state, sba });
  const mustBeBlocked = {
    name: 'Giant', type: 'Creature', power: 5, toughness: 5, uid: 'g1',
    mustBeBlocked: true, summoningSickness: false, tapped: false,
    cantAttack: false, attacksDisabled: false, controller: 'ai'
  };
  const mandatoryBlocker = {
    name: 'Defender', type: 'Creature', power: 2, toughness: 4, uid: 'd1',
    keywords: ['mustBlock'], summoningSickness: false, tapped: false,
    cantBlock: false, cantBlockThisTurn: false, controller: 'player'
  };

  state.ai.battlefield.push(mustBeBlocked);
  state.player.battlefield.push(mandatoryBlocker);

  combat.begin();
  combat.confirmAttackers([mustBeBlocked], 'ai');
  combat.assignBlockers({ g1: ['d1'] });
  assert.strictEqual(combat.currentPhase, 'combatDamage', 'mustBlock doit pouvoir bloquer mustBeBlocked');
}

// --- R-TEST-01b-2 : protection multiple couleurs ---
{
  const state = makeState();
  const combat = new CombatService({ state: () => state, sba });
  const protectedCreature = {
    name: 'Paladin', type: 'Creature', power: 2, toughness: 3, uid: 'p1',
    keywords: ['protectionW', 'protectionU'],
    summoningSickness: false, tapped: false,
    cantBlock: false, cantBlockThisTurn: false, controller: 'player'
  };
  const whiteAttacker = {
    name: 'Cleric', type: 'Creature', power: 2, toughness: 2, uid: 'c1',
    color: ['W'], keywords: [],
    summoningSickness: false, tapped: false,
    cantAttack: false, attacksDisabled: false, controller: 'ai'
  };
  const blueAttacker = {
    name: 'Merfolk', type: 'Creature', power: 2, toughness: 2, uid: 'm1',
    color: ['U'], keywords: [],
    summoningSickness: false, tapped: false,
    cantAttack: false, attacksDisabled: false, controller: 'ai'
  };
  const redAttacker = {
    name: 'Goblin', type: 'Creature', power: 2, toughness: 2, uid: 'g2',
    color: ['R'], keywords: [],
    summoningSickness: false, tapped: false,
    cantAttack: false, attacksDisabled: false, controller: 'ai'
  };

  state.player.battlefield.push(protectedCreature);
  state.ai.battlefield.push(whiteAttacker, blueAttacker, redAttacker);

  combat.begin();
  combat.confirmAttackers([whiteAttacker], 'ai');
  let threw = false;
  try { combat.assignBlockers({ c1: ['p1'] }); } catch (e) { threw = true; }
  assert.ok(threw, 'protectionW doit empêcher de bloquer une source blanche');

  combat.begin();
  combat.confirmAttackers([blueAttacker], 'ai');
  threw = false;
  try { combat.assignBlockers({ m1: ['p1'] }); } catch (e) { threw = true; }
  assert.ok(threw, 'protectionU doit empêcher de bloquer une source bleue');

  combat.begin();
  combat.confirmAttackers([redAttacker], 'ai');
  combat.assignBlockers({ g2: ['p1'] });
  assert.strictEqual(combat.currentPhase, 'combatDamage', 'Sans protection rouge, le blocage doit être autorisé');
}

console.log('OK: R-TEST-01b — mustBeBlocked/isMandatoryBlocker + protection multiple couleurs.');
