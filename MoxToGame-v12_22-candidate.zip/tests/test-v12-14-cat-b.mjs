import assert from 'assert';
import CARDS from '../src/data/cards-database.js';
import { createPermanent } from '../src/core/card-runtime.js';
import { effects } from '../src/core/effect-registry.js';
import { installEffects } from '../src/core/effects/index.js';

installEffects(effects, globalThis);

function findCard(name) { return CARDS.find(c => c.name === name); }
function makePerm(name, ctrl) {
  const c = findCard(name);
  assert.ok(c, `${name} existe`);
  const p = createPermanent(c);
  p.controller = ctrl; p.owner = ctrl; return p;
}

// B28: Argothian Pixies a flying
assert.ok(makePerm('Argothian Pixies', 'player').keywords.includes('flying'), 'B28: Argothian Pixies flying');

// B29: Bog Rats a swampwalk
assert.ok(makePerm('Bog Rats', 'player').keywords.includes('swampwalk'), 'B29: Bog Rats swampwalk');

// B30: Carnivorous Plant a forestwalk
assert.ok(makePerm('Carnivorous Plant', 'player').keywords.includes('forestwalk'), 'B30: Carnivorous Plant forestwalk');

// B31: Desert Nomads a mountainwalk + protectionU
const dn = makePerm('Desert Nomads', 'player');
assert.ok(dn.keywords.includes('mountainwalk'), 'B31a: Desert Nomads mountainwalk');
assert.ok(dn.keywords.includes('protectionU'), 'B31b: Desert Nomads protectionU');

// B32: Land Leeches a forestwalk
assert.ok(makePerm('Land Leeches', 'player').keywords.includes('forestwalk'), 'B32: Land Leeches forestwalk');

// B33: Mesa Pegasus a flying (banding retiré)
const mp = makePerm('Mesa Pegasus', 'player');
assert.ok(mp.keywords.includes('flying'), 'B33a: Mesa Pegasus flying');
assert.ok(!mp.keywords.includes('banding'), 'B33b: Mesa Pegasus pas banding');

// B34: Moor Fiend a swampwalk
assert.ok(makePerm('Moor Fiend', 'player').keywords.includes('swampwalk'), 'B34: Moor Fiend swampwalk');

// B35: Raging Goblin a haste
assert.ok(makePerm('Raging Goblin', 'player').keywords.includes('haste'), 'B35: Raging Goblin haste');

console.log('OK: Catégorie B — 35 cartes (27+8) vérifiées.');
