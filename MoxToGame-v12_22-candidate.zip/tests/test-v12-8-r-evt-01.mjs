import assert from 'assert';
import { gameEvents } from '../src/core/event-bus.js';
import { installC7EventRules } from '../src/core/effects/complex-effects.js';

// Réinitialiser le provider pour ce test
gameEvents.stateProvider = null;

const mockState = {
  player: {
    battlefield: [{ name: 'Swamp', subtype: 'Swamp', type: 'Land' }],
    life: 20, graveyard: [], library: [], hand: [],
    mana: {W:0,U:0,B:0,R:0,G:0,C:0}
  },
  ai: {
    battlefield: [{ name: 'Karma', static: { type: 'blackViseLands' } }],
    life: 20, graveyard: [], library: [], hand: [],
    mana: {W:0,U:0,B:0,R:0,G:0,C:0}
  },
};

gameEvents.setStateProvider(() => mockState);
installC7EventRules();

// Émettre un upkeepStarted SANS state (comme le fait TurnManager en v12.8.0)
gameEvents.emit({ type: 'upkeepStarted', side: 'player', activePlayer: 'player' });

assert.strictEqual(mockState.player.life, 19, 'blackViseLands doit infliger 1 dégât par swamp via upkeepStarted');
console.log('OK: R-EVT-01 — state injecté automatiquement, blackViseLands s\'exécute.');
