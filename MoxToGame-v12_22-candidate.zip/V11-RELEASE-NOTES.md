# MoxToGame V11.1

Cette version part de la V11.0 (jouable de bout en bout, joueur vs IA) et
livre la **Phase 1** du plan de travail : solidifier ce qui existe déjà
avant de s'attaquer à l'IA réactive (Phase 2). Voir
`V11.0-RELEASE-NOTES.md` pour le détail de la version précédente.

## Comment lancer le jeu

Inchangé depuis v11.0 :

```bash
npm start
# ou
python3 -m http.server 8000
```

Puis ouvrir **http://localhost:8000**.

## Ce qui a été ajouté / corrigé par rapport à v11.0

1. **Détection de fin de partie.** Le moteur calculait déjà
   `state.player.hasLost` / `state.ai.hasLost` (vie ≤ 0, pioche dans une
   bibliothèque vide, poison ≥ 10...) mais rien ne s'en servait : l'IA
   aurait continué à jouer indéfiniment contre un joueur déjà mort. →
   - `ai-controller.js` vérifie `isGameOver()` avant chaque action et
     n'en programme plus aucune une fois la partie terminée ;
   - `game-ui.js` affiche un écran "Victoire !"/"Défaite..." (réutilise
     les classes `.modal`/`.modal-content` déjà présentes dans
     `styles.css`) avec un bouton pour relancer une partie, et bloque
     toute interaction (`dispatch()` refuse silencieusement une fois la
     partie finie).

2. **Mulligan.** Absent en v11.0 : les deux joueurs recevaient une main
   de 7 cartes fixe, sans possibilité de la relancer. → règle de Londres
   simplifiée :
   - le joueur humain voit sa main de départ, peut la garder ou faire un
     mulligan (nouvelle main de 7, compteur incrémenté) ;
   - s'il garde une main après *n* mulligans, il doit sélectionner *n*
     cartes à renvoyer au fond de sa bibliothèque avant que la partie ne
     démarre réellement (nouvel écran `#mulligan-screen`, même logique
     d'interaction clic-pour-sélectionner que le panneau de combat) ;
   - l'IA gère son propre mulligan seule, sans UI : elle relance si sa
     main contient moins de 2 ou plus de 5 terrains (jusqu'à 2 fois), puis
     renvoie au fond les cartes les plus chères (CMC le plus élevé).

3. **Ciblage des sorts par l'IA.** En v11.0, un sort qui exigeait une
   cible était simplement abandonné par l'IA (`target: null` →
   "Une cible est requise." → sort perdu). → nouvelle fonction
   `pickAiTarget()` (exportée depuis `ai-controller.js`) :
   - effets de retrait (`damage`, `destroy`, `exile`, `bounce`,
     `tapTarget`, `discard`) et `anyTarget` → vise la créature adverse la
     plus puissante, ou à défaut le joueur adverse ;
   - effets de soutien (`pump`, `copyPermanent`) → vise sa propre
     meilleure créature ;
   - contre-sorts (`counterSpell` et variantes) → vise en priorité un
     objet du joueur humain sur la pile ;
   - sinon, comportement inchangé (première cible valide).

## Vérifications effectuées

Trois nouveaux scripts de test headless dans `tests/` (les deux de v11.0
sont conservés) :

- `tests/test-game-over.mjs` — force la défaite du joueur et vérifie que
  l'IA ne dispatch plus aucune action ensuite.
- `tests/test-ai-targeting.mjs` — vérifie que `pickAiTarget()` (le vrai
  code utilisé en jeu, pas une copie) cible bien la créature adverse la
  plus forte face à un effet de destruction.
- `tests/test-mulligan.mjs` — avec un DOM minimal factice (pas besoin de
  navigateur), vérifie qu'un mulligan repioche bien 7 cartes et que la
  confirmation renvoie le bon nombre de cartes au fond de la
  bibliothèque.

```bash
node tests/test-ai-loop.mjs
node tests/test-combat-damage.mjs
node tests/test-game-over.mjs
node tests/test-ai-targeting.mjs
node tests/test-mulligan.mjs
```

Tous passent (`OK : ...`) sur cette version.

## Limites toujours assumées (Phases 2 et 3 du plan de travail)

- **IA non réactive en instant-speed pendant le tour du joueur humain**
  (elle n'agit qu'à son propre tour + pour bloquer). C'est la Phase 2 du
  plan de travail (priorité bidirectionnelle via `PriorityController`).
- **`AIService#canCast` ne vérifie que le total de mana, pas les
  couleurs requises** — peut faire échouer un cast qui semblait viable.
  `tapAllLandsForMana()` masque partiellement le problème en tapant tout
  le mana disponible, mais une vraie vérification des couleurs reste à
  faire (Phase 2/3).
- **Couverture des règles** : voir `C9-FINAL-AUDIT.md` (conservé dans ce
  zip) — Shahrazad, effets de remplacement multiples, copies imbriquées,
  etc. restent structurellement routés mais non validés exhaustivement
  en jeu réel (Phase 3).
- **Deckbuilder minimal, pas de sauvegarde de partie exposée dans l'UI**
  (le moteur a déjà `saveSnapshot()`/`loadSnapshot()`, jamais branchés à
  un bouton) — Phase 4.
