// V10.7 / C9.1 — isolated subgame manager for Shahrazad.
// The main game is suspended while the subgame runs; subgame objects have no
// rules meaning in the main game except for the final result.
import { serializeState, deserializeState } from './serialization.js';
import { gameEvents } from './event-bus.js';
import { rngClock } from './rng-clock-service.js';

export class SubgameManager {
  constructor({ getState, setState }) {
    this.getState = getState;
    this.setState = setState;
    this.mainSnapshot = null;
    this.depth = 0;
  }

  get active() { return !!this.mainSnapshot; }

  start({ controller = 'player' } = {}) {
    if (this.active) throw new Error('A subgame is already active.');
    const main = serializeState(this.getState());
    this.mainSnapshot = main;
    this.depth = 1;
    const sub = this.#createSubgameState(main);
    this.setState(sub);
    gameEvents.emit({ type: 'subgameStarted', state: sub, depth: this.depth, controller });
    return sub;
  }

  // Ends the current subgame. winner is the side that won the subgame.
  finish(winner) {
    if (!this.active) throw new Error('No active subgame.');
    const main = deserializeState(this.mainSnapshot);
    const loser = winner === 'player' ? 'ai' : 'player';
    // Shahrazad's current Oracle wording/rules make the loser of the subgame
    // lose half their life, rounded up.
    main[loser].life = Math.ceil(main[loser].life / 2);
    main.subgameResult = { winner, loser };
    this.mainSnapshot = null;
    this.depth = 0;
    this.setState(main);
    gameEvents.emit({ type: 'subgameFinished', state: main, winner, loser });
    return main;
  }

  #createSubgameState(main) {
    const sub = deserializeState(main);
    for (const side of ['player', 'ai']) {
      // Rule 724.2: only libraries move into the subgame; other main-game
      // zones remain outside it. The new game gets fresh zones/state.
      const deck = (main[side].library || []).map(c => ({ ...c }));
      sub[side] = {
        life: 20,
        library: deck,
        hand: [],
        graveyard: [],
        exile: [],
        battlefield: [],
        mana: { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 },
        mustDraw: false,
        extraTurns: 0,
        landsPlayedThisTurn: 0,
        hasDrawnThisTurn: false,
        hasLost: false,
      };
    }
    sub.turnNumber = 1;
    sub.activePlayer = rngClock.random() < 0.5 ? 'player' : 'ai';
    sub.phase = 'untap';
    sub.priorityHolder = sub.activePlayer;
    sub.stack = [];
    sub.combat = null;
    sub.subgame = { active: true, depth: 1 };
    return sub;
  }
}
