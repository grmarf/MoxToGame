// @ts-check
/** M2 — Combat engine: legal attackers/blockers, evasion, first/double strike, trample and damage. */
import { gameEvents } from './event-bus.js';
import { keywordsOf, hasKeyword } from './keywords.js';
import { applyContinuousEffects, effectiveKeywords, calculateCharacteristics } from './continuous-effects.js';
export const CombatPhase = Object.freeze({ BEGIN_COMBAT:'beginCombat', DECLARE_ATTACKERS:'declareAttackers', DECLARE_BLOCKERS:'declareBlockers', COMBAT_DAMAGE:'combatDamage', END_COMBAT:'endCombat' });

export class CombatService {
  constructor({ state, sba = null, replacements = null }) { this.getState = state; this.sba = sba; this.replacements = replacements; this.combat = null; }
  get isActive(){ return !!this.combat; }
  get currentPhase(){ return this.combat?.phase ?? null; }
  begin(){ this.combat={phase:CombatPhase.BEGIN_COMBAT, attackers:[], blockers:{}, attackingSide:null, defendingSide:null, damageStep:0, combatDamageAssigned:false}; return this.combat; }

  toDeclareAttackers(attackers=[], side=null){
    if(!this.combat) this.begin();
    const state=this.getState(); const attackingSide=side || state.activePlayer;
    if(state.activePlayer!==attackingSide) throw new Error('Seul le joueur actif peut déclarer les attaquants.');
    this.combat.phase=CombatPhase.DECLARE_ATTACKERS; this.combat.attackingSide=attackingSide; this.combat.defendingSide=attackingSide==='player'?'ai':'player';
    const legal=attackers.filter(a=>this.#canAttack(a,attackingSide)); const required=this.getState()[attackingSide].battlefield.filter(a=>this.#canAttack(a,attackingSide)&&a.mustAttack); if(required.some(r=>!legal.some(a=>a.uid===r.uid))) throw new Error('Une créature qui doit attaquer n’a pas été déclarée.'); this.combat.attackers=legal;
    return this.combat;
  }
  confirmAttackers(attackers, side=null){
    this.toDeclareAttackers(attackers,side);
    for(const a of this.combat.attackers){ if(!this.#hasKeyword(a,'vigilance')) a.tapped=true; }
    this.combat.phase=CombatPhase.DECLARE_BLOCKERS;
    gameEvents.emit({type:'attackersDeclared',attackers:this.combat.attackers,attackingSide:this.combat.attackingSide});
    return this.combat;
  }
  assignBlockers(blockerMap){
    if(!this.combat || this.combat.phase!==CombatPhase.DECLARE_BLOCKERS) throw new Error('Déclaration des bloqueurs invalide.');
    const state=this.getState(), defending=this.combat.defendingSide; const used=new Set(); this.combat.blockers={};
    for(const [attackerUid, blockerUids] of Object.entries(blockerMap||{})){
      const attacker=this.combat.attackers.find(a=>a.uid===attackerUid); if(!attacker) continue;
      const blockers=(blockerUids||[]).map(uid=>this.#findBlocker(uid,defending)).filter(Boolean);
      if(this.#hasKeyword(attacker,'menace') && blockers.length===1) throw new Error('Une créature avec menace doit être bloquée par au moins deux créatures.');
      for(const b of blockers){ if(used.has(b.uid)) throw new Error('Une créature ne peut bloquer qu’un seul attaquant.'); used.add(b.uid); if(!this.#canBlock(b,attacker,defending)) throw new Error(`Blocage illégal par ${b.name}.`); }
      if(attacker.mustBeBlocked){
        const candidates=this.getState()[defending].battlefield.filter(b=>this.#canBlock(b,attacker,defending));
        if(candidates.some(b=>!blockers.some(x=>x.uid===b.uid))) throw new Error(`${attacker.name} doit être bloquée par toutes les créatures qui peuvent la bloquer.`);
      }
      this.combat.blockers[attackerUid]=blockers;
    }
    this.combat.phase=CombatPhase.COMBAT_DAMAGE; this.combat.damageStep=0; gameEvents.emit({type:'blockersDeclared',blockers:this.combat.blockers}); return this.combat;
  }
  confirmBlockers(map){ if(map) this.assignBlockers(map); if(!this.combat) return null; this.combat.phase=CombatPhase.COMBAT_DAMAGE; return this.combat; }

  resolveDamage(){
    if(!this.combat || this.combat.phase!==CombatPhase.COMBAT_DAMAGE) throw new Error('Les blessures ne peuvent être résolues hors de la phase de blessures.');
    const all=[]; const first=this.#resolveDamageStep(true); all.push(...first);
    if(this.sba) this.sba.check(this.getState());
    all.push(...this.#resolveDamageStep(false));
    if(this.sba) this.sba.check(this.getState());
    for (const event of all) gameEvents.emit(event); this.combat.combatDamageAssigned=true; this.combat.damageStep=2; return all;
  }
  end(){ const s=this.combat?{...this.combat}:null; this.combat=null; return s; }
  getValidAttackers(side){ return this.getState()[side].battlefield.filter(p=>this.#canAttack(p,side)); }
  getValidBlockers(side){ return this.getState()[side].battlefield.filter(p=>this.#canBlock(p,null,side)); }

  #resolveDamageStep(firstStrike){
    const events=[]; const state=this.getState();
    if(firstStrike) for(const a of this.combat.attackers) a._firstStrikeDealt=false;
    for(const attacker of [...this.combat.attackers]){
      if(!this.getState()[this.combat.attackingSide].battlefield.some(p => p.uid === attacker.uid)) continue;
      if(!this.#hasDamageAbility(attacker,firstStrike)) continue;
      const blockers=this.combat.blockers[attacker.uid]||[]; const atk=this.#effectivePT(attacker).power;
      if(blockers.length===0){ if(atk>0){ const r=this.#prevent(atk, this.combat.defendingSide, attacker, {targetType:'player',targetController:this.combat.defendingSide,combat:true}); if(r.remaining>0){ if(this.replacements?.applyDamageToPlayer) this.replacements.applyDamageToPlayer(this.combat.defendingSide,r.remaining,{color:attacker?.color?.[0]||null,source:attacker,meta:{combat:true}}); else { const life=this.replacements?.replaceDamageLifeLoss?this.replacements.replaceDamageLifeLoss(this.combat.defendingSide,r.remaining,{source:attacker,combat:true}):{loss:r.remaining}; state[this.combat.defendingSide].life-=life.loss; } } if(r.prevented>0) events.push({type:'combatDamagePrevented',source:attacker,target:this.combat.defendingSide,amount:r.prevented,damageKind:'combat'}); if(r.remaining>0) events.push({type:'combatDamageToPlayer',source:attacker,sourceId:attacker.uid,target:this.combat.defendingSide,amount:r.remaining,damageKind:'combat'}); } continue; }
      let remaining=Math.max(0,atk); const ordered=blockers.slice();
      for(const blocker of ordered){ if(remaining<=0) break; const lethal=Math.max(0,this.#effectivePT(blocker).toughness-(blocker.damageMarked||0)); const assigned=Math.min(remaining,lethal); const r=this.#prevent(assigned, this.combat.defendingSide, attacker, {targetType:'permanent',targetController:this.combat.defendingSide,combat:true,target:blocker}); blocker.damageMarked=(blocker.damageMarked||0)+r.remaining; remaining-=assigned; if(r.prevented>0) events.push({type:'combatDamagePrevented',source:attacker,target:blocker,amount:r.prevented,damageKind:'combat'}); if(r.remaining) events.push({type:'combatDamageToCreature',source:attacker,sourceId:attacker.uid,target:blocker,targetId:blocker.uid,amount:r.remaining,damageKind:'combat'}); }
      if(remaining>0 && this.#hasKeyword(attacker,'trample')){ const r=this.#prevent(remaining,this.combat.defendingSide,attacker,{targetType:'player',targetController:this.combat.defendingSide,combat:true}); if(r.remaining){ if(this.replacements?.applyDamageToPlayer) this.replacements.applyDamageToPlayer(this.combat.defendingSide,r.remaining,{color:attacker?.color?.[0]||null,source:attacker,meta:{combat:true}}); else { const life=this.replacements?.replaceDamageLifeLoss?this.replacements.replaceDamageLifeLoss(this.combat.defendingSide,r.remaining,{source:attacker,combat:true}):{loss:r.remaining}; state[this.combat.defendingSide].life-=life.loss; } } if(r.prevented) events.push({type:'combatDamagePrevented',source:attacker,target:this.combat.defendingSide,amount:r.prevented,damageKind:'combat'}); if(r.remaining) events.push({type:'combatDamageToPlayer',source:attacker,sourceId:attacker.uid,target:this.combat.defendingSide,amount:r.remaining,damageKind:'combat',excess:true}); }
    }
    if(firstStrike) for(const a of this.combat.attackers){ const kw=this.#keywords(a); if((kw.includes('first strike')||kw.includes('firststrike')||kw.includes('double strike')||kw.includes('doublestrike')) && this.getState()[this.combat.attackingSide].battlefield.some(p=>p.uid===a.uid)) a._firstStrikeDealt=true; }
    // Blockers deal damage to attackers during the same damage step when applicable.
    for(const attacker of [...this.combat.attackers]){
      for(const blocker of this.combat.blockers[attacker.uid]||[]){ if(!this.getState()[this.combat.defendingSide].battlefield.some(p => p.uid === blocker.uid)) continue; if(!this.#hasDamageAbility(blocker,firstStrike)) continue; const p=this.#effectivePT(blocker).power; if(p>0){ const r=this.#prevent(p,this.combat.attackingSide,blocker,{targetType:'permanent',targetController:this.combat.attackingSide,combat:true,target:attacker}); attacker.damageMarked=(attacker.damageMarked||0)+r.remaining; if(r.prevented) events.push({type:'combatDamagePrevented',source:blocker,target:attacker,amount:r.prevented,damageKind:'combat'}); if(r.remaining) events.push({type:'combatDamageToCreature',source:blocker,sourceId:blocker.uid,target:attacker,targetId:attacker.uid,amount:r.remaining,damageKind:'combat'}); } }
    }
    return events;
  }
  #prevent(amount, side, source, meta){ return this.replacements?.preventDamage(side, amount, source?.color?.[0] || null, source, meta) || {prevented:0,remaining:amount}; }
  #hasDamageAbility(p,first){ const kw=this.#keywords(p); const firstKw=kw.includes('first strike')||kw.includes('firststrike'); const doubleKw=kw.includes('double strike')||kw.includes('doublestrike'); if(first) return firstKw||doubleKw; return !firstKw && (!p._firstStrikeDealt || doubleKw); }
  #canAttack(p,side){ if(!p||!this.getState()[side].battlefield.includes(p)) return false; const c=calculateCharacteristics(this.getState(),p); const kw=c.keywords; return /Creature/.test(String(c.type||''))&&!p.tapped&&!p.summoningSickness&&!p.cantAttack&&!p.attacksDisabled&&!kw.includes('defender')&&(!p.mustAttack || true); }
  #canBlock(b,a,side){ if(!b||!this.getState()[side].battlefield.includes(b)) return false; if(!/Creature/.test(String(b.type||''))||b.tapped||b.cantBlock||b.cantBlockThisTurn) return false; if(a){ const ak=this.#keywords(a), bk=this.#keywords(b); const ac=this.#effectivePT(a); if(a.mustBeBlocked && !this.#isMandatoryBlocker(b)) return false; if(ak.includes('flying')&&!bk.includes('flying')&&!bk.includes('reach')) return false; if(ak.includes('unblockable')) return false; if(ac.power<=1 && this.#hasStaticUnblockableIfLowPower(a)) return false; if(ak.includes('fear') && !this.#isArtifactOrBlack(b)) return false; if(ak.includes('intimidate') && !this.#isArtifactOrColored(b)) return false; if(ak.includes('swampwalk') && this.#hasBasicLandType(this.combat.defendingSide,'Swamp')) return false; if(ak.includes('islandwalk') && this.#hasBasicLandType(this.combat.defendingSide,'Island')) return false; if(ak.includes('mountainwalk') && this.#hasBasicLandType(this.combat.defendingSide,'Mountain')) return false; if(ak.includes('forestwalk') && this.#hasBasicLandType(this.combat.defendingSide,'Forest')) return false; if(ak.includes('plainswalk') && this.#hasBasicLandType(this.combat.defendingSide,'Plains')) return false; const colors=a.color||[]; if(this.#hasProtection(b,colors)) return false; } return true; }
  #findBlocker(uid,side){ return this.getState()[side].battlefield.find(p=>p.uid===uid)||null; }
  #keywords(p){ return effectiveKeywords(this.getState(), p); }
  #hasKeyword(p,k){ return hasKeyword(p,k); }
  #isArtifactOrBlack(p){ return String(p.type||'').includes('Artifact') || (p.color||[]).includes('B'); }
  #isArtifactOrColored(p){ return String(p.type||'').includes('Artifact') || (p.color||[]).length>0; }
  #hasStaticUnblockableIfLowPower(a){ const all=[...(this.getState().player.battlefield||[]),...(this.getState().ai.battlefield||[])]; return all.some(s=>s.static?.some(e=>e.type==='unblockableIfPowerAtMost' && this.#sourceAppliesTo(a,s,e))); }
  #sourceAppliesTo(target,source,e){ return (e.controller==='all'||e.controllerFilter==='any') && target && source; }
  #isMandatoryBlocker(b){ return !!(b && (b.keywords?.includes('mustBlock') || b.mustBlock || b.mustBlockThisTurn)); }
  #hasBasicLandType(side, subtype){ return this.getState()[side].battlefield.some(p => String(p.type||'').includes('Land') && String(p.subtype||'').split(/\s+/).includes(subtype)); }
  #hasProtection(p,colors){ const kw=this.#keywords(p); return colors.some(c=>kw.includes(`protection${c}`.toLowerCase())||kw.includes(`protection ${c}`.toLowerCase())); }
  #effectivePT(p){ const state=this.getState(); const c=applyContinuousEffects(state,p); return {power:c.power,toughness:c.toughness}; }
}
