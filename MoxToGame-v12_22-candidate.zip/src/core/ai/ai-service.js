// @ts-check
/**
 * @fileoverview MTG Beta V8.13 — Minimal Native AI
 * Testable AI service with simple heuristics for land drops,
 * spell casting, combat, and priority passing.
 */

/** @typedef {import('../types.js').GameState} GameState */
/** @typedef {import('../types.js').Card} Card */
/** @typedef {import('../types.js').Permanent} Permanent */

import { gameEvents } from '../event-bus.js';
import { effectivePowerToughness } from '../continuous-effects.js';

export class AIService {
  /**
   * @param {Object} deps
   * @param {() => GameState} deps.state
   * @param {import('../turn/turn-manager.js').TurnManager} deps.turnManager
   * @param {import('../combat.js').CombatService} deps.combat
   * @param {import('../stack.js').StackController} deps.stack
   * @param {import('../effect-registry.js').EffectRegistry} deps.effects
   * @param {string} [deps.side] — 'ai' or 'player' (for testing both sides)
   */
  constructor({ state, turnManager, combat, stack, effects, costs = null, side = 'ai' }) {
    this.getState = state;
    this.turnManager = turnManager;
    this.combat = combat;
    this.stack = stack;
    this.effects = effects;
    this.costs = costs;
    this.side = side;
    this.opponent = side === 'ai' ? 'player' : 'ai';
  }

  // ─────────────────────────────────────────────
  // Main Decision Loop
  // ─────────────────────────────────────────────

  /**
   * Choose the best action for the current phase.
   * @returns {{action: string, data: Object}|null}
   */
  chooseAction() {
    const state = this.getState();
    const phase = this.turnManager.phase;
    const myState = state[this.side];

    switch (phase) {
      case 'main1':
      case 'main2':
        return this.#chooseMainPhaseAction(myState);
      case 'declareAttackers':
        return this.#chooseAttackers();
      case 'declareBlockers':
        return this.#chooseBlockers();
      default:
        return null;
    }
  }

  /**
   * Decide whether to respond to the current stack item.
   * @returns {{action: string, data: Object}|null}
   */
  chooseResponse() {
    const state = this.getState();
    const top = this.stack.top;
    if (!top) return null;
    if (top.controller === this.side) return null; // Don't counter own spells

    // Simple heuristic: counter if we have a counterspell in hand
    const counter = state[this.side].hand.find((c) =>
      c.effect?.type === 'counterspell' || c.name?.toLowerCase().includes('counter')
    );
    if (counter) {
      return { action: 'castCounter', data: { card: counter, target: top } };
    }
    return null;
  }

  // ─────────────────────────────────────────────
  // Main Phase
  // ─────────────────────────────────────────────

  /** @param {import('../types.js').SideState} myState */
  #chooseMainPhaseAction(myState) {
    // Priority 1: Play a land if we haven't this turn
    // V11.0 fix — `p.playedThisTurn` est posé une fois pour toutes sur le
    // permanent au moment où il entre en jeu (cf. native-engine#playLand) et
    // n'est JAMAIS réinitialisé ensuite : ce n'est pas un compteur par tour,
    // c'est un horodatage. Baser la décision dessus faisait que l'IA ne
    // jouait plus jamais aucun terrain après son tout premier. La source de
    // vérité correcte, remise à zéro à chaque tour (turn-rules.js
    // resetTurnCounters), est `myState.landsPlayedThisTurn`.
    const land = myState.hand.find((c) => String(c.type || '').includes('Land'));
    if (land && !(myState.landsPlayedThisTurn >= 1)) {
      return { action: 'playLand', data: { card: land } };
    }

    // Priority 2: Cast a creature if we have mana
    const creature = myState.hand.find((c) =>
      String(c.type || '').includes('Creature') && this.#canCast(c, myState)
    );
    if (creature) {
      return { action: 'castSpell', data: { card: creature } };
    }

    // Priority 3: Cast any other affordable spell
    const spell = myState.hand.find((c) =>
      c.effect && this.#canCast(c, myState)
    );
    if (spell) {
      return { action: 'castSpell', data: { card: spell } };
    }

    return null;
  }

  // ─────────────────────────────────────────────
  // Combat
  // ─────────────────────────────────────────────

  /** @returns {{action: string, data: {attackers: Permanent[]}}|null} */
  #chooseAttackers() {
    const valid = this.combat.getValidAttackers(this.side);
    // Attack with everything that has power > 0
    const attackers = valid.filter((a) => effectivePowerToughness(this.getState(), a).power > 0);
    if (attackers.length === 0) return null;
    return { action: 'declareAttackers', data: { attackers } };
  }

  /** @returns {{action: string, data: {blockers: Object}}|null} */
  #chooseBlockers() {
    const state = this.getState();
    const attackers = this.combat.combat?.attackers || [];
    const blockers = this.combat.getValidBlockers(this.side);
    if (blockers.length === 0 || attackers.length === 0) return null;

    const assignments = {};
    for (const attacker of attackers) {
      // Find a blocker that survives the trade
      const bestBlocker = blockers.find((b) => {
        const bToughness = effectivePowerToughness(state, b).toughness;
        const aPower = effectivePowerToughness(state, attacker).power;
        return bToughness > aPower;
      });
      if (bestBlocker) {
        assignments[attacker.uid] = [bestBlocker.uid];
        // Remove used blocker
        const idx = blockers.indexOf(bestBlocker);
        if (idx > -1) blockers.splice(idx, 1);
      }
    }

    if (Object.keys(assignments).length === 0) return null;
    return { action: 'declareBlockers', data: { blockers: assignments } };
  }

  // ─────────────────────────────────────────────
  // Mana & Casting
  // ─────────────────────────────────────────────

  /**
   * Check if a card can be cast with available mana.
   * @param {Card} card
   * @param {import('../types.js').SideState} sideState
   * @returns {boolean}
   */
  #canCast(card, sideState) {
    if (!card.cost) return true;
    if (!this.costs) return false;

    // V12: the AI must use the same canonical payment validator as the
    // engine. This prevents false positives such as trying to pay 1B from
    // a pool containing only two generic/white mana.
    const maxX = card.xSpell ? this.#maxAffordableX(card, sideState) : 0;
    return this.costs.canPay(this.side, card.cost, { controller: this.side, card, xValue: maxX });
  }

  #maxAffordableX(card, sideState) {
    if (!card.xSpell) return 0;
    let best = 0;
    const upper = Math.min(20, Object.values(sideState.mana || {}).reduce((a, b) => a + Number(b || 0), 0));
    for (let x = 0; x <= upper; x += 1) {
      if (this.costs.canPay(this.side, card.cost, { controller: this.side, card, xValue: x })) best = x;
    }
    return best;
  }

  canCast(card, xValue = 0) {
    if (!this.costs) return false;
    return this.costs.canPay(this.side, card?.cost || '', { controller: this.side, card, xValue });
  }

  // ─────────────────────────────────────────────
  // Utility
  // ─────────────────────────────────────────────

  /** @returns {string} */
  getStatus() {
    const state = this.getState();
    const my = state[this.side];
    return `AI[${this.side}] hand=${my.hand.length} mana=${Object.values(my.mana).reduce((a,b)=>a+b,0)} life=${my.life}`;
  }
}
