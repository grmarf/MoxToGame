// @ts-check
/**
 * @fileoverview MTG Beta V9.1 — Native Engine
 * Fully self-contained game engine with zero dependency on V7.2.
 * Implements all legacy-port functions using native V8 services.
 */

/** @typedef {import('./types.js').GameState} GameState */
/** @typedef {import('./types.js').Card} Card */
/** @typedef {import('./types.js').Permanent} Permanent */

import { gameEvents } from './event-bus.js';
import { canPayMana, payMana } from './costs/mana-cost.js';
import { CostService } from './costs/cost-system.js';
import { keywordsOf, hasKeyword } from './keywords.js';
import { normalizeCard, createPermanent } from './card-runtime.js';
import { rngClock } from './rng-clock-service.js';
import { getAbilities, isAbilityLegal } from './ability-model.js';
import { applyContinuousEffects } from './continuous-effects.js';

/**
 * Native game engine.
 */
export class NativeEngine {
  /**
   * @param {Object} deps
   * @param {import('./stack.js').StackController} deps.stack
   * @param {import('./combat.js').CombatService} deps.combat
   * @param {import('./state-based-actions.js').StateBasedActions} deps.sba
   * @param {import('./turn/turn-manager.js').TurnManager} deps.turnManager
   * @param {import('./effect-registry.js').EffectRegistry} deps.effects
   */
  constructor({ stack, combat, sba, turnManager, effects }) {
    this.stack = stack;
    this.combat = combat;
    this.sba = sba;
    this.turnManager = turnManager;
    this.effects = effects;
    this._manaApi = { canPayMana, payMana };
    this._priorityHolder = 'player';
    this._consecutivePasses = 0;
    // Preserve runtime services across snapshot restoration.
    this.costService = this.costService || new CostService({ getState: () => this._state });
    /** @type {GameState|null} */
    this._state = this.#createInitialState();
  }

  /** @returns {GameState} */
  get state() { return this._state; }

  setChoiceService(service) { this.choiceService = service; }
  setReplacementService(service) { this.replacementService = service; }
  setZoneManager(service) { this.zoneManager = service; }
  setCostService(service) { this.costService = service || this.costService; }

  // ─────────────────────────────────────────────
  // State Management
  // ─────────────────────────────────────────────

  /** @returns {GameState} */
  getState() { return this._state; }

  /**
   * Replace the internal state (used by serialization restore).
   * @param {GameState} newState
   */
  setState(newState) {
    this._state = newState;
    if (newState.turnNumber) this.turnManager.turnNumber = newState.turnNumber;
    if (newState.activePlayer) this.turnManager.activePlayer = newState.activePlayer;
    if (newState.phase) this.turnManager.gotoPhase(newState.phase);
    this._priorityHolder = newState.priorityHolder || newState.activePlayer || 'player';
    this._consecutivePasses = 0;
    // Preserve runtime services across snapshot restoration.
    this.costService = this.costService || new CostService({ getState: () => this._state });
    gameEvents.emit({ type: 'stateRestored', state: newState });
  }

  // ─────────────────────────────────────────────
  // Actions
  // ─────────────────────────────────────────────

  /**
   * Execute a game action natively.
   * @param {string} action
   * @param {Object} data
   */
  action(action, data = {}) {
    gameEvents.emit({ type: 'actionRequested', action, data });
    const before = JSON.parse(JSON.stringify(this._state));
    try {
      switch (String(action || '').trim()) {
        case 'cast': this.#castSpell(data.card, data.controller || this._state.activePlayer, data.target, data.x || 0); break;
        case 'playLand': this.#playLand(data.card, data.controller || this._state.activePlayer); break;
        case 'tapMana': this.#tapForMana(data.permanent, data.controller || this._state.activePlayer, data.color); break;
        case 'activateAbility': { const p = data.permanent; const controller = data.controller || this._state.activePlayer; const side = this._state[controller]; const actual = side?.battlefield.find(x => x.uid === p?.uid || x.objectId === p?.objectId || x === p) || p; const abilities = getAbilities(actual, controller).filter(a => a.kind === 'activated'); const a = data.abilityIndex != null ? abilities[data.abilityIndex] : (data.ability ?? data.effect); this.#activateAbility(actual, a, controller, data.target); break; }
        case 'nextPhase': this.turnManager.runPhase(); break;
        case 'passPriority': this.passPriorityFrom(data.controller || this._state.priorityHolder); break;
        case 'declareAttackers': this.turnManager.declareAttackers(data.attackers || []); break;
        case 'declareBlockers': this.turnManager.declareBlockers(data.blockers || {}); break;
        case 'confirmBlockers': this.turnManager.declareBlockers(data.blockers || {}); break;
        case 'resolveCombat': this.resolveCombatAssignments(); break;
        default: gameEvents.emit({ type: 'unknownAction', action, data });
      }
      this.sba.check(this._state);
      this.validateState();
    } catch (error) {
      for (const side of ['player', 'ai']) {
        const restored = JSON.parse(JSON.stringify(before[side]));
        for (const key of Object.keys(this._state[side])) delete this._state[side][key];
        Object.assign(this._state[side], restored);
      }
      for (const key of Object.keys(before)) if (key !== 'player' && key !== 'ai') this._state[key] = JSON.parse(JSON.stringify(before[key]));
      this.turnManager.activePlayer = this._state.activePlayer;
      this.turnManager.phase = this._state.phase;
      this._priorityHolder = this._state.priorityHolder;
      gameEvents.emit({ type: 'actionRolledBack', action, error: error.message });
      throw error;
    }
  }

  // ─────────────────────────────────────────────
  // Stack (delegated to StackController)
  // ─────────────────────────────────────────────

  pushToStack(card, controller, targetInfo, xValue) {
    return this.stack.push(card, controller, targetInfo, xValue);
  }

  resolveTopOfStack() {
    const item = this.stack.resolveTop();
    this.sba.check(this._state);
    return item;
  }

  // ─────────────────────────────────────────────
  // Priority
  // ─────────────────────────────────────────────

  passPriorityFrom(side) {
    // State is the serialized source of truth; resync the runtime mirror so
    // snapshots/tests/direct state setup cannot leave the two representations
    // divergent.
    this._priorityHolder = this._state.priorityHolder;
    if (side !== this._priorityHolder) throw new Error(`Priorité détenue par ${this._priorityHolder}.`);
    if (!['player','ai'].includes(side)) throw new Error('Joueur de priorité invalide.');
    this._consecutivePasses += 1;
    const other = side === 'player' ? 'ai' : 'player';
    this._priorityHolder = other;
    this._state.priorityHolder = other;
    this.stack.pass(side);
    gameEvents.emit({ type: 'priorityPassed', side, next: other, consecutivePasses: this._consecutivePasses, stackSize: this.stack.size });
    gameEvents.emit({ type: 'priorityGiven', side: other, reason: 'passTransfer' });

    if (this._consecutivePasses < 2) return;

    this._consecutivePasses = 0;
    if (this.stack.isEmpty) {
      // No object on the stack: both players passed priority, so the current
      // phase may advance. TurnManager owns the phase transition.
      this.turnManager.runPhase();
    } else {
      // Two consecutive passes resolve exactly one top object. Any triggers
      // created during resolution are already on the stack when we restore
      // priority below.
      this.resolveTopOfStack();
    }

    if (this._state.player.hasLost || this._state.ai.hasLost) {
      this._priorityHolder = null;
      this._state.priorityHolder = null;
      gameEvents.emit({ type: 'gameEndedByPriority', reason: 'stateBasedAction' });
      return;
    }

    this._priorityHolder = this.turnManager.activePlayer;
    this._state.priorityHolder = this._priorityHolder;
    gameEvents.emit({ type: 'priorityGiven', side: this._priorityHolder, reason: 'postResolution' });
  }

  giveResponderPriority(side) {
    if (!['player','ai'].includes(side)) throw new Error('Joueur de priorité invalide.');
    this._priorityHolder = side;
    this._state.priorityHolder = side;
    this._consecutivePasses = 0;
    gameEvents.emit({ type: 'priorityGiven', side, reason: 'responseWindow' });
  }

  // ─────────────────────────────────────────────
  // Targeting
  // ─────────────────────────────────────────────

  getValidTargets(effectType, controller) {
    const state = this._state;
    const allPerms = [...state.player.battlefield, ...state.ai.battlefield].map(perm => ({ kind:'permanent', perm, uid:perm.uid, name:perm.name }));
    const players = [{kind:'player',side:'player',id:'player'},{kind:'player',side:'ai',id:'ai'}];
    const opponent = controller === 'player' ? 'ai' : 'player';

    switch (effectType) {
      case 'damage':
      case 'destroy':
      case 'exile':
      case 'bounce':
      case 'tapTarget':
      case 'pump':
      case 'discard':
        return allPerms;
      case 'anyTarget':
        return [...allPerms, ...players];
      case 'discardRandom':
        return state[opponent].hand.length > 0 ? [{ type: 'opponentHand' }] : [];
      case 'draw':
      case 'gainLife':
      case 'mana':
        return [{ type: 'self' }];
      case 'counterSpell':
      case 'counterCMC':
      case 'counterSpellColor':
      case 'counterUnlessPay':
        return this.stack.items.map(item => ({
          ...item,
          _kind: 'stackItem',
          name: item.source?.name || 'Sort',
          type: item.source?.type || 'Spell',
        }));
      case 'copyPermanent':
        return allPerms.filter(p => /Creature/i.test(String(p.perm?.type || '')));
      case 'copySpell':
        return this.stack.items.filter(item => /Instant|Sorcery/i.test(String(item.source?.type || ''))).map(item => ({ ...item, _kind:'stackItem', name:item.source?.name || 'Sort', type:item.source?.type || 'Spell' }));
      case 'tutor':
        return state[controller].library.map(card => ({
          ...card,
          _kind: 'libraryCard',
        }));
      default:
        return allPerms;
    }
  }
  getAbilityOptions(permanentRef, controller) {
    const side=this._state[controller];
    const p=side.battlefield.find(x=>x.uid===permanentRef?.uid) || permanentRef;
    if(!p || !side.battlefield.includes(p)) return [];
    return getAbilities(p, controller).filter(a=>a.kind==='activated' && isAbilityLegal(a,{permanent:p,state:this._state,controller,canPay:(s,c,x)=>this.costService.canPay(controller,c,{controller,permanent:p,xValue:x})}));
  }

  choose(spec) {
    if(!this.choiceService) return spec.defaultValue ?? null;
    return this.choiceService.request(spec);
  }

  needsTarget(effectType) {
    const noTargetTypes = [
      'draw', 'gainLife', 'fog', 'extraTurn', 'wheel', 'mana',
      'destroyAllCreatures', 'destroyAllLands', 'destroyAllEnchantments',
      'damageAllCreaturesAndPlayers', 'damageToFliersAndPlayers',
      'emptyManaPool', 'gainLifePerCreature', 'noop', 'searchLibrary', 'lookTop', 'putTopCardBottom', 'chooseColor', 'chooseNumber', 'coinFlip', 'createToken', 'randomDiscard', 'returnFromGraveyard', 'discardRandom'
    ];
    return !noTargetTypes.includes(effectType);
  }

  // ─────────────────────────────────────────────

  resolveCombatAssignments() {
    if (!this.combat.isActive) return [];
    return this.combat.resolveDamage();
  }

  confirmAttackers(attackers) {
    return this.combat.confirmAttackers(attackers);
  }

  proceedToPlayerBlocks(attackers) {
    this.combat.toDeclareAttackers(attackers);
    return this.combat.confirmAttackers(attackers);
  }

  // ─────────────────────────────────────────────
  // AI Config (stub for compatibility)
  // ─────────────────────────────────────────────

  setAiConfig(difficulty, playstyle) {
    this._state.aiConfig = { difficulty, playstyle };
  }

  #tapForMana(permanent, controller, color = null) {
    const side = this._state[controller];
    const perm = side.battlefield.find(p => p.uid === permanent?.uid);
    if (!perm || (!String(perm.type || '').includes('Land') && !perm.produces)) throw new Error('Permanent producteur introuvable.');
    if (perm.tapped) throw new Error('Ce permanent est déjà engagé.');
    const produced = String(perm.produces || perm.tapAbility?.produces || '');
    if (!produced) throw new Error('Ce terrain n’a pas de capacité de mana native.');
    const chosen = color || (produced === 'any' ? 'G' : produced[0]);
    if (produced !== 'any' && !produced.includes(chosen)) throw new Error('Couleur de mana invalide.');
    this.costService.pay(controller, { tap: true }, { controller, permanent: perm });
    side.mana[chosen] = (side.mana[chosen] || 0) + 1;
    gameEvents.emit({ type: 'manaAdded', side: controller, color: chosen, amount: 1, permanent: perm });
  }

  /** Load and shuffle a deck. Used by the UI and tests. */
  loadDeck(side, cards, { draw = 7 } = {}) {
    if (!this._state[side]) throw new Error(`Unknown side: ${side}`);
    const deck = cards.map((c) => { const card=normalizeCard(c); card.owner=side; card.zone='library'; card.objectId=card.objectId||rngClock.uuid('obj'); card.uid=card.uid||rngClock.uuid('card'); return card; });
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(rngClock.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    this._state[side].library = deck;
    this._state[side].hand = [];
    this._state[side].graveyard = [];
    this._state[side].exile = [];
    const drawCount = Math.min(Math.max(0, Number(draw) || 0), deck.length);
    for (let i = 0; i < drawCount; i++) {
      this._state[side].hand.push(this._state[side].library.pop());
    }
    return this._state[side];
  }

  /** Cast a spell after validating timing, ownership and mana. */
  #castSpell(card, controller, targetInfo = null, xValue = 0) {
    const side = this._state[controller];
    const index = side.hand.indexOf(card);
    if (index < 0) throw new Error('La carte à lancer n’est pas dans la main.');
    if (String(card.type || '').includes('Land')) throw new Error('Un terrain ne se lance pas comme un sort.');
    if (this._state.priorityHolder !== controller) throw new Error('Ce joueur n’a pas la priorité.');
    const isInstantSpeed = /Instant/i.test(String(card.type || '')) || /Flash/i.test(String(card.text_fr || '')) || card.flash === true;
    const isMain = ['main1', 'main2'].includes(this.turnManager.phase) && this.turnManager.activePlayer === controller;
    if (!isMain && !isInstantSpeed) throw new Error('Ce sort ne peut pas être lancé à ce moment.');
    if (card.xSpell && xValue < 0) throw new Error('Valeur X invalide.');
    if (this.needsTarget(card.effect?.type) && !targetInfo && card.effect) throw new Error('Une cible est requise.');
    if (targetInfo && card.effect && !this.#isLegalTarget(card.effect, controller, targetInfo)) throw new Error('Cible illégale.');
    targetInfo = this.#normalizeTarget(targetInfo, controller);
    this.costService.pay(controller, card.cost || '', { controller, xValue, card });
    side.hand.splice(index, 1);
    const item = this.stack.pushSpell(card, controller, targetInfo, xValue);
    gameEvents.emit({ type: 'spellCast', card, controller, xValue, item });
    // Casting a spell ends the caster's action window. The opponent receives
    // priority to respond before the spell can resolve.
    this.giveResponderPriority(controller === 'player' ? 'ai' : 'player');
    return item;
  }

  /** Activate a canonical ability (M3). */
  #activateAbility(permanentRef, abilityOrEffect, controller, targetInfo = null) {
    const side=this._state[controller];
    if(this._state.priorityHolder!==controller) throw new Error(`Ce joueur n'a pas la priorité.`);
    const permanent=side.battlefield.find(p=>p.uid===permanentRef?.uid)||permanentRef;
    if(!permanent||!side.battlefield.includes(permanent)) throw new Error('Permanent introuvable.');
    const ability = abilityOrEffect?.kind ? abilityOrEffect : (abilityOrEffect?.effect ? abilityOrEffect : (abilityOrEffect?.type ? {effect:abilityOrEffect,cost:''} : null));
    if(!ability) throw new Error('Capacité activée invalide.');
    if(ability.manaAbility && permanent.tapAbility) {
      const rawMana = permanent.tapAbility;
      const cost = { mana: ability.costSpec?.mana || '', tap: true, sacrifice: !!rawMana.sacrifice };
      this.costService.pay(controller, cost, {controller, permanent});
      const produced = String(rawMana.produces || permanent.produces || '');
      const amount = Math.max(1, Number(rawMana.chooseColorAmount || 1));
      const options = ['W','U','B','R','G','C'];
      let chosen = produced === 'any' ? (this.choose({type:'manaColor',controller,options}) || 'G') : produced[0];
      if(!options.includes(chosen) && produced !== 'any') throw new Error('Mana produit invalide.');
      for (let i=0;i<amount;i++) side.mana[chosen] = (side.mana[chosen] || 0) + 1;
      gameEvents.emit({type:'manaAdded',side:controller,color:chosen,amount,permanent});
      return { manaAbility:true, permanent, color:chosen, amount };
    }
    if(!ability.effect?.type && !(ability.effects?.length)) throw new Error('Capacité activée sans effet.');
    if(!isAbilityLegal(ability,{permanent,state:this._state,controller,canPay:(s,c,x)=>this.costService.canPay(controller,c,{controller,permanent,xValue:x}),xValue:0})) throw new Error('Capacité activée illégale.');
    this.costService.pay(controller, { mana: ability.cost || '', tap: !!ability.tap }, {controller, permanent});
    const effect = ability.effects?.length > 1 ? { type:'sequence', effects:ability.effects } : ability.effect;
    if(targetInfo && effect && !this.#isLegalTarget(effect,controller,targetInfo)) throw new Error('Cible illégale.');
    targetInfo = this.#normalizeTarget(targetInfo, controller);
    const item=this.stack.pushAbility(permanent,effect,controller,targetInfo);
    gameEvents.emit({type:'abilityActivated',permanent,ability,controller,item});
    // Activated abilities use the same response window as spells.
    this.giveResponderPriority(controller === 'player' ? 'ai' : 'player');
    return item;
  }

  #isLegalTarget(effect, controller, targetInfo) {
    // Effets ciblant explicitement un joueur (ou anyTarget qui inclut les joueurs)
    if ((effect.target === 'player' || effect.target === 'anyTarget') && targetInfo?.kind === 'player') return true;
    const candidates = this.getValidTargets(effect.type === 'damage' && effect.target === 'anyTarget' ? 'anyTarget' : effect.type, controller);
    if (!targetInfo) return !this.needsTarget(effect.type);
    const uid = targetInfo.uid || targetInfo.id || targetInfo;
    return candidates.some(t => t === targetInfo || t.uid === uid || t.id === uid || (t.kind === targetInfo.kind && t.side === targetInfo.side));
  }

  #normalizeTarget(targetInfo, controller) {
    if (!targetInfo) return null;
    if (targetInfo.kind === 'permanent') return targetInfo;
    if (targetInfo.kind === 'player') {
      if (!['player','ai'].includes(targetInfo.side)) throw new Error(`Cible joueur invalide: ${targetInfo.side}`);
      return targetInfo;
    }
    const uid = targetInfo.uid || targetInfo.id || targetInfo;
    const perms = [...this._state.player.battlefield, ...this._state.ai.battlefield];
    const stackItem = this.stack.items.find(x => x.id === uid);
    if (stackItem) return {kind:'stackItem', item:stackItem, id:stackItem.id, name:stackItem.source?.name};
    const p = perms.find(x => x.uid === uid);
    if (p) return {kind:'permanent',perm:p,uid:p.uid,name:p.name};
    if (uid === 'player' || uid === 'ai') return {kind:'player',side:uid,id:uid};
    if (targetInfo.type === 'self') return {kind:'player',side:controller,id:controller};
    if (targetInfo.type === 'opponent') { const side=controller==='player'?'ai':'player'; return {kind:'player',side,id:side}; }
    return targetInfo;
  }

  validateState() {
    const state = this._state;
    if (!['player','ai'].includes(state.activePlayer)) throw new Error('activePlayer invalide.');
    if (!['player','ai'].includes(state.priorityHolder)) throw new Error('priorityHolder invalide.');
    for (const side of ['player','ai']) {
      const s=state[side];
      if (!s || !Array.isArray(s.hand) || !Array.isArray(s.battlefield) || !Array.isArray(s.graveyard) || !Array.isArray(s.library) || !s.mana) throw new Error(`Etat ${side} incomplet.`);
      for (const c of ['W','U','B','R','G','C']) if (!Number.isFinite(Number(s.mana[c]))) throw new Error(`Mana ${side}.${c} invalide.`);
      const seen=new Set();
      for (const p of s.battlefield) { if (!p.uid) throw new Error('Permanent sans uid.'); if(seen.has(p.uid)) throw new Error(`UID permanent dupliqué: ${p.uid}`); seen.add(p.uid); }
    }
    return true;
  }

  // ─────────────────────────────────────────────
  // Private Helpers
  // ─────────────────────────────────────────────

  /** @param {Card} card @param {string} controller */
  #playLand(card, controller) {
    const side = this._state[controller];
    if (this.turnManager.activePlayer !== controller) throw new Error('Ce n’est pas votre tour.');
    if (!['main1', 'main2'].includes(this.turnManager.phase)) throw new Error('Un terrain ne peut être joué qu’en phase principale.');
    if (side.landsPlayedThisTurn >= 1) throw new Error('Un seul terrain peut être joué par tour.');
    if (this._state.priorityHolder !== controller) throw new Error('Ce joueur n’a pas la priorité.');
    const index = side.hand.indexOf(card);
    if (index < 0) throw new Error('Le terrain n’est pas dans la main.');
    side.hand.splice(index, 1);
    const perm = createPermanent(card);
    perm.owner = card.owner || controller;
    perm.controller = controller;
    perm.uid = rngClock.uuid('land');
    perm.playedThisTurn = true;
    perm.enteredTurn = this.turnManager.turnNumber;
    perm.summoningSickness = false;
    if (this.zoneManager) {
      this.zoneManager.enterBattlefield(perm, controller, { controller, reason: 'playLand' });
    } else {
      side.battlefield.push(perm);
    }
    side.landsPlayedThisTurn = (side.landsPlayedThisTurn || 0) + 1;
    gameEvents.emit({ type: 'landPlayed', card: perm, controller });
  }

  /** @returns {GameState} */
  #createInitialState() {
    return {
      player: {
        life: 20,
        library: [],
        hand: [],
        graveyard: [],
        exile: [],
        battlefield: [],
        mana: { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 },
        mustDraw: false,
        extraTurns: 0,
        landsPlayedThisTurn: 0,
        hasLost: false,
        hasDrawnThisTurn: false,
      },
      ai: {
        life: 20,
        library: [],
        hand: [],
        graveyard: [],
        exile: [],
        battlefield: [],
        mana: { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 },
        mustDraw: false,
        extraTurns: 0,
        landsPlayedThisTurn: 0,
        hasLost: false,
        hasDrawnThisTurn: false,
      },
      fogActive: false,
      turnNumber: 1,
      activePlayer: 'player',
      phase: 'untap',
      priorityHolder: 'player',
    };
  }
}
