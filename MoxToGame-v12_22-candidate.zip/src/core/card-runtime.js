// @ts-check
/** Runtime normalization for C0 cards: lands, vanilla creatures and simple permanents. */
import { applyC81Definition } from './effects/card-definitions.js';
import { applyC82Definition } from './effects/static-definitions.js';
import { applyC88Definition } from './effects/final-pass-effects.js';
import { rngClock } from './rng-clock-service.js';

export function normalizeCard(card) {
  const c = { ...card };
  c.cost = c.cost ?? '';
  c.cmc = Number(c.cmc ?? 0);
  c.color = Array.isArray(c.color) ? [...c.color] : [];
  c.keywords = Array.isArray(c.keywords) ? [...c.keywords] : [];
  c.triggers = Array.isArray(c.triggers) ? c.triggers.map(t => ({ ...t })) : [];
  if (c.upkeepTrigger && !c.triggers.some(t => t.event === 'upkeepStarted')) {
    c.triggers.push({ event: 'upkeepStarted', condition: { kind: 'controllerUpkeep', controllerSelf: true }, effect: c.upkeepTrigger });
  }
  c.isLand = /\bLand\b/.test(String(c.type || ''));
  c.isCreature = /\bCreature\b/.test(String(c.type || ''));
  c.isPermanent = /Creature|Artifact|Enchantment|Planeswalker/.test(String(c.type || ''));
  if (c.produces && typeof c.produces !== 'string') c.produces = String(c.produces);
  applyC81Definition(c);
  applyC82Definition(c);
  applyC88Definition(c);
  if (c.name === 'Ali from Cairo') c.replacementEffects = [{ event: 'damageToController', type: 'setLifeMinimum', minimum: 1 }];
  if (c.name === 'Shahrazad') c.effect = { type: 'startSubgame' };
  delete c.__c81Applied; delete c.__c82Applied;
  return c;
}

export function createPermanent(card) {
  const c = normalizeCard(card);
  return {
    ...c,
    uid: c.uid || rngClock.uuid('perm'),
    objectId: c.objectId || rngClock.uuid('obj'),
    zone: 'battlefield',
    zoneChangeId: null,
    tapped: false,
    summoningSickness: !!c.isCreature && !c.keywords.some(k => String(k).toLowerCase() === 'haste'),
    enteredTurn: null,
    damageMarked: 0,
    counters: Array.isArray(c.counters) ? [...c.counters] : [],
    auraBuffs: [],
    tempBuffs: [],
    tempKeywords: [],
    playedThisTurn: false,
    controller: c.controller || null,
    owner: c.owner || null,
  };
}

export function isBasicC0Card(card) {
  const c = normalizeCard(card);
  return c.isLand || (c.isPermanent && !c.effect && !c.activated && !c.triggers && !c.static && !c.tapAbility);
}
