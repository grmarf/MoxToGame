/** Targeting service: legality belongs to the engine, presentation does not. */
export class TargetingService {
  constructor({ getValidTargets, needsTarget }) {
    this._getValidTargets = getValidTargets;
    this._needsTarget = needsTarget;
  }
  needsTarget(effect) { return !!this._needsTarget?.(effect); }
  validTargets(effect, controller, colors = []) {
    return this._getValidTargets?.(effect, controller, colors) ?? [];
  }
  choose(effect, controller, colors = [], predicate = () => true, chooser = null) {
    const options = this.validTargets(effect, controller, colors).filter(predicate);
    if (!options.length) return null;
    if (chooser) return chooser({type:'target', controller, options, min:1, max:1});
    return options[0];
  }
  isLegal(effect, target, controller, colors = []) {
    if (!target) return !this.needsTarget(effect);
    const uid = target.uid || target.id || target;
    return this.validTargets(effect, controller, colors).some(x => x === target || x.uid === uid || x.id === uid);
  }
}
