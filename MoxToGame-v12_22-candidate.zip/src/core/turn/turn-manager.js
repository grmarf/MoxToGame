// @ts-check
/**
 * @fileoverview MTG Beta V8.13 — Turn Manager
 * Orchestrates the full MTG turn structure with explicit phase transitions,
 * automatic SBA checks, and trigger emission.
 */

/** @typedef {import('../types.js').GameState} GameState */

import { gameEvents } from '../event-bus.js';
import { phaseAllowsPriority, emptyManaPool, resetTurnCounters, clearUntilCleanup } from './turn-rules.js';

export const TurnPhase = Object.freeze({
  UNTAP: 'untap',
  UPKEEP: 'upkeep',
  DRAW: 'draw',
  MAIN1: 'main1',
  COMBAT_BEGIN: 'combatBegin',
  DECLARE_ATTACKERS: 'declareAttackers',
  DECLARE_BLOCKERS: 'declareBlockers',
  COMBAT_DAMAGE: 'combatDamage',
  COMBAT_END: 'combatEnd',
  MAIN2: 'main2',
  END_STEP: 'endStep',
  CLEANUP: 'cleanup',
});

const PHASE_ORDER = [
  TurnPhase.UNTAP,
  TurnPhase.UPKEEP,
  TurnPhase.DRAW,
  TurnPhase.MAIN1,
  TurnPhase.COMBAT_BEGIN,
  TurnPhase.DECLARE_ATTACKERS,
  TurnPhase.DECLARE_BLOCKERS,
  TurnPhase.COMBAT_DAMAGE,
  TurnPhase.COMBAT_END,
  TurnPhase.MAIN2,
  TurnPhase.END_STEP,
  TurnPhase.CLEANUP,
];

export class TurnManager {
  /**
   * @param {Object} deps
   * @param {() => GameState} deps.state
   * @param {import('../state-based-actions.js').StateBasedActions} deps.sba
   * @param {import('../combat.js').CombatService} deps.combat
   * @param {import('../triggers/trigger-engine.js').TriggerEngine} [deps.triggerEngine]
   * @param {string} [deps.startingPlayer]
   */
  constructor({ state, sba, combat, triggerEngine = null, startingPlayer = 'player', zones = null }) {
    this.getState = state;
    this.sba = sba;
    this.combat = combat;
    this.triggerEngine = triggerEngine;
    this.zones = zones;
    this.activePlayer = startingPlayer;
    this.turnNumber = 1;
    this.phaseIndex = 0;
    this.phase = TurnPhase.UNTAP;
    this.priorityPlayer = startingPlayer;
    this.combatDeclared = false;
    this.blockersDeclared = false;
    this.extraTurns = 0;
    this.phaseStarted = false;
  }

  /** @returns {{turn: number, phase: string, activePlayer: string}} */
  get snapshot() {
    return {
      turn: this.turnNumber,
      phase: this.phase,
      activePlayer: this.activePlayer,
      priorityPlayer: this.priorityPlayer,
    };
  }

  // ─────────────────────────────────────────────
  // Phase Navigation
  // ─────────────────────────────────────────────

  /** Advance to the next phase, applying turn-based actions and timing hooks. */
  nextPhase() {
    const state = this.getState();
    this.sba.check(state);
    let nextIndex = this.phaseIndex + 1;
    let newTurn = false;
    if (nextIndex >= PHASE_ORDER.length) {
      nextIndex = 0;
      newTurn = true;
    }
    if (newTurn) {
      if (this.extraTurns > 0) this.extraTurns -= 1;
      else this.activePlayer = this.activePlayer === 'player' ? 'ai' : 'player';
      this.turnNumber += 1;
      resetTurnCounters(state[this.activePlayer]);
    }
    this.phaseIndex = nextIndex;
    this.phase = PHASE_ORDER[this.phaseIndex];
    this.combatDeclared = false;
    this.blockersDeclared = false;
    this.#onPhaseEnter();
    state.turnNumber = this.turnNumber;
    state.activePlayer = this.activePlayer;
    state.phase = this.phase;
    state.priorityHolder = phaseAllowsPriority(this.phase) ? this.activePlayer : null;
    this.priorityPlayer = state.priorityHolder;
    gameEvents.emit({ type:'phaseChanged', phase:this.phase, turn:this.turnNumber, activePlayer:this.activePlayer, priorityAvailable:phaseAllowsPriority(this.phase) });
    if (this.phase === TurnPhase.UPKEEP) gameEvents.emit({ type:'upkeepStarted', side:this.activePlayer, activePlayer:this.activePlayer });
    if (this.phase === TurnPhase.DRAW) gameEvents.emit({ type:'drawStepStarted', side:this.activePlayer, activePlayer:this.activePlayer });
    if (this.phase === TurnPhase.COMBAT_BEGIN) gameEvents.emit({ type:'combatStarted', side:this.activePlayer, activePlayer:this.activePlayer });
    if (this.phase === TurnPhase.END_STEP) gameEvents.emit({ type:'endStepStarted', side:this.activePlayer, activePlayer:this.activePlayer });
    return this.snapshot;
  }

  /**
   * Jump to a specific phase (for testing/debugging).
   * @param {string} targetPhase
   */
  gotoPhase(targetPhase) {
    const idx = PHASE_ORDER.indexOf(targetPhase);
    if (idx === -1) throw new Error(`Unknown phase: ${targetPhase}`);
    this.phaseIndex = idx;
    this.phase = targetPhase;
    if (targetPhase === TurnPhase.DECLARE_ATTACKERS) this.combatDeclared = false;
    if (targetPhase === TurnPhase.DECLARE_BLOCKERS) this.blockersDeclared = false;
    this.#onPhaseEnter();
    return this.snapshot;
  }

  /** Run the entire current phase and advance. */
  runPhase() {
    const phase = this.phase;
    switch (phase) {
      case TurnPhase.UNTAP:
        this.#runUntap();
        break;
      case TurnPhase.UPKEEP:
        this.#runUpkeep();
        break;
      case TurnPhase.DRAW:
        this.#runDraw();
        break;
      case TurnPhase.MAIN1:
      case TurnPhase.MAIN2:
        this.#runMain();
        break;
      case TurnPhase.COMBAT_BEGIN:
        this.combat.begin();
        break;
      case TurnPhase.DECLARE_ATTACKERS:
        // Waiting for player/AI input
        break;
      case TurnPhase.DECLARE_BLOCKERS:
        // Waiting for player/AI input
        break;
      case TurnPhase.COMBAT_DAMAGE:
        this.#runCombatDamage();
        break;
      case TurnPhase.COMBAT_END:
        this.combat.end();
        break;
      case TurnPhase.END_STEP:
        this.#runEndStep();
        break;
      case TurnPhase.CLEANUP:
        this.#runCleanup();
        break;
    }
    return this.nextPhase();
  }

  // ─────────────────────────────────────────────
  // Phase Implementations
  // ─────────────────────────────────────────────

  #runUntap() {
    const state = this.getState();
    state.priorityHolder = null;
    const side = state[this.activePlayer];
    if (this.#hasStatic('skipUntap', this.activePlayer)) { side.skipUntap = false; gameEvents.emit({type:'untapSkipped', side:this.activePlayer}); return; }
    for (const perm of side.battlefield) {
      if (perm.tapped && !perm.cantUntap) {
        perm.tapped = false;
        gameEvents.emit({ type: 'permanentUntapped', permanent: perm, side: this.activePlayer });
      }
    }
  }

  #runUpkeep() {
    // Triggers are emitted by phaseChanged event, caught by TriggerEngine
    // This is where upkeep cost effects resolve
  }

  #runDraw() {
    const state = this.getState();
    const side = state[this.activePlayer];
    if (this.#hasStatic('skipDraw', this.activePlayer)) { side.hasDrawnThisTurn = true; gameEvents.emit({type:'drawSkipped', side:this.activePlayer}); return; }
    if (side.hasDrawnThisTurn) return;
    side.hasDrawnThisTurn = true;
    if (side.library.length > 0) {
      // ZoneManager.move() resolves the object from its current zone. Do not
      // pop it first: removing it from the library makes the lookup fail.
      const card = side.library[side.library.length - 1];
      if (this.zones) this.zones.move(card, 'hand', { toSide: this.activePlayer, reason: 'draw' });
      else side.hand.push(side.library.pop());
    } else {
      side.mustDraw = true;
      this.sba.check(state);
    }
  }

  #runMain() {
    // Main phase: player/AI can play lands, cast spells, activate abilities
    // No automatic actions
  }

  #runCombatDamage() {
    if (this.combat.isActive && this.combat.currentPhase === 'combatDamage') {
      const events = this.combat.resolveDamage();
      this.sba.check(this.getState());
      return events;
    }
    return [];
  }

  #runEndStep() {
    // End step triggers
  }

  #runCleanup() {
    const state = this.getState();
    const side = state[this.activePlayer];
    clearUntilCleanup(side);
    for (const perm of [...state.player.battlefield, ...state.ai.battlefield]) {
      if (perm.damageMarked > 0) perm.damageMarked = 0;
      if (perm.summoningSickness && perm.enteredTurn != null && perm.enteredTurn < this.turnNumber) perm.summoningSickness = false;
    }
    const emptied = emptyManaPool(side);
    if (emptied) gameEvents.emit({type:'manaPoolEmptied', side:this.activePlayer, amount:emptied, reason:'cleanup'});
    while (side.hand.length > 7) {
      // ZoneManager.move() must see the card in its source zone; do not pop
      // it before resolving the zone change.
      const discarded = side.hand[side.hand.length - 1];
      if (this.zones) this.zones.move(discarded, 'graveyard', { toSide: discarded.owner || this.activePlayer, reason: 'handSize' });
      else side.graveyard.push(side.hand.pop());
      gameEvents.emit({ type:'discardedToHandSize', card:discarded, side:this.activePlayer });
    }
    gameEvents.emit({type:'cleanupCompleted', side:this.activePlayer, turn:this.turnNumber});
  }

  #hasStatic(type, side) {
    const state = this.getState();
    return ['player','ai'].some(s => (state[s]?.battlefield || []).some(p => {
      const list = Array.isArray(p.static) ? p.static : (p.static ? [p.static] : []);
      return list.some(e => e?.type === type && (e.controller === 'all' || e.controller === side || !e.controller));
    }));
  }

  #onPhaseEnter() {
    const state = this.getState();
    if (!phaseAllowsPriority(this.phase)) {
      this.priorityPlayer = null;
    } else if (this.phase === TurnPhase.DECLARE_BLOCKERS) {
      // The defending player is the non-active player. The active player
      // cannot advance through the blockers window on their own.
      this.priorityPlayer = this.activePlayer === 'player' ? 'ai' : 'player';
    } else {
      this.priorityPlayer = this.activePlayer;
    }
    state.priorityHolder = this.priorityPlayer;
  }

  takeExtraTurn() { this.extraTurns += 1; gameEvents.emit({type:'extraTurnScheduled', player:this.activePlayer, count:this.extraTurns}); }

  // ─────────────────────────────────────────────
  // Combat Helpers
  // ─────────────────────────────────────────────

  beginCombat() {
    this.gotoPhase(TurnPhase.COMBAT_BEGIN);
    return this.combat.begin();
  }

  declareAttackers(attackers) {
    if (this.phase !== TurnPhase.DECLARE_ATTACKERS) this.gotoPhase(TurnPhase.DECLARE_ATTACKERS);
    const result = this.combat.confirmAttackers(attackers, this.activePlayer);
    this.combatDeclared = true;
    return result;
  }

  declareBlockers(blockerMap) {
    if (this.phase !== TurnPhase.DECLARE_BLOCKERS) this.gotoPhase(TurnPhase.DECLARE_BLOCKERS);
    this.combat.assignBlockers(blockerMap || {});
    this.blockersDeclared = true;
    return this.combat.confirmBlockers();
  }

  resolveCombatDamage() {
    this.gotoPhase(TurnPhase.COMBAT_DAMAGE);
    return this.#runCombatDamage();
  }
}
