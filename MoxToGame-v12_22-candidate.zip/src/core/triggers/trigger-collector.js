/**
 * V8.5 — Triggered Ability Collector
 *
 * Converts canonical game events into stack-ready trigger objects.
 * A trigger source is a permanent/card with `abilities` or `triggers`.
 *
 * Supported trigger descriptors:
 *   { event: "creatureDied", effect: ... }
 *   { event: "spellCast", effect: ... }
 *   { event: "permanentEntered", effect: ... }
 *
 * `condition` may be a function(event, context) => boolean.
 * `createStackItem` may be supplied for advanced/custom stack integration.
 */
function sameStableIdentity(a, b, explicitId = null) {
  if (a === b) return true;
  const aIds = [a?.uid, a?.objectId, a?.id].filter(Boolean);
  const bIds = [b?.uid, b?.objectId, b?.id].filter(Boolean);
  if (explicitId && bIds.includes(explicitId)) return true;
  return aIds.some(id => bIds.includes(id));
}

function matchesCondition(condition, event, context) {
  switch (condition.kind) {
    case "combatDamageToPlayer":
      return event.damageKind === "combat" && event.targetType === "player" &&
        (!condition.sourceSelf || sameStableIdentity(event.source, context.source, event.sourceId));
    case "controllerUpkeep":
      return event.side === context.controller && (!condition.controllerSelf || event.side === context.controller);
    default:
      return false;
  }
}

export class TriggerCollector {
  constructor({ eventBus, stack, getGameState = () => null } = {}) {
    if (!eventBus) throw new Error("TriggerCollector requires an eventBus");
    this.eventBus = eventBus;
    this.stack = stack;
    this.getGameState = getGameState;
    this.registrations = new Map();
    this.unsubscribers = new Map();
  }

  registerSource(source, controller, descriptors = null) {
    const list = descriptors || [
      ...(Array.isArray(source?.triggers) ? source.triggers : []),
      ...(Array.isArray(source?.abilities) ? source.abilities.filter(a => a?.event) : []),
      ...(source?.upkeepTrigger ? [{ event: 'upkeepStarted', condition: { kind: 'controllerUpkeep', controllerSelf: true }, effect: source.upkeepTrigger }] : []),
    ];
    const normalized = list
      .filter(Boolean)
      .map(d => ({ ...d, source, controller }));

    this.registrations.set(source, normalized);

    return normalized;
  }

  unregisterSource(source) {
    this.registrations.delete(source);
  }

  clear() {
    for (const unsubscribe of this.unsubscribers.values()) unsubscribe();
    this.unsubscribers.clear();
    this.registrations.clear();
  }

  collect(event) {
    const triggers = [];

    for (const descriptors of this.registrations.values()) {
      for (const descriptor of descriptors) {
        if (descriptor.event !== event.type) continue;

        const context = {
          event,
          source: descriptor.source,
          controller: descriptor.controller,
          state: this.getGameState()
        };

        if (typeof descriptor.condition === "function" &&
            !descriptor.condition(event, context)) {
          continue;
        }

        if (descriptor.condition && typeof descriptor.condition === "object" &&
            !matchesCondition(descriptor.condition, event, context)) {
          continue;
        }

        triggers.push(this.#toStackItem(descriptor, context));
      }
    }

    return triggers;
  }

  collectAndPush(event) {
    // Kept for compatibility. TriggerEngine is the single owner of trigger
    // collection, APNAP ordering and stack insertion; pushing here would
    // create duplicate triggers.
    return this.collect(event);
  }

  #toStackItem(descriptor, context) {
    if (typeof descriptor.createStackItem === "function") {
      return descriptor.createStackItem(context);
    }

    return {
      type: "triggeredAbility",
      source: descriptor.source,
      controller: descriptor.controller,
      triggerEvent: context.event,
      effect: descriptor.effect,
      description: descriptor.description || null
    };
  }

  #subscribe(eventType) {
    if (!eventType || this.unsubscribers.has(eventType)) return;

    const unsubscribe = this.eventBus.on(eventType, event => {
      this.collectAndPush(event);
    });

    this.unsubscribers.set(eventType, unsubscribe);
  }

  #refreshSubscriptions() {
    const required = new Set();
    for (const descriptors of this.registrations.values()) {
      for (const d of descriptors) if (d.event) required.add(d.event);
    }

    for (const [event, unsubscribe] of this.unsubscribers) {
      if (!required.has(event)) {
        unsubscribe();
        this.unsubscribers.delete(event);
      }
    }

    for (const event of required) this.#subscribe(event);
  }
}
