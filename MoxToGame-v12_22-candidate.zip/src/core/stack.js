// @ts-check
/**
 * @fileoverview MTG Beta V8.12 — Native Stack Controller
 * Full LIFO stack with EffectRegistry resolution, priority gates,
 * and canonical event emission. Replaces legacy stack delegation.
 */

/** @typedef {import('./types.js').GameState} GameState */
/** @typedef {import('./types.js').StackItem} StackItem */
/** @typedef {import('./types.js').EffectData} EffectData */
/** @typedef {import('./types.js').Card} Card */
/** @typedef {import('./types.js').Permanent} Permanent */
/** @typedef {import('./effect-registry.js').EffectRegistry} EffectRegistry */

import { gameEvents } from './event-bus.js';
import { rngClock } from './rng-clock-service.js';
import { createPermanent } from './card-runtime.js';
import { applyCopyValues, snapshotCopy } from './layers/copy-effects.js';

/**
 * Unique ID generator for stack items.
 * @returns {string}
 */
function uid() {
  return rngClock.uuid('stk');
}

/**
 * Native stack controller with EffectRegistry resolution.
 */
export class StackController {
  /**
   * @param {Object} deps
   * @param {() => GameState} deps.state
   * @param {EffectRegistry} deps.effects
   * @param {Function} [deps.pushLegacy] — optional fallback
   * @param {Function} [deps.resolveLegacy] — optional fallback
   */
  constructor({ state, effects, pushLegacy, resolveLegacy, zones = null, replacements = null, choiceService = null, subgames = null, combat = null }) {
    this.getState = state;
    this.effects = effects;
    this.pushLegacy = pushLegacy;
    this.resolveLegacy = resolveLegacy;
    this.zones = zones;
    this.replacements = replacements;
    this.choiceService = choiceService;
    this.subgames = subgames;
    this.combat = combat;
    /** @type {StackItem[]} */
    this._items = [];
    /** @type {Set<string>} */
    this._resolved = new Set();
  }

  /** @returns {StackItem[]} */
  get items() { return [...this._items]; }

  /** @returns {number} */
  get size() { return this._items.length; }

  /** @returns {StackItem|null} */
  get top() { return this._items[this._items.length - 1] ?? null; }

  /** @returns {boolean} */
  get isEmpty() { return this._items.length === 0; }

  // ─────────────────────────────────────────────
  // Push Operations
  // ─────────────────────────────────────────────

  /**
   * Push a spell onto the stack.
   * @param {Card} card
   * @param {string} controller — 'player' | 'ai'
   * @param {Object} [targetInfo]
   * @param {number} [xValue]
   * @returns {StackItem}
   */
  pushSpell(card, controller, targetInfo = null, xValue = 0) {
    const item = {
      id: uid(),
      type: 'spell',
      source: card,
      effect: card.effect || null,
      effects: Array.isArray(card.effects) ? card.effects : (card.effect ? [card.effect] : []),
      controller,
      target: targetInfo,
      xValue,
      timestamp: rngClock.now(),
    };
    this._items.push(item);
    gameEvents.emit({ type: 'stackPushed', item, stackSize: this.size });
    return item;
  }

  /**
   * Push a triggered ability onto the stack.
   * @param {Object} trigger — from TriggerCollector
   * @param {string} controller
   * @returns {StackItem}
   */
  pushTrigger(trigger, controller) {
    const item = {
      id: uid(),
      type: 'trigger',
      source: trigger.source,
      effect: trigger.effect,
      effects: Array.isArray(trigger.effects) ? trigger.effects : (trigger.effect ? [trigger.effect] : []),
      controller,
      target: null,
      xValue: 0,
      timestamp: rngClock.now(),
      triggerDescriptor: trigger,
    };
    this._items.push(item);
    gameEvents.emit({ type: 'stackPushed', item, stackSize: this.size });
    return item;
  }

  /**
   * Push an activated ability onto the stack.
   * @param {Permanent} permanent
   * @param {EffectData} effect
   * @param {string} controller
   * @param {Object} [targetInfo]
   * @returns {StackItem}
   */
  pushAbility(permanent, effect, controller, targetInfo = null) {
    const item = {
      id: uid(),
      type: 'ability',
      source: permanent,
      effect,
      effects: Array.isArray(effect) ? effect : (effect ? [effect] : []),
      controller,
      target: targetInfo,
      xValue: 0,
      timestamp: rngClock.now(),
    };
    this._items.push(item);
    gameEvents.emit({ type: 'stackPushed', item, stackSize: this.size });
    return item;
  }

  /**
   * Legacy-compatible push wrapper.
   * @param {Card} card
   * @param {string} controller
   * @param {Object} [targetInfo]
   * @param {number} [xValue]
   * @returns {StackItem|null}
   */
  push(card, controller, targetInfo = null, xValue = 0) {
    if (card.effect && this.effects.has(card.effect.type)) {
      return this.pushSpell(card, controller, targetInfo, xValue);
    }
    // Fallback to legacy for un-migrated effects
    if (this.pushLegacy) {
      this.pushLegacy(card, controller, targetInfo, xValue);
    }
    return null;
  }

  // ─────────────────────────────────────────────
  // Resolution
  // ─────────────────────────────────────────────

  pushCopy(item, controller, target=null) {
    const deepClone = (obj) => { if (obj === null || typeof obj !== 'object') return obj; if (obj instanceof Date) return new Date(obj); if (Array.isArray(obj)) return obj.map(deepClone); const c={}; for (const k of Object.keys(obj)) c[k]=deepClone(obj[k]); return c; };
    const copy = { ...item, id: uid(), type:'copy', controller, target, timestamp:rngClock.now(), copiedFrom:item.id, source:deepClone(item.source || {}), effects:deepClone(item.effects || []), effect:deepClone(item.effect || null) };
    this._items.push(copy);
    gameEvents.emit({ type:'stackPushed', item:copy, stackSize:this.size, copy:true });
    return copy;
  }

  pushSpellCopy(item, controller, target=null) { return this.pushCopy(item, controller, target); }

  /**
   * Resolve the top item of the stack using EffectRegistry.
   * @returns {StackItem|null}
   */
  resolveTop() {
    const item = this._items.pop();
    if (!item) {
      gameEvents.emit({ type: 'stackEmptied' });
      return null;
    }

    if (this._resolved.has(item.id)) {
      gameEvents.emit({ type: 'stackResolved', item, duplicate: true });
      return item;
    }

    // Try native resolution first
    if (item.effect && this.effects.has(item.effect.type)) {
      const state = this.getState();
      const ctx = {
        state,
        controllerKey: item.controller,
        sourceCard: item.source,
        api: this.#buildApi(state),
        targetInfo: item.target,
        xValue: item.xValue,
      };
      try {
        for (const effect of (item.effects?.length ? item.effects : [item.effect])) {
          if (!effect?.type) continue;
          if (!this.effects.has(effect.type)) {
            gameEvents.emit({ type: 'unknownEffect', effect, item });
            continue;
          }
          this.effects.resolve(effect.type, ctx, effect);
        }
        this._finalizeSpell(item);
        this._resolved.add(item.id);
        gameEvents.emit({ type: 'stackResolved', item, native: true });
      } catch (err) {
        gameEvents.emit({ type: 'stackResolutionFailed', item, error: err.message });
        // Re-push on failure so it can be retried or handled
        this._items.push(item);
        throw err;
      }
      return item;
    }

    // Fallback to legacy resolution
    if (this.resolveLegacy) {
      this.resolveLegacy();
      gameEvents.emit({ type: 'stackResolved', item, native: false });
      return item;
    }

    if (item.type === 'spell') this._finalizeSpell(item);
    gameEvents.emit({ type: 'stackResolved', item, native: false, noEffect: true });
    return item;
  }

  /**
   * Resolve all items in the stack (LIFO order).
   * @returns {StackItem[]}
   */
  resolveAll() {
    const resolved = [];
    while (!this.isEmpty) {
      resolved.push(this.resolveTop());
    }
    return resolved;
  }

  // ─────────────────────────────────────────────
  // Priority & Response
  // ─────────────────────────────────────────────

  /**
   * Check if a player can respond to the current top item.
   * @param {string} side — 'player' | 'ai'
   * @returns {boolean}
   */
  canRespond(side) {
    if (this.isEmpty) return false;
    const top = this.top;
    // A player cannot respond to their own spell/ability immediately
    // (simplified: both get priority before resolution)
    return top.controller !== side || this.size > 1;
  }

  /**
   * Pass priority for a side.
   * @param {string} side
   */
  pass(side) {
    gameEvents.emit({ type: 'priorityPassed', side, stackSize: this.size, topItem: this.top });
    if (this.pushLegacy) {
      this.pushLegacy(side);
    }
  }

  // ─────────────────────────────────────────────
  // Utility
  // ─────────────────────────────────────────────

  /** Remove all items from the stack. */
  clear() {
    const count = this._items.length;
    this._items.length = 0;
    gameEvents.emit({ type: 'stackCleared', count });
  }

  /** @returns {StackItem[]} */
  toArray() { return [...this._items]; }

  /** Move a resolved spell to its correct zone, or put a permanent spell onto the battlefield. */
  _finalizeSpell(item) {
    if (item.type !== 'spell') return;
    const state = this.getState();
    const side = state[item.controller];
    const card = item.source;
    const isPermanent = /Creature|Artifact|Enchantment|Planeswalker/.test(String(card?.type || ''));

    // Bug 9 : Aura sans cible valide doit fizzle
    if (isPermanent && /\bAura\b/i.test(String(card?.type || ''))) {
        const ref = item.target?.perm || item.target?.object || item.target;
        const target = this.#buildApi(state).findPermanent(ref);
        if (!target) {
            if (this.zones) {
                try { this.zones.moveToGraveyard(card, { toSide: item.controller, reason: 'fizzleNoTarget' }); }
                catch (e) { side.graveyard.push({ ...card, zone: 'graveyard', objectId: card.objectId || rngClock.uuid('obj') }); }
            } else {
                side.graveyard.push({ ...card, zone: 'graveyard', objectId: card.objectId || rngClock.uuid('obj') });
            }
            gameEvents.emit({ type: 'spellFizzled', item, reason: 'auraNoTarget' });
            return;
        }
    }

    if (isPermanent) {
      let resolvedCard = card;
      if (card?.effect?.type === 'copyPermanent') {
        const ref = item.target?.perm || item.target?.object || item.target;
        const id = ref?.uid || ref?.objectId || ref?.id || ref;
        const copied = [...state.player.battlefield, ...state.ai.battlefield].find(p => p.uid === id || p.objectId === id);
        if (copied) {
          resolvedCard = { ...JSON.parse(JSON.stringify(copied)), owner: card.owner || item.controller, controller: item.controller, zone:'battlefield', copiedFrom:copied.uid };
          delete resolvedCard.uid; delete resolvedCard.objectId; delete resolvedCard.zoneChangeId;
          delete resolvedCard.enteredTurn; delete resolvedCard.damageMarked;
        }
      }
      const permanent = createPermanent(resolvedCard);
      permanent.controller = item.controller;
      permanent.owner = card.owner || item.controller;
      permanent.enteredTurn = state.turnNumber || 1;
      const entered = this.zones ? this.zones.enterBattlefield(permanent, item.controller, { controller: item.controller, reason: 'spellResolved' }) : (side.battlefield.push(permanent), permanent);
      if (/\bAura\b/i.test(String(card?.type || ''))) {
        entered.isAura = true;
        entered.auraEffect = card.effect || null;
        const ref = item.target?.perm || item.target?.object || item.target;
        const target = this.#buildApi(state).findPermanent(ref);
        if (target) entered.attachedTo = target.uid;
      }
      gameEvents.emit({ type: 'permanentEntered', permanent: entered, side: item.controller, controller: item.controller, source: card });
    } else {
      // Bug 8 : fallback si zones.find échoue
      if (this.zones) {
        try { this.zones.moveToGraveyard(card, { toSide: item.controller, reason: 'spellResolved' }); }
        catch (e) { side.graveyard.push({ ...card, zone: 'graveyard', objectId: card.objectId || rngClock.uuid('obj') }); }
      } else {
        side.graveyard.push({ ...card, zone: 'graveyard', objectId: card.objectId || rngClock.uuid('obj') });
      }
    }
  }

  // ─────────────────────────────────────────────
  // Private
  // ─────────────────────────────────────────────

  /** @param {GameState} state */
  /** @param {GameState} state */
  #buildApi(state) {
    const stack = this;
    return {
      state,
      opponentKey: (k) => k === 'player' ? 'ai' : 'player',
      allPermanents: () => [...state.player.battlefield, ...state.ai.battlefield],
      combat: stack.combat && stack.combat.combat ? {
        phase: stack.combat.combat.phase,
        attackers: stack.combat.combat.attackers.map(a => a.uid),
        blockers: Object.fromEntries(
          Object.entries(stack.combat.combat.blockers || {}).map(([k, v]) => [k, v.map(b => b.uid)])
        ),
        attackingSide: stack.combat.combat.attackingSide,
        defendingSide: stack.combat.combat.defendingSide,
      } : null,
      zones: stack.zones,
      moveToZone: (obj, zone, opts={}) => stack.zones ? stack.zones.move(obj, zone, opts) : null,
      preventDamage: (side, amount, color=null, source=null, meta={}) => stack.replacements?.preventDamage(side, amount, color, source, meta) || { prevented:0, remaining:amount },
      replaceDamageLifeLoss: (side, amount, meta={}) => stack.replacements?.replaceDamageLifeLoss(side, amount, meta) || { replaced:false, loss:amount },
      applyDamageToPlayer: (side, amount, opts={}) => stack.replacements?.applyDamageToPlayer(side, amount, opts) || { amount, prevented:0, loss:amount },
      applyDamageToPermanent: (target, amount, opts={}) => stack.replacements?.applyDamageToPermanent(target, amount, opts) || { amount, prevented:0 },
      startSubgame: (controller='player') => stack.subgames?.start({controller}),
      addPreventionShield: (side, shield) => stack.replacements?.addPreventionShield(side, shield),
      drawCard: (side) => { const s=state[side]; if(!s.library.length){ s.mustDraw=true; return null; } const c=s.library[s.library.length-1]; if(stack.zones) return stack.zones.move(c,'hand',{toSide:side,reason:'draw'}); s.library.pop(); s.hand.push(c); return c; },
      discardCard: (side, index=0) => { const s=state[side]; if(!s.hand.length) return null; const safeIndex=Math.max(0,Math.min(index,s.hand.length-1)); const c=s.hand[safeIndex]; gameEvents.emit({type:'cardDiscarded',state,side,card:c,reason:'discard'}); if(stack.zones) return stack.zones.move(c,'graveyard',{toSide:c.owner||side,reason:'discard'}); s.hand.splice(safeIndex,1); s.graveyard.push(c); return c; },

      // ── Pile ──
      stackItems: () => [...stack._items],
      findStackItem: (itemId) => stack._items.find(it => it.id === itemId),
      findPermanent: (ref) => { const id = ref?.uid || ref?.objectId || ref?.id || ref; return [...state.player.battlefield, ...state.ai.battlefield].find(p => p.uid === id || p.objectId === id) || null; },
      attachAura: (auraRef, targetRef) => { const aura = stack.#buildApi(state).findPermanent(auraRef); const target = stack.#buildApi(state).findPermanent(targetRef); if (!aura || !target || !/\bAura\b/i.test(String(aura.type||''))) return null; aura.isAura=true; aura.attachedTo=target.uid; aura.auraEffect=aura.auraEffect||aura.effect||null; gameEvents.emit({type:'auraAttached',aura,target}); return aura; },
      detachAura: (auraRef) => { const aura = stack.#buildApi(state).findPermanent(auraRef); if (!aura) return null; const old=aura.attachedTo; aura.attachedTo=null; gameEvents.emit({type:'auraDetached',aura,oldTarget:old}); return aura; },
      pushSpellCopy: (item, controller, target=null) => stack.pushCopy(item, controller, target),
      choose: (spec) => this.choiceService?.request(spec) ?? spec.defaultValue ?? null,
      chooseNewTargets: (item, controller) => item.target,
      resolveInlineEffect: (effect, extra={}) => { if (!effect?.type || !stack.effects.has(effect.type)) return null; return stack.effects.resolve(effect.type, { state, controllerKey:extra.controllerKey || 'player', sourceCard:extra.sourceCard || null, api:stack.#buildApi(state), targetInfo:extra.targetInfo || null, xValue:extra.xValue || 0 }, effect); },
      createToken: (side, effect) => { const token = { ...effect, id:undefined, uid:rngClock.uuid('token'), objectId:rngClock.uuid('obj'), zone:'battlefield', owner:side, controller:side, token:true, enteredTurn:state.turnNumber||1, damageMarked:0, tapped:false, summoningSickness:!!effect.isCreature && !effect.keywords?.includes('haste'), counters:[] }; delete token.amount; delete token.controller; token.controller=side; state[side].battlefield.push(token); gameEvents.emit({type:'permanentEntered',permanent:token,side,controller:side,source:token}); return token; },
      removeStackItem: (itemId) => {
        const idx = stack._items.findIndex(it => it.id === itemId);
        if (idx >= 0) {
          const [removed] = stack._items.splice(idx, 1);
          return removed;
        }
        return null;
      },

      // ── Mana ──
      totalMana: (pool) => Object.values(pool).reduce((a, b) => a + b, 0),
      payGenericFromPool: (side, amount) => {
        let remaining = amount;
        for (const c of ['C', 'W', 'U', 'B', 'R', 'G']) {
          while (remaining > 0 && side.mana[c] > 0) { side.mana[c]--; remaining--; }
        }
        return remaining === 0;
      },

      // ── Mots-clés & protection ──
      effectiveKeywords: (perm) => {
        const base = perm.keywords || [];
        const granted = [];
        const allPerms = [...state.player.battlefield, ...state.ai.battlefield];
        allPerms.forEach(a => {
          if (a.isAura && a.attachedTo === perm.uid && a.auraEffect) {
            if (a.auraEffect.type === 'addKeyword') granted.push(a.auraEffect.keyword);
            if (a.auraEffect.type === 'unblockable') granted.push('unblockable');
            if (a.auraEffect.type === 'addProtection') {
              const map = { W: 'protectionWhite', U: 'protectionBlue', B: 'protectionBlack', R: 'protectionRed', G: 'protectionGreen' };
              if (map[a.auraEffect.color]) granted.push(map[a.auraEffect.color]);
            }
          }
        });
        const temp = perm.tempKeywords || [];
        return [...base, ...granted, ...temp];
      },
      effectivePT: (perm) => {
        const power = (perm.power || 0) + (perm.auraBuffs?.reduce((s, b) => s + (b.power || 0), 0) || 0);
        const toughness = (perm.toughness || 0) + (perm.auraBuffs?.reduce((s, b) => s + (b.toughness || 0), 0) || 0);
        return { power, toughness };
      },
      hasProtectionFromColors: (perm, sourceColors) => {
        if (!sourceColors || sourceColors.length === 0) return false;
        const PROTECTION_COLOR_MAP = {
          protectionWhite: 'W', protectionBlue: 'U', protectionBlack: 'B', protectionRed: 'R', protectionGreen: 'G'
        };
        const kw = perm.keywords || [];
        const granted = [];
        const allPerms = [...state.player.battlefield, ...state.ai.battlefield];
        allPerms.forEach(a => {
          if (a.isAura && a.attachedTo === perm.uid && a.auraEffect?.type === 'addProtection') {
            const map = { W: 'protectionWhite', U: 'protectionBlue', B: 'protectionBlack', R: 'protectionRed', G: 'protectionGreen' };
            if (map[a.auraEffect.color]) granted.push(map[a.auraEffect.color]);
          }
        });
        const prot = [...kw, ...granted].map(k => PROTECTION_COLOR_MAP[k]).filter(Boolean);
        return prot.some(c => sourceColors.includes(c));
      },

      // ── Destruction & utilitaires ──
      log: (msg, side) => gameEvents.emit({ type: 'log', msg, side }),
      checkStateBasedDeaths: () => {},
      destroyPermanent: (p, opts = {}) => {
        const side = state.player.battlefield.includes(p) ? 'player' : state.ai.battlefield.includes(p) ? 'ai' : null;
        if (side) {
          // V12.19 (fix) : destroyPermanent() est le point d'entrée commun à tous
          // les effets de destruction directe (Terror, Wrath of God, etc. via le
          // handler 'destroy' d'atomic-effects.js, gagnant du registre). Il
          // ignorait totalement regenShield, contrairement au chemin des dégâts
          // létaux dans state-based-actions.js -- confirmé par test réel
          // (Will-o'-the-Wisp survivait au SBA mais mourait quand même à Terror).
          // Comportement aligné sur celui de l'ASB : consomme le bouclier,
          // engage la créature, retire les dégâts marqués, empêche la mort.
          if (p.regenShield && !opts.noRegen) {
            p.regenShield = false;
            p.damageMarked = 0;
            p.tapped = true;
            gameEvents.emit({ type: 'regenerationUsed', permanent: p, side, reason: 'destroy' });
            return;
          }
          if (stack.zones) stack.zones.moveToGraveyard(p, { toSide: p.owner || side, reason: 'destroy' });
          else { state[side].battlefield = state[side].battlefield.filter(x => x !== p); state[side].graveyard.push(p); }
          p.destroyed = true;
        }
      },
      findPermSide: (p) => state.player.battlefield.includes(p) ? 'player' : state.ai.battlefield.includes(p) ? 'ai' : null,
      shuffle: (a) => rngClock.shuffle(a),
      uid: () => rngClock.uuid('p'),
      makePermFromCard: (c) => ({ ...c, auraBuffs: [], tempBuffs: [] }),
    };
  }

}
