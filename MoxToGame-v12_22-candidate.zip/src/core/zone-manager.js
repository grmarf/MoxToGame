// V9.6 — canonical zone/object manager (M8).
import { gameEvents } from './event-bus.js';
let sequence = 0;
import { rngClock } from './rng-clock-service.js';
function nextId(prefix='obj') { sequence += 1; return `${prefix}_${rngClock.now().toString(36)}_${sequence.toString(36)}`; }
export const ZONES = Object.freeze(['library','hand','battlefield','graveyard','exile']);
export class ZoneManager {
  constructor({ state, replacements = null } = {}) { this.getState = state; this.replacements = replacements; }
  ensureIdentity(obj, { owner=null, controller=null }={}) {
    if (!obj) return obj;
    if (!obj.objectId) obj.objectId=nextId('obj'); if (!obj.uid) obj.uid=nextId('card');
    if (owner && !obj.owner) obj.owner=owner; if (controller) obj.controller=controller; return obj;
  }
  find(ref) { if (!ref) return null; const id=typeof ref==='object'?(ref.uid||ref.objectId||ref.id):ref; if(!id) return null; const state=this.getState(); for(const side of ['player','ai']) for(const zone of ZONES){ const o=(state[side]?.[zone]||[]).find(x=>x?.uid===id||x?.objectId===id); if(o) return {object:o,side,zone}; } return null; }
  ownerOf(obj){ const f=this.find(obj); return obj?.owner||f?.object?.owner||f?.side||null; }
  controllerOf(obj){ const f=this.find(obj); return obj?.controller||f?.object?.controller||(f?.zone==='battlefield'?f.side:null); }
  remove(obj){ const f=this.find(obj); if(!f) return null; const a=this.getState()[f.side][f.zone],i=a.indexOf(f.object); if(i>=0)a.splice(i,1); return f; }
  move(obj,toZone,{toSide=null,controller=null,owner=null,reason='zoneChange'}={}) {
    if(!ZONES.includes(toZone)) throw new Error(`Zone inconnue: ${toZone}`);
    const before=this.find(obj); if(!before) throw new Error('Objet introuvable pour changement de zone.');
    const state=this.getState(), destinationSide=toSide||owner||before.side; if(!state[destinationSide]) throw new Error('Joueur de destination invalide.');
    if(this.replacements){ const r=this.replacements.replaceZoneChange({object:before.object,from:before.zone,to:toZone,fromSide:before.side,toSide:destinationSide,reason}); if(r?.replaced){toZone=r.zone;reason=r.reason;} }
    this.remove(before.object); const next={...before.object};
    next.zone=toZone; next.owner=next.owner||owner||before.side; next.controller=controller||(toZone==='battlefield'?(next.controller||destinationSide):next.controller);
    next.previousUid=before.object.uid || null; next.previousObjectId=before.object.objectId || null; next.zoneChangeId=nextId('zci'); next.objectId=nextId('obj'); next.uid=nextId(toZone==='battlefield'?'perm':'card'); next.zoneHistory=Array.isArray(before.object.zoneHistory)?[...before.object.zoneHistory]:[]; next.zoneHistory.push({zoneChangeId:next.zoneChangeId,from:before.zone,to:toZone,oldUid:before.object.uid||null,oldObjectId:before.object.objectId||null});
    if(toZone==='battlefield'){ next.enteredTurn=state.turnNumber||1; next.damageMarked=0; next.destroyed=false; next.attacking=false; next.blocking=false; next.attachedTo=next.attachedTo||null; }
    state[destinationSide][toZone].push(next);
    // Bug 10 : préserver attachedTo et mettre à jour les références externes
    next.attachedTo = before.object.attachedTo || null;
    for (const s of ['player', 'ai']) {
        for (const perm of state[s].battlefield) {
            if (perm.attachedTo === before.object.uid || perm.attachedTo === before.object.objectId) {
                perm.attachedTo = next.uid;
            }
        }
    }
    gameEvents.emit({type:'zoneChanged',object:next,from:before.zone,to:toZone,fromSide:before.side,toSide:destinationSide,reason,oldObjectId:before.object.objectId,zoneChangeId:next.zoneChangeId});
    return next;
  }
  enterBattlefield(card,side,{controller=side,reason='enterBattlefield'}={}) { const f=this.find(card); if(f){ const moved=this.move(card,'battlefield',{toSide:side,controller,reason}); moved.damageMarked=moved.damageMarked||0; return moved; } const copy=this.ensureIdentity({...card},{owner:card.owner||side,controller}); copy.zone='battlefield'; copy.enteredTurn=this.getState().turnNumber||1; copy.damageMarked=0; this.getState()[side].battlefield.push(copy); gameEvents.emit({type:'permanentEntered',permanent:copy,side,controller,source:card}); return copy; }
  moveToGraveyard(obj,o={}){return this.move(obj,'graveyard',{...o,reason:o.reason||'putIntoGraveyard'});}
  exile(obj,o={}){return this.move(obj,'exile',{...o,reason:o.reason||'exile'});}
  returnToHand(obj,o={}){return this.move(obj,'hand',{...o,reason:o.reason||'returnToHand'});}
}
