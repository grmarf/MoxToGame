// V9.4 — canonical ability model (M3 consolidation).
import { normalizeCost } from './costs/cost-system.js';
export const AbilityKind = Object.freeze({ STATIC:'static', ACTIVATED:'activated', TRIGGERED:'triggered', REPLACEMENT:'replacement' });

export function normalizeAbility(raw = {}, { source = null, controller = null } = {}) {
  if (!raw) return null;
  const kind = raw.kind || (raw.event ? AbilityKind.TRIGGERED : raw.cost !== undefined || raw.tap !== undefined || raw.manaAbility ? AbilityKind.ACTIVATED : raw.replacement ? AbilityKind.REPLACEMENT : AbilityKind.STATIC);
  return Object.freeze({
    id: raw.id || `${kind}_${source?.uid || source?.id || 'card'}_${raw.effect?.type || 'ability'}`,
    kind, source, controller,
    cost: raw.cost ?? '', costSpec: normalizeCost(raw.cost ?? '', raw), tap: !!raw.tap,
    manaAbility: !!raw.manaAbility,
    event: raw.event || null, condition: raw.condition || null,
    effect: raw.effect || null, effects: Array.isArray(raw.effects) ? raw.effects : (raw.effect ? [raw.effect] : []),
    mode: raw.mode || null, choices: raw.choices || null,
    targets: raw.targets || raw.target || null,
    description: raw.description || null,
    layer: raw.layer ?? null, duration: raw.duration || null,
    replacement: raw.replacement || null,
  });
}

export function getAbilities(source, controller = null) {
  if (!source) return [];
  const result = [];
  for (const a of (source.abilities || [])) result.push(normalizeAbility(a, { source, controller }));
  for (const a of (source.activated || [])) result.push(normalizeAbility(a, { source, controller }));
  if (source.tapAbility) {
    const ta = source.tapAbility;
    result.push(normalizeAbility({ ...ta, kind: AbilityKind.ACTIVATED, manaAbility: !!(ta.produces || ta.chooseColorAmount), tap: true, cost: { mana: ta.cost || '', tap: true, sacrifice: !!ta.sacrifice }, effect: ta.effect || null }, { source, controller }));
  }
  for (const a of (source.triggers || [])) result.push(normalizeAbility({ ...a, kind: AbilityKind.TRIGGERED }, { source, controller }));
  if (source.static) result.push(normalizeAbility({ ...source.static, kind: AbilityKind.STATIC }, { source, controller }));
  if (source.replacement) result.push(normalizeAbility({ ...source.replacement, kind: AbilityKind.REPLACEMENT }, { source, controller }));
  return result.filter(Boolean);
}

export function isAbilityLegal(ability, { permanent = null, state, controller, canPay, xValue = 0 } = {}) {
  if (!ability) return false;
  if (ability.controller && ability.controller !== controller) return false;
  if (ability.tap && permanent?.tapped) return false;
  if (ability.cost && !canPay(state[controller], ability.cost, xValue)) return false;
  return true;
}
