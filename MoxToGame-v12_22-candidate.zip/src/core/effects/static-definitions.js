// C8.2 — static/conditional characteristics and combat restrictions.
// Kept as data-driven definitions so the engine does not accumulate card-specific branches.
export function applyC82Definition(c) {
  if (!c?.name || c.__c82Applied) return c;
  const existing = Array.isArray(c.static) ? c.static : (c.static ? [c.static] : []);
  if (existing.length && ['Nightmare','Plague Rats','Beast of Burden','Keldon Warlord',"Gaea's Liege",'Lifeforce','Gloom','Smoke','Stasis',"Tawnos's Wand",'Lure','Hidden Path','Zombie Master',"Titania's Song",'Colossus of Sardia','Juggernaut','Erg Raiders','Orgg'].includes(c.name)) { c.__c82Applied=true; return c; }
  c.__c82Applied = true;
  const n=c.name;
  const S=(effect)=>{ c.static=Array.isArray(c.static)?[...c.static,effect]:[effect]; };
  const K=(effect)=>S(effect);
  if(n==='Nightmare') K({type:'dynamicPT', powerSource:'basicLandCount', landType:'Swamp', controller:'self'});
  if(n==='Plague Rats') K({type:'dynamicPT', powerSource:'subtypeCount', subtype:'Rat', controller:'all', per:1});
  if(n==='Beast of Burden') K({type:'dynamicPT', powerSource:'creatureCount', controller:'all', per:1});
  if(n==='Keldon Warlord') K({type:'dynamicPT', powerSource:'creatureCount', controller:'self', per:1});
  if(n==='Gaea\'s Liege') K({type:'dynamicPT', powerSource:'basicLandCount', landType:'Forest', controller:'self'});
  if(n==='Lifeforce') K({type:'spellCostIncrease', filterColor:'B', amount:2});
  if(n==='Gloom') K({type:'spellCostIncrease', filterColor:'W', amount:3});
  if(n==='Smoke') K({type:'cantUntapCreatures', controller:'all'});
  if(n==='Stasis') K({type:'skipUntapPhase', controller:'all'});
  if(n==='Tawnos\'s Wand') K({type:'unblockableIfPowerAtMost', power:1, controller:'all'});
  if(n==='Lure') K({type:'mustBlock', sourceOnly:true});
  if(n==='Hidden Path') K({type:'grantKeyword', filterColor:'G', keyword:'forestwalk', controllerFilter:'any'});
  if(n==='Zombie Master') K({type:'grantKeyword', filterSubtype:'Zombie', keyword:'regenerate'});
  if(n==='Goblin War Drums') K({type:'grantKeyword', filterSubtype:'Goblin', keyword:'trample'});
  if(n==='Titania\'s Song') K({type:'animateArtifacts', power:4, toughness:4});
  if(n==='Colossus of Sardia') K({type:'cantBlock'});
  if(n==='Juggernaut') K({type:'mustAttack'});
  if(n==='Erg Raiders') K({type:'mustAttack'});
  if(n==='Orgg') K({type:'attackRestriction', condition:'defenderControlsUntappedCreature'});
  return c;
}
