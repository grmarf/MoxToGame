// V9.0 — fallback handlers for every effect descriptor present in the card database.
export function registerExtendedEffects(registry) {
  const reg = (type, fn) => { if (!registry.has(type)) registry.register(type, fn); };
  reg('unblockable', (ctx) => { const t = ctx.api?.findPermanent?.(ctx.targetInfo?.uid || ctx.targetInfo?.perm || ctx.targetInfo); if (t) t.tempKeywords = [...new Set([...(t.tempKeywords || []), 'unblockable'])]; });
  reg('spiritLink', (ctx) => { const t = ctx.api?.findPermanent?.(ctx.targetInfo?.uid || ctx.targetInfo?.perm || ctx.targetInfo); if (t) t.spiritLink = true; });
  // V12.19 (fix provisoire, PAS une correction complète) : pumpAttacking a été
  // retiré à tort lors du nettoyage v12.19 -- type unique, non dupliqué
  // ailleurs, utilisé par une carte réelle (Warrior's Charge, id 230, "Vos
  // créatures attaquantes +1/+0"). Son absence rendait la résolution du sort
  // un no-op totalement silencieux (stack.js:194 -- effects.has() échoue en
  // amont, aucune erreur levée, aucun log). Ce ré-enregistrement évite ce
  // no-op muet, MAIS NE RÉSOUT PAS LE FOND : l'état de combat
  // (CombatService#combat.attackers) n'est jamais exposé à `state` ni à
  // l'API construite pour la résolution de pile (#buildApi dans stack.js) --
  // aucun handler d'effet n'a de moyen fiable de savoir quelles créatures
  // attaquent au moment de la résolution. La condition p.attacking ci-dessous
  // est un espace réservé qui ne sera jamais vrai en l'état actuel du moteur.
  // À CORRIGER PAR KIMI : exposer l'état de combat courant (au minimum la
  // liste des uid attaquants) à travers ctx.state.combat ou ctx.api.combat,
  // puis remplacer la condition ci-dessous par une vérification réelle.
  reg('pumpAttacking', (ctx, effect) => {
    const controller = ctx.controllerKey;
    const combat = ctx.api?.combat;
    const attackingUids = combat?.attackers || [];
    const perms = ctx.api?.allPermanents ? ctx.api.allPermanents() : (ctx.state?.[controller]?.battlefield || []);
    for (const p of perms) {
      if (p.owner !== controller && p.controller !== controller) continue;
      if (!attackingUids.includes(p.uid)) continue;
      p.tempBuffs = p.tempBuffs || [];
      p.tempBuffs.push({ power: effect?.power ?? 0, toughness: effect?.toughness ?? 0, untilEndOfTurn: true });
    }
  });
}

// ─────────────────────────────────────────────
// C1/C2/C3 — keyword and activated-ability primitives
// ─────────────────────────────────────────────
const __mtg92Target = (ctx) => {
  const t = ctx.targetInfo;
  if (t?.kind === 'permanent') return t.perm;
  if (t?.uid) return ctx.api.allPermanents().find(p => p.uid === t.uid) || null;
  return null;
};

export function registerC123Effects(registry) {
  const reg = (type, fn) => { if (!registry.has(type)) registry.register(type, fn); };
  reg('untapTarget', ctx => { const t=__mtg92Target(ctx); if(t)t.tapped=false; });
  reg('sacrifice', ctx => { const t=__mtg92Target(ctx); if(t)ctx.api.destroyPermanent(t); });
}
