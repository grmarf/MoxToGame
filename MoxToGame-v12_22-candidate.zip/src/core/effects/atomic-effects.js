/**
 * V8.2 atomic effect implementations.
 * These handlers deliberately depend only on a small engine context supplied by the
 * compatibility adapter. They contain no DOM code.
 */
const amountOf = (effect, xValue) => effect.amount === 'X' ? (xValue || 0) : effect.amount;
const targetPermanent = (target, api) => {
  if (!target || target.kind !== 'permanent') return null;
  const uid = target.uid || target.perm?.uid || target.id;
  if (!uid) return target.perm || null;
  const resolved = api?.findPermanent?.(uid);
  return resolved || null;
};

export function registerAtomicEffects(registry) {
  registry.register('damage', (ctx, effect) => {
    const { targetInfo, sourceCard, controllerKey, xValue, api } = ctx;
    const amount = amountOf(effect, xValue);
    const target = targetPermanent(targetInfo, api);
    if (target) {
      const side = api.findPermSide(target);
      const result = api.applyDamageToPermanent ? api.applyDamageToPermanent(target, amount, { color: sourceCard?.color?.[0] || null, source: sourceCard, meta:{ combat:!!ctx.combatDamage } }) : api.preventDamage(side, amount, sourceCard?.color?.[0] || null, sourceCard, {targetType:'permanent', targetController:target.controller || side, combat:!!ctx.combatDamage});
      const prevented = result.prevented !== undefined ? { remaining: result.amount, prevented: result.prevented } : result;
      api.log(`${sourceCard.name} inflige ${amount} blessures à ${target.name}.`, controllerKey);
      api.checkStateBasedDeaths();
    } else if (targetInfo?.kind === 'player') {
      const result = api.applyDamageToPlayer ? api.applyDamageToPlayer(targetInfo.side, amount, { color: sourceCard?.color?.[0] || null, source: sourceCard, meta:{ combat: !!ctx.combatDamage } }) : null;
      const prevented = result ? { remaining: result.amount, prevented: result.prevented } : api.preventDamage(targetInfo.side, amount, sourceCard?.color?.[0] || null, sourceCard, {targetType:'player', targetController:targetInfo.side, combat:!!ctx.combatDamage});
      if (!result) { const life = api.replaceDamageLifeLoss ? api.replaceDamageLifeLoss(targetInfo.side, prevented.remaining, { source: sourceCard, combat: !!ctx.combatDamage }) : { loss: prevented.remaining }; api.state[targetInfo.side].life -= life.loss; }
      api.log(`${sourceCard.name} inflige ${amount} blessures à ${targetInfo.side === 'player' ? 'vous' : "l'IA"}.`, controllerKey);
    }
  });

  registry.register('destroy', (ctx) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (target) { ctx.api.log(`${ctx.sourceCard.name} détruit ${target.name}.`, ctx.controllerKey); ctx.api.destroyPermanent(target); }
  });

  registry.register('exile', (ctx, effect) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    const side = ctx.api.findPermSide(target);
    if (effect.lifegainFromPower) {
      const pt = ctx.api.effectivePT(target, side);
      ctx.api.state[side].life += Math.max(0, pt.power);
    }
    if (ctx.api.zones) ctx.api.zones.move(target, 'exile', { toSide: target.owner || side, reason: 'effectExile' });
    else { ctx.api.state[side].battlefield = ctx.api.state[side].battlefield.filter(p => p !== target); ctx.api.state[side].exile.push(target); }
    ctx.api.log(`${target.name} est exilé par ${ctx.sourceCard.name}.`, ctx.controllerKey);
  });

  registry.register('bounce', (ctx) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    const side = ctx.api.findPermSide(target);
    if (ctx.api.zones) ctx.api.zones.move(target, 'hand', { toSide: target.owner || side, reason: 'effectBounce' });
    else { ctx.api.state[side].battlefield = ctx.api.state[side].battlefield.filter(p => p !== target); ctx.api.state[side].hand.push(target); }
    ctx.api.log(`${target.name} retourne en main (${side === 'player' ? 'vous' : 'IA'}).`, ctx.controllerKey);
  });

  registry.register('draw', (ctx, effect) => {
    const amount = amountOf(effect, ctx.xValue);
    for (let i = 0; i < amount; i++) {
      if (ctx.api.drawCard) ctx.api.drawCard(ctx.controllerKey); else if (ctx.api.state[ctx.controllerKey].library.length > 0) ctx.api.state[ctx.controllerKey].hand.push(ctx.api.state[ctx.controllerKey].library.pop());
    }
    ctx.api.log(`${ctx.controllerKey === 'player' ? 'Vous piochez' : "L'IA pioche"} ${amount} carte(s).`, ctx.controllerKey);
  });

  registry.register('discard', (ctx, effect) => {
    const target = effect.target === 'opponent' ? ctx.api.opponentKey(ctx.controllerKey) : ctx.controllerKey;
    for (let i = 0; i < effect.amount && ctx.api.state[target].hand.length > 0; i++) {
      const idx = Math.floor(Math.random() * ctx.api.state[target].hand.length);
      const card = ctx.api.state[target].hand[idx];
      if (ctx.api.zones) ctx.api.zones.move(card, 'graveyard', { toSide: card.owner || target, reason: 'effectDiscard' });
      else ctx.api.state[target].graveyard.push(ctx.api.state[target].hand.splice(idx, 1)[0]);
    }
    ctx.api.log(`${target === 'player' ? 'Vous défaussez' : "L'IA défausse"} ${effect.amount} carte(s).`, ctx.controllerKey);
  });

  registry.register('discardRandom', (ctx, effect) => {
    const amount = effect?.amount === 'X' ? (ctx.xValue || 0) : (effect?.amount || 1);
    const target = effect?.target === 'opponent' ? (ctx.controllerKey === 'player' ? 'ai' : 'player') : ctx.controllerKey;
    for (let i = 0; i < amount; i++) {
      const hand = ctx.api.state[target].hand;
      if (hand.length === 0) break;
      const idx = Math.floor(Math.random() * hand.length);
      const card = hand[idx];
      let moved = false;
      if (ctx.api.zones) {
        try {
          ctx.api.zones.move(card, 'graveyard', { toSide: card.owner || target, reason: 'effectDiscardRandom' });
          moved = true;
        } catch (e) {
          // Fallback si l'objet n'a pas d'identifiant stable pour ZoneManager
        }
      }
      if (!moved) {
        hand.splice(idx, 1);
        ctx.api.state[target].graveyard.push(card);
      }
      ctx.api.log(`${target === 'player' ? 'Vous défaussez' : "L'IA défausse"} ${card.name} au hasard.`, ctx.controllerKey);
    }
  });

  registry.register('gainLife', (ctx, effect) => {
    const amount = effect.amount === 'X' ? (ctx.xValue || 0) : effect.amount;
    const target = effect.target === 'self' ? ctx.controllerKey : (ctx.targetInfo?.side || ctx.controllerKey);
    ctx.api.state[target].life += amount;
    ctx.api.log(`${target === 'player' ? 'Vous gagnez' : "L'IA gagne"} ${amount} PV.`, ctx.controllerKey);
  });

  registry.register('pump', (ctx, effect) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    if (effect.permanentAura) return;
    target.tempBuffs.push({ power: effect.power, toughness: effect.toughness });
    ctx.api.log(`${target.name} ${effect.power >= 0 ? 'gagne' : 'perd'} ${Math.abs(effect.power)}/${Math.abs(effect.toughness)}.`, ctx.controllerKey);
  });

  registry.register('pumpSelf', (ctx, effect) => {
    if (!ctx.sourceCard.tempBuffs) ctx.sourceCard.tempBuffs = [];
    ctx.sourceCard.tempBuffs.push({ power: effect.power, toughness: effect.toughness });
    ctx.api.log(`${ctx.sourceCard.name} gagne ${effect.power}/${effect.toughness} jusqu'à la fin du tour.`, ctx.controllerKey);
  });

  registry.register('destroyAllCreatures', (ctx) => {
    ctx.api.allPermanents().filter(p => p.type.includes('Creature')).forEach(p => { p.regenShield = false; ctx.api.destroyPermanent(p); });
    ctx.api.log('Toutes les créatures sont détruites.', 'system');
  });

  registry.register('destroyAllLands', (ctx, effect) => {
    let targets = ctx.api.allPermanents().filter(p => p.type.includes('Land'));
    if (effect?.filter) {
      targets = targets.filter(p => String(p.type || '').includes(effect.filter) || String(p.name || '').includes(effect.filter));
    }
    targets.forEach(p => ctx.api.destroyPermanent(p));
    ctx.api.log(`${effect?.filter ? effect.filter + 's' : 'Tous les terrains'} détruits.`, 'system');
  });

  registry.register('destroyAllEnchantments', (ctx) => {
    ctx.api.allPermanents().filter(p => p.type.includes('Enchantment')).forEach(p => ctx.api.destroyPermanent(p));
    ctx.api.log(`${ctx.sourceCard.name} détruit tous les enchantements.`, 'system');
  });

  registry.register('damageAllCreaturesAndPlayers', (ctx, effect) => {
    const amount = amountOf(effect, ctx.xValue);
    const colors = ctx.sourceCard?.color || [];
    ctx.api.allPermanents().filter(p => p.type.includes('Creature')).forEach(p => {
      if (ctx.api.hasProtectionFromColors(p, colors)) {
        ctx.api.log(`${p.name} est protégée : blessures de ${ctx.sourceCard.name} prévenues.`, 'system');
        return;
      }
      p.damageMarked = (p.damageMarked || 0) + amount;
    });
    for (const side of ['player','ai']) { const life = ctx.api.replaceDamageLifeLoss ? ctx.api.replaceDamageLifeLoss(side, amount, { source: ctx.sourceCard }) : { loss: amount }; ctx.api.state[side].life -= life.loss; }
    ctx.api.log(`${ctx.sourceCard.name} inflige ${amount} blessure(s) à toutes les créatures et à chaque joueur.`, 'system');
    ctx.api.checkStateBasedDeaths();
  });

  registry.register('extraTurn', (ctx) => {
    ctx.api.state.extraTurnFor = ctx.controllerKey;
    ctx.api.log(`${ctx.controllerKey === 'player' ? 'Vous prendrez' : "L'IA prendra"} un tour supplémentaire.`, ctx.controllerKey);
  });

  registry.register('wheel', (ctx) => {
    for (const side of ['player', 'ai']) {
      const s = ctx.api.state[side];
      s.library.push(...s.hand, ...s.graveyard);
      s.hand = []; s.graveyard = [];
      s.library = ctx.api.shuffle(s.library);
      for (let i = 0; i < 7; i++) if (s.library.length) s.hand.push(s.library.pop());
    }
    ctx.api.log('Chaque joueur mélange sa main et son cimetière puis pioche 7 cartes.', 'system');
  });

  registry.register('mana', (ctx, effect) => {
    ctx.api.state[ctx.controllerKey].mana[effect.color] = (ctx.api.state[ctx.controllerKey].mana[effect.color] || 0) + effect.amount;
    ctx.api.log(`+${effect.amount}{${effect.color}} ajouté.`, ctx.controllerKey);
  });

  registry.register('regenerateShield', (ctx) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (target) { target.regenShield = true; ctx.api.log(`${target.name} obtient un bouclier de régénération.`, ctx.controllerKey); }
  });

  registry.register('fog', (ctx) => {
    ctx.api.state.fogActive = true;
    ctx.api.log('Tous les dégâts de combat seront prévenus ce tour-ci.', ctx.controllerKey);
  });

  registry.register('tapTarget', (ctx, effect) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    const shouldTap = effect?.tap !== false;
    target.tapped = shouldTap;
    ctx.api.log(`${target.name} est ${shouldTap ? 'engagé' : 'désengagé'} par ${ctx.sourceCard?.name || 'ability'}.`, ctx.controllerKey);
  });

  registry.register('tapOrUntap', (ctx) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (target) { target.tapped = !target.tapped; ctx.api.log(`${target.name} est ${target.tapped ? 'engagé' : 'dégagé'} par ${ctx.sourceCard.name}.`, ctx.controllerKey); }
  });

  registry.register('removeKeyword', (ctx, effect) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    const kw = effect.keyword;
    if (target.keywords) {
      target.keywords = target.keywords.filter(k => k !== kw);
    }
    ctx.api.log(`${target.name} perd ${kw}.`, ctx.controllerKey);
  });

  registry.register('stealCreature', (ctx) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    const side = ctx.api.findPermSide(target);
    ctx.api.state[side].battlefield = ctx.api.state[side].battlefield.filter(p => p !== target);
    ctx.api.state[ctx.controllerKey].battlefield.push(target);
    ctx.api.log(`${ctx.controllerKey === 'player' ? 'Vous prenez' : "L'IA prend"} le contrôle de ${target.name}.`, ctx.controllerKey);
  });

  registry.register('reanimate', (ctx, effect) => {
    if (ctx.targetInfo?.kind !== 'graveyardCard') return;
    const side = ctx.targetInfo.side;
    const card = ctx.targetInfo.card;
    if (ctx.api.zones) {
      ctx.api.zones.move(card, 'battlefield', { toSide: ctx.controllerKey, controller: ctx.controllerKey, reason: 'reanimate' });
    } else {
      ctx.api.state[side].graveyard = ctx.api.state[side].graveyard.filter(c => c !== card);
      const perm = ctx.api.makePermFromCard(card);
      perm.uid = ctx.api.uid();
      perm.auraBuffs.push({ power: effect.powerMod || 0, toughness: 0 });
      ctx.api.state[ctx.controllerKey].battlefield.push(perm);
    }
    ctx.api.log(`${card.name} est ramené sur le champ de bataille sous le contrôle de ${ctx.controllerKey === 'player' ? 'vous' : "l'IA"}.`, ctx.controllerKey);
  });

  registry.register('returnFromGraveyard', (ctx, effect) => {
    const gy = ctx.api.state[ctx.controllerKey].graveyard;
    if (!gy.length) return;
    let card = null;
    if (ctx.targetInfo?.kind === 'graveyardCard') {
      card = ctx.targetInfo.card;
    } else if (effect?.filter === 'Creature') {
      card = gy.find(c => String(c.type || '').includes('Creature'));
    } else {
      card = gy[0];
    }
    if (!card) return;
    if (ctx.api.zones) ctx.api.zones.move(card, 'hand', { toSide: ctx.controllerKey, reason: 'returnFromGraveyard' });
    else {
      ctx.api.state[ctx.controllerKey].graveyard = ctx.api.state[ctx.controllerKey].graveyard.filter(c => c !== card);
      ctx.api.state[ctx.controllerKey].hand.push(card);
    }
    ctx.api.log(`${card.name} revient en main.`, ctx.controllerKey);
  });

  registry.register('addKeyword', (ctx, effect) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (!target) return;
    if (effect.permanentAura) return;
    target.tempKeywords = target.tempKeywords || [];
    if (!target.tempKeywords.includes(effect.keyword)) target.tempKeywords.push(effect.keyword);
  });

  registry.register('addKeywordUntilEnd', (ctx, effect) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api) || (ctx.sourceCard?.uid ? ctx.sourceCard : null);
    if (!target) return;
    target.tempKeywords = target.tempKeywords || [];
    if (!target.tempKeywords.includes(effect.keyword)) target.tempKeywords.push(effect.keyword);
    ctx.api.log(`${target.name} gagne ${effect.keyword} jusqu'à la fin du tour.`, ctx.controllerKey);
  });

  registry.register('cantBlock', (ctx) => {
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (target) { target.cantBlockThisTurn = true; ctx.api.log(`${target.name} ne peut plus bloquer ce tour-ci.`, ctx.controllerKey); }
  });

  registry.register('drainLife', (ctx, effect) => {
    const amount = amountOf(effect, ctx.xValue);
    const target = targetPermanent(ctx.targetInfo, ctx.api);
    if (target) { target.damageMarked = (target.damageMarked || 0) + amount; ctx.api.checkStateBasedDeaths(); }
    else if (ctx.targetInfo?.kind === 'player') { if (ctx.api.applyDamageToPlayer) ctx.api.applyDamageToPlayer(ctx.targetInfo.side, amount, {color:ctx.sourceCard?.color?.[0]||null,source:ctx.sourceCard,meta:{effect:'drainLife'}}); else { const life = ctx.api.replaceDamageLifeLoss ? ctx.api.replaceDamageLifeLoss(ctx.targetInfo.side, amount, { source: ctx.sourceCard }) : { loss: amount }; ctx.api.state[ctx.targetInfo.side].life -= life.loss; } }
    ctx.api.state[ctx.controllerKey].life += amount;
    ctx.api.log(`${ctx.sourceCard.name} draine ${amount} PV.`, ctx.controllerKey);
  });


  // ============================================================
  // LOT E : Effets legacy migrés vers natif V8.16
  // ============================================================

  // ── Contre-sorts ──
  registry.register('counterSpell', (ctx, effect) => {
    const { controllerKey, sourceCard, api, targetInfo } = ctx;
    if (targetInfo && targetInfo._kind === 'stackItem') {
      const removed = api.removeStackItem(targetInfo.id);
      if (removed) {
        ctx.state[removed.controller].graveyard.push(removed.source);
        api.log(`${removed.source.name} est contrecarré par ${sourceCard.name} !`, controllerKey);
      } else {
        api.log(`${sourceCard.name} n'a plus de cible légale : sans effet.`, controllerKey);
      }
    } else {
      api.log(`${sourceCard.name} n'a pas de cible : sans effet.`, controllerKey);
    }
  });

  registry.register('counterCMC', (ctx, effect) => {
    const { controllerKey, sourceCard, api, targetInfo, xValue } = ctx;
    if (targetInfo && targetInfo._kind === 'stackItem') {
      const targetCmc = targetInfo.source?.cmc || 0;
      const requiredCmc = effect.amount === 'X' ? (xValue || 0) : (effect.amount || 0);
      if (targetCmc !== requiredCmc) {
        api.log(`${sourceCard.name} : CMC de la cible (${targetCmc}) différent de ${requiredCmc}. Sans effet.`, controllerKey);
        return;
      }
      const removed = api.removeStackItem(targetInfo.id);
      if (removed) {
        ctx.state[removed.controller].graveyard.push(removed.source);
        api.log(`${removed.source.name} est contrecarré par ${sourceCard.name} !`, controllerKey);
      } else {
        api.log(`${sourceCard.name} n'a plus de cible légale : sans effet.`, controllerKey);
      }
    } else {
      api.log(`${sourceCard.name} n'a pas de cible : sans effet.`, controllerKey);
    }
  });

  registry.register('counterSpellColor', (ctx, effect) => {
    const { controllerKey, sourceCard, api, targetInfo } = ctx;
    if (targetInfo && targetInfo._kind === 'stackItem') {
      const targetColors = targetInfo.source?.color || [];
      const requiredColor = effect.color;
      if (requiredColor && !targetColors.includes(requiredColor)) {
        api.log(`${sourceCard.name} : la cible n'est pas de la couleur ${requiredColor}. Sans effet.`, controllerKey);
        return;
      }
      const removed = api.removeStackItem(targetInfo.id);
      if (removed) {
        ctx.state[removed.controller].graveyard.push(removed.source);
        api.log(`${removed.source.name} est contrecarré par ${sourceCard.name} !`, controllerKey);
      } else {
        api.log(`${sourceCard.name} n'a plus de cible légale : sans effet.`, controllerKey);
      }
    } else {
      api.log(`${sourceCard.name} n'a pas de cible : sans effet.`, controllerKey);
    }
  });

  registry.register('counterUnlessPay', (ctx, effect) => {
    const { state, controllerKey, sourceCard, api, targetInfo, xValue } = ctx;
    if (targetInfo && targetInfo._kind === 'stackItem') {
      const target = api.findStackItem(targetInfo.id);
      if (!target) {
        api.log(`${sourceCard.name} n'a plus de cible légale : sans effet.`, controllerKey);
        return;
      }
      const amount = effect.amount === 'X' ? (xValue || 0) : (effect.amount || 0);
      const targetController = target.controller;
      let paid = false;
      if (amount <= 0) {
        paid = true;
      } else if (targetController === 'ai') {
        paid = api.totalMana(state.ai.mana) >= amount;
        if (paid) api.payGenericFromPool(state.ai, amount);
      } else {
        const canAfford = api.totalMana(state.player.mana) >= amount;
        paid = canAfford;
        if (paid) api.payGenericFromPool(state.player, amount);
      }
      if (paid) {
        api.log(`${target.source.name} n'est pas contrecarré : le coût de ${amount} a été payé.`, controllerKey);
      } else {
        const removed = api.removeStackItem(targetInfo.id);
        if (removed) {
          state[removed.controller].graveyard.push(removed.source);
          api.log(`${removed.source.name} est contrecarré par ${sourceCard.name} (coût non payé) !`, controllerKey);
        }
      }
    } else {
      api.log(`${sourceCard.name} n'a pas de cible : sans effet.`, controllerKey);
    }
  });

  // ── Dégâts & destructions spécifiques ──
  registry.register('damageAndGain', (ctx, effect) => {
    const amount = effect.amount || 0;
    const { state, controllerKey, api, targetInfo } = ctx;
    if (targetInfo?.kind === 'player') {
      const side = targetInfo.side || targetInfo.id;
      state[side].life -= amount;
      state[controllerKey].life += amount;
      api.log(`${side === 'player' ? 'Vous' : "L'IA"} subit ${amount} dégâts. Vous gagnez ${amount} PV.`, controllerKey);
      return;
    }
    const target = targetPermanent(targetInfo, api);
    if (target) {
      target.damageMarked = (target.damageMarked || 0) + amount;
      api.checkStateBasedDeaths();
    }
    state[controllerKey].life += amount;
    api.log(`${controllerKey === 'player' ? 'Vous' : "L'IA"} gagne ${amount} PV.`, controllerKey);
  });

  registry.register('damageToFliersAndPlayers', (ctx, effect) => {
    const { state, sourceCard, api, xValue } = ctx;
    const amount = effect.amount === 'X' ? (xValue || 0) : (effect.amount || 0);
    const allPerms = api.allPermanents();
    allPerms.forEach(p => {
      if (String(p.type || '').includes('Creature') && api.effectiveKeywords(p).includes('flying')) {
        if (api.hasProtectionFromColors(p, sourceCard.color || [])) return;
        p.damageMarked = (p.damageMarked || 0) + amount;
      }
    });
    for (const side of ['player','ai']) { if (ctx.api.applyDamageToPlayer) ctx.api.applyDamageToPlayer(side, amount, {color:ctx.sourceCard?.color?.[0]||null,source:ctx.sourceCard,meta:{effect:'damageAllCreaturesAndPlayers'}}); else { const life = ctx.api.replaceDamageLifeLoss ? ctx.api.replaceDamageLifeLoss(side, amount, { source: ctx.sourceCard }) : { loss: amount }; state[side].life -= life.loss; } }
    api.log(`${sourceCard.name} inflige ${amount} blessures aux créatures avec vol et à chaque joueur.`, 'system');
    api.checkStateBasedDeaths();
  });

  registry.register('destroyRandomPermanent', (ctx, effect) => {
    const { controllerKey, sourceCard, api } = ctx;
    const pool = api.allPermanents();
    if (pool.length > 0) {
      const target = pool[Math.floor(Math.random() * pool.length)];
      api.log(`${sourceCard.name} détruit ${target.name} au hasard.`, controllerKey);
      api.destroyPermanent(target);
    }
  });

  registry.register('destroyXMountains', (ctx, effect) => {
    const { controllerKey, sourceCard, api, xValue } = ctx;
    const amount = effect.amount === 'X' ? (xValue || 0) : (effect.amount || 0);
    const mountains = api.allPermanents().filter(p => p.subtype === 'Mountain');
    mountains.slice(0, amount).forEach(m => api.destroyPermanent(m));
    api.log(`${sourceCard.name} détruit ${Math.min(amount, mountains.length)} Montagne(s).`, controllerKey);
  });

  registry.register('emptyManaPool', (ctx, effect) => {
    const { state, controllerKey, sourceCard, api } = ctx;
    const target = api.opponentKey(controllerKey);
    const emptied = api.totalMana(state[target].mana);
    for (const c in state[target].mana) state[target].mana[c] = 0;
    api.log(`${sourceCard.name} vide la réserve de mana adverse (${emptied} mana perdu).`, controllerKey);
  });

  registry.register('gainLifePerCreature', (ctx, effect) => {
    const { state, controllerKey, api } = ctx;
    const count = state[controllerKey].battlefield.filter(p => String(p.type || '').includes('Creature')).length;
    const gain = count * (effect.multiplier || 2);
    state[controllerKey].life += gain;
    api.log(`${controllerKey === 'player' ? 'Vous gagnez' : "L'IA gagne"} ${gain} PV (${effect.multiplier || 2} par créature contrôlée).`, controllerKey);
  });

  // ── Tutor (recherche en bibliothèque) ──
  registry.register('tutor', (ctx, effect) => {
    const { state, controllerKey, api, targetInfo, sourceCard } = ctx;
    const lib = state[controllerKey].library;
    if (targetInfo && targetInfo._kind === 'libraryCard') {
      const idx = lib.findIndex(c => c.uid === targetInfo.uid);
      if (idx >= 0) {
        const [picked] = lib.splice(idx, 1);
        state[controllerKey].hand.push(picked);
        api.log(`${controllerKey === 'player' ? 'Vous cherchez' : "L'IA cherche"} ${picked.name} et le met en main.`, controllerKey);
      } else {
        api.log(`${sourceCard.name} : carte non trouvée dans la bibliothèque.`, controllerKey);
      }
    } else {
      if (lib.length > 0) {
        const best = [...lib].sort((a, b) => (b.cmc || 0) - (a.cmc || 0))[0];
        const idx = lib.indexOf(best);
        if (idx >= 0) {
          lib.splice(idx, 1);
          state[controllerKey].hand.push(best);
          api.log(`${controllerKey === 'player' ? 'Vous cherchez' : "L'IA cherche"} ${best.name} et le met en main.`, controllerKey);
        }
      } else {
        api.log(`${controllerKey === 'player' ? 'Vous ne trouvez' : "L'IA ne trouve"} rien.`, controllerKey);
      }
    }
    state[controllerKey].library = api.shuffle(state[controllerKey].library);
    api.log(`${controllerKey === 'player' ? 'Votre bibliothèque est' : "La bibliothèque de l'IA est"} mélangée.`, 'system');
  });

  return registry;
}
