// V12.3 — C6: card-facing replacement & prevention rules.
// All prevention effects now flow through ReplacementService.addPreventionShield.
// The legacy global flag `combatDamagePreventedUntilCleanup` has been removed
// in favour of a canonical shield with combatOnly=true and until='cleanup'.
import { gameEvents } from '../event-bus.js';

const sides = ['player','ai'];
const isCreature = p => /(^|\s|—)Creature\b/i.test(String(p?.type || ''));
const isFlying = p => !!p?.flying || !!p?.keywords?.flying || /(^|[\s,])flying([\s,]|$)/i.test(String(p?.keywords || ''));

function allBattlefield(state) { return sides.flatMap(s => state[s]?.battlefield || []); }

export function registerC6Effects(registry) {
  const reg = (type, fn) => { if (!registry.has(type)) registry.register(type, fn); };

  // Circle of Protection cycle: creates a one-shot shield filtered by source color.
  reg('preventNextDamageFromColor', (ctx, effect) => {
    ctx.api.replacements?.addPreventionShield(ctx.controllerKey, {
      amount: Number(effect.amount || 999999),
      color: effect.color || null,
      source: null,
      scope: 'controller',
      until: 'nextMatchingDamage'
    });
  });

  // Artifact version: the database uses a fixed 2-damage shield.
  reg('preventNextTwoDamageFromArtifact', (ctx) => {
    ctx.api.replacements?.addPreventionShield(ctx.controllerKey, {
      amount: 2, sourceType: 'Artifact', scope: 'controller', until: 'nextMatchingDamage'
    });
  });

  // Fog: combat-only prevention shield applied globally to both sides.
  // V12.3 — migrated from global flag to canonical shield.
  reg('preventCombatDamage', (ctx) => {
    for (const side of sides) {
      ctx.api.replacements?.addPreventionShield(side, {
        amount: 999999,
        scope: 'controllerAndCreatures',
        combatOnly: true,
        until: 'cleanup'
      });
    }
  });

  // Reverse Damage: prevent damage to controller and creatures controlled by them
  // for the current turn, then gain life equal to damage prevented.
  reg('reverseDamage', (ctx) => {
    const s = ctx.controllerKey;
    ctx.api.replacements?.addPreventionShield(s, {
      amount: 999999,
      scope: 'controllerAndCreatures',
      until: 'cleanup',
      gainLife: true
    });
  });

  // Island Sanctuary: non-flying creatures cannot deal combat damage to its controller.
  reg('preventDamageFromNonFlying', (ctx) => {
    const controller = ctx.controllerKey;
    ctx.api.replacements?.addPreventionShield(controller, {
      amount: 999999,
      sourceType: 'Creature',
      nonFlyingOnly: true,
      combatOnly: true,
      scope: 'controller',
      persistent: true
    });
  });

  // Static protection helper used by White Ward and similar cards.
  // V12.3 — kept as marker; full 702.16 semantics are Phase-2 work.
  reg('addProtection', (ctx, effect) => {
    const target = ctx.api.findPermanent?.(ctx.targetInfo?.uid || ctx.targetInfo?.perm || ctx.targetInfo);
    if (!target) return;
    target.protectionFrom = Array.from(new Set([...(target.protectionFrom || []), effect.color].filter(Boolean)));
  });

  // Generic regeneration shield remains compatible with the SBA implementation.
  reg('regenerateShield', (ctx) => {
    const target = ctx.api.findPermanent?.(ctx.targetInfo?.uid || ctx.targetInfo?.perm || ctx.targetInfo);
    if (target) target.regenShield = true;
  });
}

export function installC6EventRules() {
  gameEvents.on('cleanupStarted', ({state}) => {
    if (!state) return;
    // V12.3 — global flag removed; shields with until='cleanup' are purged
    // by the existing prevention-filter logic in ReplacementService.
    for (const side of sides) {
      const shields = Array.isArray(state[side].prevention) ? state[side].prevention : [];
      state[side].prevention = shields.filter(s => s.persistent || s.until !== 'cleanup');
    }
  });
}
