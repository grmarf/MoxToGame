// C8.1 structured definitions for the first choice/search/copy tranche.
export function applyC81Definition(c) {
  if (!c?.name || c.__c81Applied) return c;
  c.__c81Applied = true;
  const name = c.name;
  if (name === 'Hypnotic Specter') c.triggers = [{ event:'damageDealt', condition:{ targetType:'player', sourceSelf:true }, effect:{type:'randomDiscard', target:'opponent', amount:1} }];
  if (name === 'Clone') c.effect = {type:'copyPermanent', targetType:'creature', copiable:true};
  if (name === 'Vesuvan Doppelganger') { c.effect = {type:'copyPermanent', targetType:'creature', copiable:true}; c.triggers = [{ event:'upkeepStarted', condition:{controllerUpkeep:true, sourceSelf:true}, effect:{type:'copyPermanent', targetType:'creature', copiable:true, retargetSource:true} }]; }
  if (name === 'Fork') c.effect = {type:'copySpell', targetType:'instantOrSorcery', chooseNewTargets:true};
  if (name === "Aladdin's Lamp" || name === "Ring of Ma'rûf") c.activated = [{cost:'{5}', effect:{type:'searchLibrary'}}];
  if (name === 'Natural Selection') c.effect = {type:'lookTop', amount:3};
  if (name === 'Mind Bomb') c.effect = {type:'chooseNumber', min:0, max:7, symmetric:true};
  if (name === 'Bottle of Suleiman') c.activated = [{cost:'{1}', effect:{type:'coinFlip', heads:{type:'createToken',name:'Djinni',subtype:'Djinn',type:'Creature',power:5,toughness:5,keywords:['flying']}, tails:{type:'damage',amount:5,target:'self'}}}];
  if (name === 'Sorceress Queen' || name === 'Singing Tree') c.activated = [{cost:'',tap:true,effect:{type:'setBasePT',power:0,toughness:2}}];
  if (name === 'Candelabra of Tawnos') c.activated = [{cost:'{X}',effect:{type:'untapX', targetType:'land'}}];
  if (name === 'Aladdin\'s Ring') c.activated = [{cost:'{8}',effect:{type:'damage',amount:4,target:'anyTarget'}}];
  if (name === 'Millstone') c.activated = [{cost:'{2}',effect:{type:'mill',amount:2,target:'opponent'}}];
  if (name === 'Jalum Tome') c.activated = [{cost:'{2}',effect:{type:'draw',amount:1,then:{type:'discard',amount:1}}}];
  return c;
}
