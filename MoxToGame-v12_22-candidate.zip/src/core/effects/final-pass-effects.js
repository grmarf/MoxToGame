// V12.3 — C8.8 closure pass for the last annotated card definitions.
// Definitions already covered by canonical handlers in C6/C7/C8.1/C8.6 are removed.
import { gameEvents } from '../event-bus.js';
import { calculateCharacteristics } from '../continuous-effects.js';

const sides=['player','ai'];
const opp=s=>s==='player'?'ai':'player';
const find=(state,ref)=>{const id=ref?.uid||ref?.objectId||ref?.id||ref;return sides.flatMap(s=>state[s]?.battlefield||[]).find(p=>p.uid===id||p.objectId===id)||null;};
const isCreature=p=>/Creature/i.test(String(p?.type||''));
const isLand=p=>/Land/i.test(String(p?.type||''));
const isArtifact=p=>/Artifact/i.test(String(p?.type||''));
const reg=(r,t,f)=>r.has(t)?r.register(t,f,{replace:true}):r.register(t,f);

export function applyC88Definition(c){
  if(!c?.name||c.__c88Applied)return c; c.__c88Applied=true; const n=c.name;
  const add=(e)=>{c.static=Array.isArray(c.static)?[...c.static,e]:[e];};
  const aura=(e)=>{c.isAura=true;c.auraEffect=e;};

  // ── Auras / Enchantments not covered by canonical handlers ──
  if(n==='Consecrate Land'||n==='Farmstead') aura({type:'grantManaAbility',produces:'C',gainLife:1});
  if(n==='Sleight of Mind') c.effect={type:'colorChangeWord',target:'permanentOrSpell'};
  if(n==='Warp Artifact') c.triggers=[{event:'upkeepStarted',condition:{controllerUpkeep:false,sourceSelf:true},effect:{type:'artifactDamage',amount:1,target:'enchanted'}}];
  if(n==='Karma') add({type:'karma'});
  if(n==='Creature Bond') c.triggers=[{event:'creatureDied',condition:{enchantedSource:true},effect:{type:'draw',amount:1}}];

  // ── Already covered by canonical handlers (C6/C7/C8.1) ──
  // Drain Power      -> c7 'drainMana'
  // Flash            -> c7 'flash'
  // Island Sanctuary -> c6 'preventDamageFromNonFlying'
  // Siren's Call     -> c7 'forceAttack'
  // Stasis           -> c8.6 'skipUntap'
  // Steal Artifact   -> c7 'stealArtifact'
  // Circle of Protection -> c6 'preventNextDamageFromColor' (via __c88Structured)
  // Purelace         -> c7 'changeColor'
  // Blaze of Glory   -> c7 'mustBeBlocked'
  // Carnival of Souls-> c7 static marker (lifeLossAndManaOnCreatureEnter)
  // Evil Presence    -> aura changeType
  // Iron Star        -> c6 'preventNextDamageFromColor' (activated)
  // Megrim           -> c7 static marker
  // Nettling Imp     -> c7 'forceAttack' (activated)
  // Paralyze         -> c7 'paralyze' (aura)

  if(n==='Evil Presence') aura({type:'changeType',subtype:'Swamp'});
  if(n==='Nettling Imp') c.activated=[{cost:'{1}{B}',tap:true,effect:{type:'forceAttack',target:'opponentsCreature'}}];
  if(n==='Paralyze') aura({type:'paralyze'});

  // ── Remaining unique definitions ──
  if(n==='Purelace') c.effect={type:'changeColor',target:'permanent',color:'W'};
  if(n==='Blaze of Glory') c.effect={type:'mustBeBlocked',target:'attackingCreature',power:1,toughness:1};
  if(n==='Carnival of Souls') add({type:'lifeLossAndManaOnCreatureEnter'});
  if(n==='Megrim') add({type:'megrim'});

  return c;
}

export function registerC88Effects(registry){
  // V12.3: all C8.8 effect types are now registered by earlier C6/C7/C8 modules.
  // This function is kept for forward compatibility but currently registers nothing new.
  const reg=(t,f)=>{if(!registry.has(t))registry.register(t,f);};
  // artifactDamage is handled inline by extended-effects or atomic-effects
  reg('artifactDamage',(ctx,e)=>{const t=find(ctx.state,ctx.targetInfo);if(t)t.damageMarked=(t.damageMarked||0)+Number(e.amount||1);});
}

export function installC88EventRules(){
  // V12.3: event rules consolidated in C6/C7/C8.6 install functions.
  // Kept as no-op hook for future expansion.
}
