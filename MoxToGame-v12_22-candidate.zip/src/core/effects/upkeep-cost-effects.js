/** V8.9 — Composable upkeep replacement costs. */
import { canPayMana, payMana } from '../costs/mana-cost.js';

const sideState = (ctx) => ctx.api.state[ctx.controllerKey];

const choose = (ctx, options, metadata) =>
  ctx.api.decisions?.choose(options, {
    source: ctx.sourceCard,
    controller: ctx.controllerKey,
    effect: ctx.effect,
    ...metadata,
  });

const ownCreatures = (ctx) =>
  sideState(ctx).battlefield.filter((p) =>
    String(p.type || '').includes('Creature')
  );

const lands = (ctx) =>
  [
    ...ctx.api.state.player.battlefield,
    ...ctx.api.state.ai.battlefield,
  ].filter((p) => String(p.type || '').includes('Land'));

function removePermanent(ctx, p) {
  const side = ctx.api.findPermSide(p);
  if (side == null) return false;
  if (ctx.api.zones) { ctx.api.zones.moveToGraveyard(p, { toSide: p.owner || side, reason: 'upkeepCost' }); return true; }
  ctx.api.state[side].battlefield = ctx.api.state[side].battlefield.filter(
    (x) => x !== p
  );
  ctx.api.state[side].graveyard.push(p);
  return true;
}

function damage(ctx, n) {
  ctx.api.state[ctx.controllerKey].life -= n;
  ctx.api.log(
    `${ctx.sourceCard.name} : ${n} blessures d'entretien.`,
    ctx.controllerKey
  );
}

export function registerUpkeepCostEffects(registry) {
  registry.register('payOrDamage', (ctx, e) => {
    const p = sideState(ctx);
    const can = canPayMana(p, e.cost);
    const opts = can ? ['pay', 'damage'] : ['damage'];
    const c = choose(ctx, opts, { kind: 'payOrDamage', options: opts });
    if (c === 'pay' && can) {
      payMana(p, e.cost);
      ctx.api.log(
        `${ctx.sourceCard.name} : coût d'entretien payé (${e.cost}).`,
        ctx.controllerKey
      );
      return { choice: c, paid: true };
    }
    damage(ctx, e.damage);
    return { choice: 'damage', paid: false };
  });

  registry.register('sacrificeOrDamage', (ctx, e) => {
    const cs = ownCreatures(ctx);
    const opts = cs.length ? ['sacrifice', 'damage'] : ['damage'];
    const c = choose(ctx, opts, {
      kind: 'sacrificeOrDamage',
      options: opts,
    });
    if (c === 'sacrifice' && cs.length) {
      const s = choose(ctx, cs, {
        kind: 'chooseCreatureToSacrifice',
        options: cs,
      });
      if (s && removePermanent(ctx, s)) {
        ctx.api.log(
          `${ctx.sourceCard.name} : ${s.name} est sacrifiée.`,
          ctx.controllerKey
        );
        return { choice: c, sacrificed: s };
      }
    }
    damage(ctx, e.damage);
    return { choice: 'damage', sacrificed: null };
  });

  registry.register('payOrSacrifice', (ctx, e) => {
    const p = sideState(ctx);
    const can = canPayMana(p, e.cost);
    const opts = can ? ['pay', 'sacrifice'] : ['sacrifice'];
    const c = choose(ctx, opts, { kind: 'payOrSacrifice', options: opts });
    if (c === 'pay' && can) {
      payMana(p, e.cost);
      ctx.api.log(
        `${ctx.sourceCard.name} : coût d'entretien payé (${e.cost}).`,
        ctx.controllerKey
      );
      return { choice: c, paid: true };
    }
    const s = ctx.sourceCard;
    if (removePermanent(ctx, s)) {
      ctx.api.log(`${s.name} est sacrifiée.`, ctx.controllerKey);
      return { choice: 'sacrifice', sacrificed: s };
    }
    return { choice: 'none', paid: false };
  });

  registry.register('destroyLandOrPay', (ctx, e) => {
    const p = sideState(ctx);
    const can = canPayMana(p, e.cost);
    const ls = lands(ctx);
    const opts = can && ls.length ? ['destroyLand', 'pay'] : ['pay'];
    const c = choose(ctx, opts, {
      kind: 'destroyLandOrPay',
      options: opts,
    });
    if (c === 'destroyLand' && ls.length) {
      const t = choose(ctx, ls, {
        kind: 'chooseLandToDestroy',
        options: ls,
      });
      if (t && removePermanent(ctx, t)) {
        ctx.api.log(
          `${ctx.sourceCard.name} : ${t.name} est détruit.`,
          ctx.controllerKey
        );
        return { choice: c, destroyed: t };
      }
    }
    if (can) {
      payMana(p, e.cost);
      ctx.api.log(
        `${ctx.sourceCard.name} : coût d'entretien payé (${e.cost}).`,
        ctx.controllerKey
      );
      return { choice: 'pay', paid: true };
    }
    return { choice: 'none', paid: false };
  });
}
