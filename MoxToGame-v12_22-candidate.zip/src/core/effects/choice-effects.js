// V12.3 — C8.1: choices, search, randomisation, copying and token helpers.
// createToken removed (unified in c8-token-historical.js).
// setBasePT migrated to continuous static effect (Layer 7b).
import { gameEvents } from '../event-bus.js';

const sides = ['player','ai'];
const other = s => s === 'player' ? 'ai' : 'player';
const findPermanent = (state, ref) => {
  const id = ref?.uid || ref?.objectId || ref?.id || ref;
  return sides.flatMap(s => state[s]?.battlefield || []).find(p => p.uid === id || p.objectId === id) || null;
};

function register(registry, type, fn) { if (!registry.has(type)) registry.register(type, fn); }

export function registerC81Effects(registry) {
  register(registry, 'randomDiscard', (ctx, effect) => {
    const side = effect.target === 'opponent' ? other(ctx.controllerKey) : (effect.side || ctx.controllerKey);
    const hand = ctx.state[side]?.hand || [];
    const count = Math.min(Number(effect.amount || 1), hand.length);
    for (let i=0;i<count;i++) {
      const index = Math.floor(rngClock.random() * ctx.state[side].hand.length);
      ctx.api.discardCard(side, index);
    }
  });

  register(registry, 'chooseColor', (ctx, effect) => {
    const colors = effect.options || ['W','U','B','R','G'];
    const chosen = ctx.api.choose({ type:'color', controller:ctx.controllerKey, options:colors, prompt:effect.prompt || 'Choisissez une couleur.', defaultValue:colors[0] });
    if (chosen) {
      ctx.sourceCard.chosenColor = chosen;
      if (effect.target) {
        const target = findPermanent(ctx.state, ctx.targetInfo);
        if (target) target.chosenColor = chosen;
      }
    }
    return chosen;
  });

  register(registry, 'searchLibrary', (ctx, effect) => {
    const side = effect.side || ctx.controllerKey;
    const library = ctx.state[side]?.library || [];
    if (!library.length) return null;
    const candidates = library.filter(card => {
      if (effect.cardType && !String(card.type || '').includes(effect.cardType)) return false;
      if (effect.subtype && !String(card.subtype || '').toLowerCase().includes(String(effect.subtype).toLowerCase())) return false;
      if (effect.name && card.name !== effect.name) return false;
      return true;
    });
    if (!candidates.length) { ctx.api.shuffle(library); return null; }
    const chosen = ctx.api.choose({ type:'libraryCard', controller:side, options:candidates, min:1, max:1, prompt:effect.prompt || 'Choisissez une carte.', defaultValue:candidates[0] });
    if (!chosen) return null;
    const index = library.indexOf(chosen);
    if (index < 0) return null;
    const card = library.splice(index,1)[0];
    if (ctx.api.zones) ctx.api.zones.move(card,'hand',{toSide:side,reason:'searchLibrary'});
    else ctx.state[side].hand.push({...card,zone:'hand'});
    ctx.api.shuffle(library);
    gameEvents.emit({type:'librarySearched', side, card});
    return card;
  });

  register(registry, 'lookTop', (ctx, effect) => {
    const side = effect.side || ctx.controllerKey;
    const n = Math.min(Number(effect.amount || 1), ctx.state[side].library.length);
    const cards = ctx.state[side].library.slice(-n).reverse();
    ctx.api.choose({ type:'lookTop', controller:side, options:cards, min:0, max:0, prompt:effect.prompt || `Regardez les ${n} cartes du dessus.` });
    ctx.state[side].lookedAt = cards.map(c => c.uid || c.objectId || c.id);
    return cards;
  });

  register(registry, 'putTopCardBottom', (ctx, effect) => {
    const side = effect.side || ctx.controllerKey;
    const lib = ctx.state[side].library;
    if (!lib.length) return;
    const top = lib.pop(); lib.unshift(top);
  });

  register(registry, 'copySpell', (ctx, effect) => {
    const item = ctx.api.findStackItem?.(ctx.targetInfo?.id || ctx.targetInfo);
    if (!item || !['spell','copy'].includes(item.type)) return null;
    const target = effect.chooseNewTargets ? ctx.api.chooseNewTargets?.(item, ctx.controllerKey) : item.target;
    return ctx.api.pushSpellCopy?.(item, ctx.controllerKey, target) || null;
  });

  // V12.3 — setBasePT migrated from direct mutation to continuous static effect.
  // This makes it properly interact with layers and removable when the source leaves.
  register(registry, 'setBasePT', (ctx, effect) => {
    const target = findPermanent(ctx.state, ctx.targetInfo);
    if (!target) return;
    // Apply as a continuous effect on the target itself so it layers correctly
    target.static = Array.isArray(target.static) ? target.static : (target.static ? [target.static] : []);
    target.static.push({
      type: 'setPowerToughness',
      power: Number(effect.power ?? 0),
      toughness: Number(effect.toughness ?? 0),
      selfOnly: true,
      duration: effect.duration || 'permanent'
    });
  });

  register(registry, 'coinFlip', (ctx, effect) => {
    const heads = rngClock.random() < 0.5;
    const branch = heads ? effect.heads : effect.tails;
    if (branch) ctx.api.resolveInlineEffect?.(branch, { sourceCard:ctx.sourceCard, targetInfo:ctx.targetInfo, xValue:ctx.xValue });
    gameEvents.emit({type:'coinFlipped', side:ctx.controllerKey, heads});
    return heads;
  });

  // V12.3 — createToken removed; unified in c8-token-historical.js registerC86C87Effects.
  // If any card references type:'createToken' from C8.1, it will resolve via C8.6/C8.7.
}
