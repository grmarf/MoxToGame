// V9.3 — unified choice service (M4). UI and AI can provide the same chooser contract.
export class ChoiceService {
  constructor({ state, chooser = null } = {}) { this.getState = state; this.chooser = chooser; this.pending = null; this.seq = 0; }
  setChooser(chooser) { this.chooser = chooser; return this; }
  request(spec = {}) {
    const options = Array.isArray(spec.options) ? spec.options : [];
    if (!options.length) return spec.defaultValue ?? null;
    const choice = { id:`choice_${++this.seq}`, type:spec.type || 'choice', controller:spec.controller || 'player', prompt:spec.prompt || 'Choisissez.', options, min:spec.min ?? 1, max:spec.max ?? 1, defaultValue:spec.defaultValue ?? options[0] };
    const chosen = this.chooser ? this.chooser(choice, this.getState?.()) : null;
    if (chosen != null) return this.validate(choice, chosen) ? chosen : choice.defaultValue;
    this.pending = choice;
    return null;
  }
  validate(choice, value) {
    if (choice.max === 1) return choice.options.some(x => x === value || x?.uid === value?.uid || x?.id === value?.id);
    if (!Array.isArray(value) || value.length < choice.min || value.length > choice.max) return false;
    return value.every(v => choice.options.some(x => x === v || x?.uid === v?.uid || x?.id === v?.id));
  }
  resolve(value) { if (!this.pending) return null; const c=this.pending; if(!this.validate(c,value)) throw new Error('Choix invalide.'); this.pending=null; return value; }
  clear() { this.pending=null; }
}
