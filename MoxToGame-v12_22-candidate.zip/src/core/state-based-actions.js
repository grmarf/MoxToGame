// @ts-check
/**
 * @fileoverview MTG Beta V8.15 — State-Based Actions (SBA) Extended
 * Full CR 704 implementation including:
 * 704.5a: 0 life
 * 704.5b: draw from empty library
 * 704.5f: toughness <= 0
 * 704.5g: lethal damage
 * 704.5i: Planeswalker uniqueness
 * 704.5j: Legend rule
 * 704.5k: +1/+1 and -1/-1 counter annihilation
 * 704.5m: Poison (10+ counters = lose)
 * 704.5n: Aura illegal attachment
 * 704.5d: Token outside battlefield
 */

/** @typedef {import('./types.js').GameState} GameState */
/** @typedef {import('./types.js').Permanent} Permanent */

import { gameEvents } from './event-bus.js';
import { calculateCharacteristics } from './continuous-effects.js';

/**
 * @typedef {Object} SBAEvent
 * @property {string} type
 * @property {Permanent} [permanent]
 * @property {string} [side]
 * @property {string} [reason]
 * @property {Object} [data]
 */

export class StateBasedActions {
  /**
   * @param {Object} [deps]
   * @param {Function} [deps.legacyCheck]
   */
  constructor({ legacyCheck, zones = null, choiceService = null } = {}) {
    this.legacyCheck = legacyCheck;
    this.zones = zones;
    this.choiceService = choiceService;
  }
  /**
   * Put a permanent into its owner's graveyard via ZoneManager if available,
   * otherwise fallback by uid (never by JS reference).
   */
  #putIntoGraveyard(perm, side, reason, events, state) {
    if (this.zones) {
      this.zones.moveToGraveyard(perm, { toSide: perm.owner || side, reason: 'stateBasedAction' });
    } else {
      const uid = perm.uid;
      state[side].battlefield = state[side].battlefield.filter((p) => p.uid !== uid);
      state[side].graveyard.push(perm);
    }
    perm.destroyed = true;
    events.push({ type: 'creatureDied', permanent: perm, side, reason });
  }


  /**
   * Run all applicable state-based actions.
   * @param {GameState} state
   * @returns {SBAEvent[]} events generated
   */
  check(state) {
    const events = [];
    events.push(...this.#checkPlayerLost(state));
    events.push(...this.#checkDrawFromEmptyLibrary(state));
    events.push(...this.#checkCreatureDeath(state));
    events.push(...this.#checkPlaneswalkerUniqueness(state));
    events.push(...this.#checkLegendRule(state));
    events.push(...this.#checkCounterAnnihilation(state));
    events.push(...this.#checkPoison(state));
    events.push(...this.#checkAurasAttachedToIllegal(state));
    events.push(...this.#checkTokenInNonBattlefield(state));

    events.forEach((evt) => gameEvents.emit(evt));

    if (events.length === 0 && this.legacyCheck) {
      this.legacyCheck();
    }

    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5a — Player at 0 or less life loses
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkPlayerLost(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      if (state[side].life <= 0 && !state[side].hasLost) {
        state[side].hasLost = true;
        events.push({ type: 'playerLost', side, reason: 'zeroOrLessLife' });
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5b — Draw from empty library
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkDrawFromEmptyLibrary(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      if (state[side].mustDraw && state[side].library.length === 0) {
        state[side].hasLost = true;
        events.push({ type: 'playerLost', side, reason: 'drawFromEmptyLibrary' });
        state[side].mustDraw = false;
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5f/g — Creature death
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkCreatureDeath(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      const toDestroy = [];
      for (const perm of state[side].battlefield) {
        if (!String(perm.type || '').includes('Creature')) continue;
        const effectiveToughness = this.#effectiveToughness(state, perm);
        if (effectiveToughness <= 0 || ((perm.damageMarked || 0) >= effectiveToughness && !perm.regenShield)) {
          if (perm.regenShield) { perm.regenShield = false; perm.damageMarked = 0; perm.tapped = true; events.push({ type:'regenerationUsed', permanent:perm, side, reason:'regenerationShield' }); } else toDestroy.push(perm);
        }
      }
      for (const perm of toDestroy) {
        this.#putIntoGraveyard(perm, side, perm.damageMarked > 0 ? 'lethalDamage' : 'zeroOrLessToughness', events, state);
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5i — Planeswalker uniqueness
  // If a player controls two or more Planeswalkers with the same
  // subtype, that player chooses one and the rest are put into
  // their owners' graveyards.
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkPlaneswalkerUniqueness(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      const pws = state[side].battlefield.filter((p) =>
        String(p.type || '').includes('Planeswalker')
      );
      const bySubtype = {};
      for (const pw of pws) {
        // subtype is stored in p.subtype or extracted from name
        const subtype = pw.subtype || pw.name;
        bySubtype[subtype] = (bySubtype[subtype] || []).concat(pw);
      }
      for (const [subtype, perms] of Object.entries(bySubtype)) {
        if (perms.length > 1) {
          const keep = this.choiceService?.request({
            type: 'planeswalker-choose',
            controller: side,
            prompt: `Choisissez un planeswalker ${subtype} à garder.`,
            options: perms,
            min: 1,
            max: 1,
            defaultValue: perms[0],
          }) || perms[0];
          const toDestroy = perms.filter(p => p !== keep);
          for (const perm of toDestroy) {
            this.#putIntoGraveyard(perm, side, `duplicate subtype ${subtype}`, events, state);
            events[events.length - 1].type = 'planeswalkerUniqueness';
          }
        }
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5j — Legend rule
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkLegendRule(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      const legends = state[side].battlefield.filter((p) =>
        String(p.type || '').includes('Legendary')
      );
      const byName = {};
      for (const l of legends) {
        byName[l.name] = (byName[l.name] || []).concat(l);
      }
      for (const [name, perms] of Object.entries(byName)) {
        if (perms.length > 1) {
          const keep = this.choiceService?.request({
            type: 'legend-choose',
            controller: side,
            prompt: `Choisissez une légende ${name} à garder.`,
            options: perms,
            min: 1,
            max: 1,
            defaultValue: perms[0],
          }) || perms[0];
          const toDestroy = perms.filter(p => p !== keep);
          for (const perm of toDestroy) {
            this.#putIntoGraveyard(perm, side, `duplicate ${name}`, events, state);
            events[events.length - 1].type = 'legendRule';
          }
        }
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5k — +1/+1 and -1/-1 counter annihilation
  // If a permanent has both +1/+1 and -1/-1 counters,
  // remove pairs until only one type remains.
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkCounterAnnihilation(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      for (const perm of state[side].battlefield) {
        if (!perm.counters) continue;
        const plus = perm.counters.filter((c) => c.type === '+1/+1').length;
        const minus = perm.counters.filter((c) => c.type === '-1/-1').length;
        const pairs = Math.min(plus, minus);
        if (pairs > 0) {
          // Remove pairs
          let removedPlus = 0;
          let removedMinus = 0;
          perm.counters = perm.counters.filter((c) => {
            if (c.type === '+1/+1' && removedPlus < pairs) {
              removedPlus++;
              return false;
            }
            if (c.type === '-1/-1' && removedMinus < pairs) {
              removedMinus++;
              return false;
            }
            return true;
          });
          events.push({
            type: 'counterAnnihilation',
            permanent: perm,
            side,
            data: { pairsRemoved: pairs },
          });
        }
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5m — Poison (10+ poison counters = lose)
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkPoison(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      const poison = state[side].poison || 0;
      if (poison >= 10) {
        state[side].hasLost = true;
        events.push({ type: 'playerLost', side, reason: 'poison' });
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5n — Aura attached to illegal object
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkAurasAttachedToIllegal(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      for (const perm of state[side].battlefield) {
        if (!String(perm.type || '').includes('Aura')) continue;
        // Check if attached permanent still exists and is legal
        if (perm.attachedTo) {
          const allPerms = [...state.player.battlefield, ...state.ai.battlefield];
          const target = allPerms.find((p) => p.uid === perm.attachedTo);
          if (!target) {
            // Target left battlefield — put aura in graveyard
            this.#putIntoGraveyard(perm, side, 'targetLeftBattlefield', events, state);
            events[events.length - 1].type = 'auraDetached';
          }
        }
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // 704.5d — Token outside battlefield
  // ─────────────────────────────────────────────
  /** @param {GameState} state */
  #checkTokenInNonBattlefield(state) {
    const events = [];
    for (const side of ['player', 'ai']) {
      for (const zone of ['hand', 'graveyard', 'exile', 'library']) {
        const tokens = state[side][zone].filter((c) => c.isToken);
        if (tokens.length) {
          state[side][zone] = state[side][zone].filter((c) => !c.isToken);
          tokens.forEach((t) => {
            events.push({ type: 'tokenCeasedToExist', permanent: t, side });
          });
        }
      }
    }
    return events;
  }

  // ─────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────

  /** @param {Permanent} perm */
  #effectiveToughness(state, perm) {
    return calculateCharacteristics(state, perm).toughness;
  }
}
