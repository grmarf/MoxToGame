// @ts-check
import { canPayMana, manaCostToPool } from '../core/costs/mana-cost.js';
import { rngClock } from '../core/rng-clock-service.js';

export class GameUI {
  constructor({ cards, game, root = document.body }) {
    this.cards = cards;
    this.game = game;
    this.root = root;
    this.deck = [];
    this.started = false;
    // V11.0 — état de sélection pour le combat (attaquants/bloqueurs)
    this.selectedAttackers = new Set();
    this.selectedAttackerForBlock = null;
    this.blockerAssignments = {}; // { attackerUid: [blockerUid, ...] }
    // V11.1 — état du mulligan (côté joueur humain uniquement, l'IA se gère seule)
    this.playerMulliganCount = 0;
    this.mulliganStage = 'deciding'; // 'deciding' | 'selectingBottom'
    this.mulliganBottomSelection = new Set();
    this.#bind();
    this.render(this.game.state);
  }

  #bind() {
    const search = document.getElementById('card-search');
    search?.addEventListener('input', () => this.renderCardCatalog(search.value));
    document.getElementById('add-random')?.addEventListener('click', () => this.addRandomDeck());
    document.getElementById('clear-deck')?.addEventListener('click', () => { this.deck = []; this.renderDeck(); });
    document.getElementById('start-game')?.addEventListener('click', () => this.startGame());
    document.getElementById('next-phase')?.addEventListener('click', () => this.dispatch('nextPhase'));
    document.getElementById('resolve-stack')?.addEventListener('click', () => this.dispatch('nextPhase'));
    document.getElementById('concede')?.addEventListener('click', () => {
      if (this.#isGameOver()) return;
      this.game.state.player.life = 0;
      this.game.state.player.hasLost = true;
      this.render(this.game.state);
    });
  }

  /** V11.1 — vrai dès qu'un des deux joueurs a perdu. */
  #isGameOver() {
    const s = this.game.state;
    return !!(s && (s.player?.hasLost || s.ai?.hasLost));
  }

  dispatch(action, data = {}) {
    if (this.#isGameOver()) { this.log('La partie est terminée.', 'system'); return; }
    try { this.game.dispatch(action, data); }
    catch (e) { this.log(e.message, 'system'); }
    this.render(this.game.state);
  }

  addRandomDeck() {
    const pool = this.cards.filter(c => !String(c.type).includes('Basic Land'));
    const basics = this.cards.filter(c => c.isBasic);
    this.deck = [];
    for (let i = 0; i < 24; i++) this.deck.push({ ...basics[i % basics.length] });
    while (this.deck.length < 60) this.deck.push({ ...pool[Math.floor(rngClock.random()*pool.length)] });
    this.renderDeck();
  }

  // ─────────────────────────────────────────────
  // V11.1 — Mulligan (règle de Londres simplifiée)
  // ─────────────────────────────────────────────

  startGame() {
    if (this.deck.length < 40) return this.log('Le deck doit contenir au moins 40 cartes.', 'system');
    this.game.engine.loadDeck('player', this.deck);
    this.game.engine.loadDeck('ai', this.deck);
    this.playerMulliganCount = 0;
    this.mulliganStage = 'deciding';
    this.mulliganBottomSelection = new Set();
    this.#aiResolveMulligan();
    document.getElementById('pre-game')?.classList.add('hidden');
    document.getElementById('mulligan-screen')?.classList.remove('hidden');
    this.#renderMulliganScreen();
  }

  /** L'IA décide seule si elle garde sa main (2 à 5 terrains sur 7, sinon mulligan, 2 max). */
  #aiResolveMulligan() {
    const side = this.game.state.ai;
    const isLand = (c) => String(c.type || '').includes('Land');
    let mulligans = 0;
    while (mulligans < 2) {
      const lands = side.hand.filter(isLand).length;
      if (lands >= 2 && lands <= 5) break;
      side.library.push(...side.hand);
      side.hand = [];
      this.#shuffle(side.library);
      for (let i = 0; i < 7 && side.library.length > 0; i++) side.hand.push(side.library.pop());
      mulligans += 1;
    }
    if (mulligans > 0) {
      const sorted = [...side.hand].sort((a, b) => this.#cmc(b) - this.#cmc(a));
      const toBottom = sorted.slice(0, mulligans);
      side.hand = side.hand.filter(c => !toBottom.includes(c));
      side.library.unshift(...toBottom);
      this.log(`🤖 L'IA a fait ${mulligans} mulligan(s).`, 'ai');
    }
  }

  mulliganPlayer() {
    const side = this.game.state.player;
    side.library.push(...side.hand);
    side.hand = [];
    this.#shuffle(side.library);
    for (let i = 0; i < 7 && side.library.length > 0; i++) side.hand.push(side.library.pop());
    this.playerMulliganCount += 1;
    this.mulliganBottomSelection = new Set();
    this.#renderMulliganScreen();
  }

  keepPlayerHand() {
    if (!this.playerMulliganCount) { this.#finalizeStart(); return; }
    this.mulliganStage = 'selectingBottom';
    this.#renderMulliganScreen();
  }

  confirmMulliganBottom() {
    const n = this.playerMulliganCount;
    if (this.mulliganBottomSelection.size !== n) return;
    const side = this.game.state.player;
    const toBottom = side.hand.filter(c => this.mulliganBottomSelection.has(c.uid));
    side.hand = side.hand.filter(c => !this.mulliganBottomSelection.has(c.uid));
    side.library.unshift(...toBottom);
    this.mulliganBottomSelection = new Set();
    this.mulliganStage = 'deciding';
    this.#finalizeStart();
  }

  #finalizeStart() {
    this.started = true;
    document.getElementById('mulligan-screen')?.classList.add('hidden');
    document.getElementById('game-board')?.classList.remove('hidden');
    this.render(this.game.state);
    const suffix = this.playerMulliganCount ? ` (après ${this.playerMulliganCount} mulligan(s))` : '';
    this.log(`Partie lancée. Vous gardez une main de ${this.game.state.player.hand.length} carte(s)${suffix}.`, 'system');
  }

  #renderMulliganScreen() {
    const el = document.getElementById('mulligan-screen');
    if (!el) return;
    const hand = this.game.state.player.hand;

    if (this.mulliganStage === 'selectingBottom') {
      const n = this.playerMulliganCount;
      const ready = this.mulliganBottomSelection.size === n;
      el.innerHTML = `
        <div class="section-title">Renvoyez ${n} carte(s) au fond de votre bibliothèque</div>
        <div class="hint">Cliquez sur ${n} carte(s) de votre main pour les renvoyer, puis validez.</div>
        <div id="mulligan-hand" class="card-list"></div>
        <div class="hint">Sélectionnées : <strong>${this.mulliganBottomSelection.size}</strong>/${n}</div>
        <button class="btn btn-success" id="mulligan-confirm-bottom" ${ready ? '' : 'disabled'} style="width:100%; margin-top:8px;">✅ Valider</button>
      `;
      const handEl = document.getElementById('mulligan-hand');
      handEl.innerHTML = hand.map(c => {
        const sel = this.mulliganBottomSelection.has(c.uid);
        return `<button class="card-item${sel ? ' selected' : ''}" data-uid="${c.uid}">${this.#esc(c.name)} <small>${this.#esc(c.cost || '')}</small>${sel ? ' ↩️' : ''}</button>`;
      }).join('');
      handEl.querySelectorAll('.card-item').forEach(b => b.onclick = () => {
        const uid = b.dataset.uid;
        if (this.mulliganBottomSelection.has(uid)) this.mulliganBottomSelection.delete(uid);
        else if (this.mulliganBottomSelection.size < n) this.mulliganBottomSelection.add(uid);
        this.#renderMulliganScreen();
      });
      document.getElementById('mulligan-confirm-bottom')?.addEventListener('click', () => this.confirmMulliganBottom());
      return;
    }

    el.innerHTML = `
      <div class="section-title">Votre main de départ${this.playerMulliganCount ? ` — mulligan n°${this.playerMulliganCount}` : ''}</div>
      <div id="mulligan-hand" class="card-list"></div>
      <div class="hint">${this.playerMulliganCount
        ? `Vous devrez renvoyer ${this.playerMulliganCount} carte(s) au fond de la bibliothèque si vous gardez cette main (règle de Londres).`
        : 'Gardez cette main, ou faites un mulligan pour repiocher 7 nouvelles cartes.'}</div>
      <div style="display:flex; gap:6px; margin-top:10px;">
        <button class="btn btn-primary" id="mulligan-keep" style="flex:1;">✅ Garder ma main</button>
        <button class="btn btn-info" id="mulligan-again" style="flex:1;">🔄 Mulligan</button>
      </div>
    `;
    const handEl = document.getElementById('mulligan-hand');
    handEl.innerHTML = hand.map(c => `<div class="card-item">${this.#esc(c.name)} <small>${this.#esc(c.cost || '')}</small></div>`).join('');
    document.getElementById('mulligan-keep').onclick = () => this.keepPlayerHand();
    document.getElementById('mulligan-again').onclick = () => this.mulliganPlayer();
  }

  #shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(rngClock.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  #cmc(card) {
    const pool = manaCostToPool(card?.cost || '');
    return Object.values(pool).reduce((a, b) => a + (Number(b) || 0), 0);
  }

  render(state) {
    if (!state) return;
    this.renderCardCatalog(document.getElementById('card-search')?.value || '');
    this.renderDeck();
    this.#text('player-life', state.player.life); this.#text('ai-life', state.ai.life);
    this.#text('player-hand-count', state.player.hand.length); this.#text('ai-hand-count', state.ai.hand.length);
    this.#text('player-lib-count', state.player.library.length); this.#text('ai-lib-count', state.ai.library.length);
    this.#text('player-mana-display', this.mana(state.player.mana)); this.#text('ai-mana-display', this.mana(state.ai.mana));
    this.#text('phase-indicator', `${this.game.turnManager.phase} — tour ${this.game.turnManager.turnNumber} — actif : ${this.game.turnManager.activePlayer}`);
    const combatMode = this.#combatMode();
    this.#renderZone('player-hand', state.player.hand, false);
    this.#renderZone('ai-hand', state.ai.hand, true);
    this.#renderBattlefield('player-battlefield', state.player.battlefield, 'player', combatMode);
    this.#renderBattlefield('ai-battlefield', state.ai.battlefield, 'ai', combatMode);
    this.#renderStack();
    this.#renderCombatPanel(combatMode);
    this.#renderGameOver(state);
  }

  renderCardCatalog(query = '') {
    const q = query.toLowerCase();
    const list = this.cards.filter(c => `${c.name} ${c.type} ${c.text_fr || ''}`.toLowerCase().includes(q)).slice(0, 80);
    const el = document.getElementById('card-list'); if (!el) return;
    el.innerHTML = list.map(c => `<button class="card-item" data-name="${this.#esc(c.name)}">${this.#esc(c.name)} <small>${this.#esc(c.cost || '')}</small></button>`).join('');
    el.querySelectorAll('.card-item').forEach(b => b.onclick = () => { const c=this.cards.find(x=>x.name===b.dataset.name); if(c){this.deck.push({...c});this.renderDeck();} });
  }

  renderDeck() {
    this.#text('deck-count', `Cartes : ${this.deck.length}/60`);
    const el=document.getElementById('current-deck-list'); if(!el)return;
    const counts={}; this.deck.forEach(c=>counts[c.name]=(counts[c.name]||0)+1);
    el.innerHTML=Object.entries(counts).map(([n,nr])=>`<div>${this.#esc(n)} ×${nr}</div>`).join('');
  }

  #renderZone(id, cards, hidden) {
    const el=document.getElementById(id); if(!el)return;
    el.innerHTML=cards.map((c,i)=>`<button class="card-slot" data-i="${i}">${hidden?'Carte face cachée':this.#esc(c.name)}${hidden?'':`<small>${this.#esc(c.cost||'')}</small>`}</button>`).join('');
    if(!hidden) el.querySelectorAll('.card-slot').forEach(b=>b.onclick=()=>this.cardAction(cards[Number(b.dataset.i)]));
  }

  // ─────────────────────────────────────────────
  // V11.0 — Combat : détection du mode d'interaction courant
  // ─────────────────────────────────────────────

  /** @returns {{mode:'attack'|'block'|null, validAttackerUids:Set<string>, validBlockerUids:Set<string>, attackers:Object[]}} */
  #combatMode() {
    const tm = this.game.turnManager;
    const combat = this.game.combat;
    if (!tm || !combat || this.#isGameOver()) return { mode: null, validAttackerUids: new Set(), validBlockerUids: new Set(), attackers: [] };

    if (tm.phase === 'declareAttackers' && tm.activePlayer === 'player' && !tm.combatDeclared) {
      const valid = combat.getValidAttackers('player');
      return { mode: 'attack', validAttackerUids: new Set(valid.map(p=>p.uid)), validBlockerUids: new Set(), attackers: [] };
    }
    if (tm.phase === 'declareBlockers' && tm.activePlayer === 'ai' && !tm.blockersDeclared) {
      const attackers = combat.combat?.attackers || [];
      const valid = combat.getValidBlockers('player');
      return { mode: 'block', validAttackerUids: new Set(), validBlockerUids: new Set(valid.map(p=>p.uid)), attackers };
    }
    // Hors de ces deux fenêtres : on nettoie les sélections en cours.
    if (this.selectedAttackers.size || this.selectedAttackerForBlock || Object.keys(this.blockerAssignments).length) {
      this.selectedAttackers = new Set();
      this.selectedAttackerForBlock = null;
      this.blockerAssignments = {};
    }
    return { mode: null, validAttackerUids: new Set(), validBlockerUids: new Set(), attackers: [] };
  }

  #renderBattlefield(id, perms, side, combatMode) {
    const el=document.getElementById(id); if(!el)return;
    const assignedBlockerUids = new Set(Object.values(this.blockerAssignments).flat());
    el.innerHTML=perms.map(p=>{
      const classes=['permanent-slot','permanent-card'];
      if (p.tapped) classes.push('tapped');
      if (combatMode.mode==='attack' && side==='player' && this.selectedAttackers.has(p.uid)) classes.push('selected','attacking');
      if (combatMode.mode==='block' && side==='ai' && combatMode.attackers.some(a=>a.uid===p.uid)) {
        classes.push('attacking');
        if (this.selectedAttackerForBlock===p.uid) classes.push('selected');
      }
      if (combatMode.mode==='block' && side==='player' && assignedBlockerUids.has(p.uid)) classes.push('blocking','selected');
      return `<button class="${classes.join(' ')}" data-uid="${p.uid}">${this.#esc(p.name)}<small>${p.power!==undefined?`${p.power}/${p.toughness}`:''}</small></button>`;
    }).join('');
    el.querySelectorAll('.permanent-slot').forEach(b=>b.onclick=()=>{
      if (this.#isGameOver()) return;
      const p=perms.find(x=>x.uid===b.dataset.uid);
      if (!p) return;

      if (combatMode.mode==='attack' && side==='player') {
        if (!combatMode.validAttackerUids.has(p.uid)) return; // créature engagée / malade d'invocation / etc.
        if (this.selectedAttackers.has(p.uid)) this.selectedAttackers.delete(p.uid);
        else this.selectedAttackers.add(p.uid);
        this.render(this.game.state);
        return;
      }

      if (combatMode.mode==='block') {
        if (side==='ai') {
          // Sélectionner l'attaquant que l'on veut bloquer.
          if (!combatMode.attackers.some(a=>a.uid===p.uid)) return;
          this.selectedAttackerForBlock = (this.selectedAttackerForBlock===p.uid) ? null : p.uid;
          this.render(this.game.state);
          return;
        }
        if (side==='player') {
          if (!combatMode.validBlockerUids.has(p.uid)) return;
          if (!this.selectedAttackerForBlock) { this.log('Choisissez d’abord la créature adverse à bloquer.', 'system'); return; }
          const atkUid = this.selectedAttackerForBlock;
          const list = this.blockerAssignments[atkUid] || (this.blockerAssignments[atkUid] = []);
          const alreadyAssignedElsewhere = Object.entries(this.blockerAssignments).some(([uid,arr]) => uid!==atkUid && arr.includes(p.uid));
          if (alreadyAssignedElsewhere) { this.log('Cette créature bloque déjà un autre attaquant.', 'system'); return; }
          const idx = list.indexOf(p.uid);
          if (idx>-1) list.splice(idx,1); else list.push(p.uid);
          if (list.length===0) delete this.blockerAssignments[atkUid];
          this.render(this.game.state);
          return;
        }
      }

      // Comportement par défaut (hors combat) : engager un terrain pour produire du mana.
      if (side==='player' && String(p.type).includes('Land')) this.dispatch('action',{action:'tapMana',data:{permanent:p,controller:'player'}});
    });
  }

  #renderCombatPanel(combatMode) {
    const el = document.getElementById('combat-panel');
    if (!el) return;
    if (combatMode.mode==='attack') {
      el.classList.remove('hidden');
      const n = this.selectedAttackers.size;
      el.innerHTML = `
        <div class="notice">⚔️ Déclarez vos attaquants : cliquez sur vos créatures aptes à attaquer, puis validez.</div>
        <div>Attaquants sélectionnés : <strong>${n}</strong></div>
        <button class="btn btn-success btn-small" id="confirm-attackers">✅ Confirmer les attaquants</button>
      `;
      document.getElementById('confirm-attackers').onclick = () => {
        const state = this.game.state;
        const attackers = state.player.battlefield.filter(p => this.selectedAttackers.has(p.uid));
        this.dispatch('declareAttackers', { attackers });
        this.selectedAttackers = new Set();
      };
      return;
    }
    if (combatMode.mode==='block') {
      el.classList.remove('hidden');
      const attackersHtml = combatMode.attackers.map(a => {
        const blockers = this.blockerAssignments[a.uid] || [];
        const label = blockers.length ? `bloqué par ${blockers.length}` : 'non bloqué';
        const cls = this.selectedAttackerForBlock===a.uid ? 'notice' : '';
        return `<div class="${cls}">${this.#esc(a.name)} (${a.power}/${a.toughness}) — ${label}</div>`;
      }).join('') || '<div>Aucun attaquant.</div>';
      el.innerHTML = `
        <div class="notice">🛡️ L'IA attaque ! Cliquez sur une créature adverse ci-dessus pour la cibler, puis sur vos créatures pour les assigner au blocage.</div>
        ${attackersHtml}
        <button class="btn btn-success btn-small" id="confirm-blockers">✅ Confirmer les bloqueurs</button>
      `;
      document.getElementById('confirm-blockers').onclick = () => {
        this.dispatch('declareBlockers', { blockers: { ...this.blockerAssignments } });
        this.selectedAttackerForBlock = null;
        this.blockerAssignments = {};
      };
      return;
    }
    el.classList.add('hidden');
    el.innerHTML = '';
  }

  // ─────────────────────────────────────────────
  // V11.1 — Fin de partie
  // ─────────────────────────────────────────────

  #renderGameOver(state) {
    const el = document.getElementById('game-over-modal');
    if (!el) return;
    const playerLost = !!state.player.hasLost;
    const aiLost = !!state.ai.hasLost;
    if (!playerLost && !aiLost) { el.classList.remove('show'); el.innerHTML = ''; return; }
    const youWon = aiLost && !playerLost;
    el.classList.add('show');
    el.innerHTML = `
      <div class="modal-content" style="text-align:center;">
        <h3>${youWon ? '🏆 Victoire !' : '💀 Défaite...'}</h3>
        <div class="hint">${youWon ? 'L’IA a été vaincue.' : 'Vous avez perdu la partie.'}</div>
        <button class="btn btn-primary" id="game-over-restart" style="margin-top:12px;">🔄 Nouvelle partie</button>
      </div>
    `;
    document.getElementById('game-over-restart').onclick = () => location.reload();
  }

  cardAction(card) {
    if (this.#isGameOver()) return;
    const state=this.game.state, side=state.player;
    if (String(card.type||'').includes('Land')) this.dispatch('action',{action:'playLand',data:{card,controller:'player'}});
    else {
      const target = this.game.targeting?.validTargets(card.effect?.type,'player')?.[0] || null;
      this.dispatch('castSpell',{card,target});
    }
  }

  #renderStack() {
    const el=document.getElementById('stack-items'); if(!el)return;
    el.innerHTML=this.game.stack.items.slice().reverse().map(x=>`<div>${this.#esc(x.source?.name||x.type)} — ${x.controller}</div>`).join('');
    const btn=document.getElementById('resolve-stack'); if(btn) btn.disabled=this.game.stack.isEmpty || this.game.state.priorityHolder !== 'player';
  }

  #text(id,v){const e=document.getElementById(id);if(e)e.textContent=String(v);}
  mana(m){return ['W','U','B','R','G','C'].filter(c=>m[c]>0).map(c=>`${c}:${m[c]}`).join(' ')||'0';}
  log(msg,type='system'){const e=document.getElementById('game-log');if(!e)return;const d=document.createElement('div');d.className=`log-${type}`;d.textContent=msg;e.appendChild(d);e.scrollTop=e.scrollHeight;}
  #esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
}
export function createGameUI(opts) { return new GameUI(opts); }
