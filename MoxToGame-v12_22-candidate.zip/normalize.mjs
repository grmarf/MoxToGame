import fs from 'node:fs';
const path='src/data/cards-database.js';
const src=fs.readFileSync(path,'utf8');
const start=src.indexOf('const CARDS = [');
const end=src.indexOf('];',start);
const body=src.slice(start+'const CARDS = '.length,end+1);
const cards=Function('return '+body)();
const byName=new Map();
const setsByRange=(id)=> id<=353?['LEB']:id<=427?['ARN']:id<=510?['DRK']:id<=588?['FEM']:['ATQ'];
for(const c of cards){
  const oldSets=setsByRange(c.id);
  const existing=byName.get(c.name);
  if(!existing){ byName.set(c.name,{...c,sets:[...oldSets]}); }
  else {
    for(const k of Object.keys(c)) if(k!=='id'&&k!=='sets' && (existing[k]==null || existing[k]==='' || (Array.isArray(existing[k])&&existing[k].length===0))) existing[k]=c[k];
    existing.sets=[...new Set([...(existing.sets||[]),...oldSets])];
  }
}
// Confirmed missing cards from the historical target sets.
const missing={
  ARN:['City in a Bottle','Dandân','Eye for an Eye'],
  ATQ:['Artifact Possession','Yawgmoth Demon','Cursed Rack','Golgothian Sylex',"Urza's Miter"],
  LEB:['Animate Wall','Balance','Benalish Hero','Black Ward','Blaze of Glory','Blue Ward','Castle','Circle of Protection: Black','Circle of Protection: Blue','Circle of Protection: Green','Circle of Protection: Red','Circle of Protection: White','Conversion','Death Ward','Farmstead','Green Ward','Guardian Angel','Holy Armor','Island Sanctuary','Karma','Lance','Mesa Pegasus','Northern Paladin','Personal Incarnation','Purelace','Red Ward','Resurrection','Reverse Damage','Samite Healer','Savannah Lions','Veteran Bodyguard','Wall of Swords','White Knight','White Ward','Animate Artifact','Blue Elemental Blast','Braingeyser','Copy Artifact','Drain Power','Feedback','Flight','Jump','Lifetap','Lord of Atlantis','Magical Hack','Mana Short','Phantasmal Forces','Phantasmal Terrain','Phantom Monster','Power Leak','Power Sink','Prodigal Sorcerer','Psychic Venom','Siren\'s Call','Spell Blast','Steal Artifact','Thoughtlace','Wall of Water','Water Elemental','Will-o\'-the-Wisp','Word of Command','Sacrifice','Scavenging Ghoul','Simulacrum','Dwarven Demolition Team','Dwarven Warriors','Earthquake','False Orders','Flashfires','Power Surge','Raging River','Rock Hydra','Stone Giant','Tunnel','Uthden Troll','Wheel of Fortune','Channel','Ice Storm','Lifelace','Regrowth','Scryb Sprites','Shanodin Dryads','Timber Wolves','Tsunami','Wanderlust','Wooden Sphere','Time Vault']
};
for(const [set,names] of Object.entries(missing)) for(const name of names){ if(!byName.has(name)) byName.set(name,{name,sets:[set],cost:'',cmc:0,color:[],type:'Unknown',rarity:'Unknown',text_fr:`Carte de l'édition ${set}. Effet à implémenter.`}); else byName.get(name).sets=[...new Set([...(byName.get(name).sets||[]),set])]; }
const out=[...byName.values()].map((c,i)=>{const x={...c,id:i+1}; return x;});
const header=`// ============================================================\n// BASE DE CARTES — Beta, Arabian Nights, Legends, The Dark,\n// Fallen Empires, Antiquities — normalisée V12.3.1\n// Une définition logique par nom ; les éditions sont dans sets[].\n// ============================================================\nimport { normalizeCard } from '../core/card-runtime.js';\n\nconst CARDS = `;
fs.writeFileSync(path,header+JSON.stringify(out,null,2)+';\n\nexport default CARDS.map(normalizeCard);\n');
fs.writeFileSync('src/data/card-set-manifest.js',`export const CARD_SET_MANIFEST = {\n  LEB: { name: 'Limited Edition Beta', expected: 302 },\n  ARN: { name: 'Arabian Nights', expected: 78 },\n  LEG: { name: 'Legends', expected: 310 },\n  DRK: { name: 'The Dark', expected: 119 },\n  FEM: { name: 'Fallen Empires', expected: 187 },\n  ATQ: { name: 'Antiquities', expected: 100 }\n};\n`);
console.log('normalized',cards.length,'=>',out.length);
console.log('set counts',Object.fromEntries(Object.keys({LEB:1,ARN:1,LEG:1,DRK:1,FEM:1,ATQ:1}).map(s=>[s,out.filter(c=>c.sets?.includes(s)).length])));
