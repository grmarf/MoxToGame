# C9 regression results

`C9.2/C9.3/C9.4 regression OK`

Tests exécutés :
- Ali from Cairo : 10 dégâts à 5 PV -> perte limitée à 4, total final 1 ;
- prévention de 2 sur 3 dégâts -> 1 dégât restant ;
- calcul de caractéristiques après installation du pipeline Layer 1-3 ;
- SBA : joueur à 0 PV -> événement `playerLost`.

Validation syntaxique : tous les fichiers JavaScript de `src/` passent `node --check`.
Base : 667 entrées / 600 noms uniques / 0 annotation « non simulé ».
