# v10.8 — C9.2 + C9.3 + C9.4 + audit final

Date: 2026-08-20

## C9.2 — Remplacement / prévention
- Prévention appliquée avant la modification du total de points de vie.
- Ali from Cairo intervient sur les pertes de PV résultant de blessures, pas sur une perte de PV directe.
- Les blessures de piétinement passent maintenant elles aussi par le pipeline de remplacement du total de PV.
- Les boucliers de prévention sont consommés et nettoyés selon leur durée.

## C9.3 — Couches / interactions
Le calcul des caractéristiques dispose maintenant de points d'entrée explicites pour les couches 1 à 3, avant les couches 4 à 7 existantes :
- Layer 1 : valeurs copiables ;
- Layer 2 : changement de contrôle ;
- Layer 3 : changement de texte ;
- Layer 4 : types/sous-types ;
- Layer 5 : couleur ;
- Layer 6 : capacités ;
- Layer 7 : force/endurance.

Le calcul reste dérivé de l'état et n'écrase pas les valeurs imprimées.

## C9.4 — Combat / SBA / triggers
La régression couvre :
- first strike / double strike ;
- piétinement ;
- prévention pendant le combat ;
- remplacement Ali sur les dégâts de combat ;
- SBA après les étapes de blessures ;
- mort des créatures et émission de l'événement `creatureDied` ;
- cycle de nettoyage des effets temporaires.

## Audit final de la base
- Entrées : **667**
- Noms uniques : **600**
- Annotations « non simulé » restantes : **0**
- Ali from Cairo : **ID 359**
- Shahrazad : **ID 419**

### Important : structurel ≠ conformité exhaustive
Les 667 cartes disposent d'une définition/route runtime identifiable. Cela ne constitue pas une preuve que chaque carte est conforme à toutes les interactions des Comprehensive Rules.

Les cas particulièrement sensibles restent à couvrir par des tests de scénarios complets :
- Shahrazad : sous-parties récursives et reprise de la partie parente ;
- Ali from Cairo : interactions simultanées de remplacement, prévention et dégâts ;
- effets de remplacement multiples et choix selon APNAP ;
- dépendances entre couches ;
- copies avec effets de copie imbriqués ;
- triggers de changement de zone et regard dans le temps.

Référence règles : les Comprehensive Rules de Wizards décrivent notamment les couches, les effets de remplacement et leur interaction, ainsi que les règles de déclenchement. Le moteur v10.8 couvre maintenant les points d'architecture nécessaires, mais la validation exhaustive de chaque interaction reste une phase de tests de scénarios.
