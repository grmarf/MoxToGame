import json,re
from pathlib import Path
p=Path('src/data/cards-database.js')
s=p.read_text()

# (name, cost, cmc, colors, type, subtype, power, toughness, rarity)
# Lot 7 — LEG #301-310, Wall of Wonder -> Zephyr Falcon (dernier lot, complete
# la couverture Legends a 310/310). Donnees verifiees individuellement via
# Scryfall (cout, type, sous-type, P/T, rarete) avant integration.
entries=[
('Wall of Wonder','{2}{U}{U}',4,['U'],'Creature','Wall',1,5,'uncommon'),
('Whirling Dervish','{G}{G}',2,['G'],'Creature','Human Monk',1,1,'uncommon'),
('White Mana Battery','{4}',4,[],'Artifact',None,None,None,'uncommon'),
('Willow Satyr','{2}{G}{G}',4,['G'],'Creature','Satyr',1,1,'rare'),
('Winds of Change','{R}',1,['R'],'Sorcery',None,None,None,'uncommon'),
('Winter Blast','{X}{G}',1,['G'],'Sorcery',None,None,None,'rare'),
('Wolverine Pack','{2}{G}{G}',4,['G'],'Creature','Wolverine',2,4,'common'),
('Wood Elemental','{3}{G}',4,['G'],'Creature','Elemental',None,None,'rare'),
('Xira Arien','{B}{R}{G}',3,['B','R','G'],'Legendary Creature','Insect Wizard',1,2,'rare'),
('Zephyr Falcon','{1}{U}',2,['U'],'Creature','Bird',1,1,'common'),
]

maxid=max(map(int,re.findall(r'"id":\s*(\d+)',s)))
assert maxid==946, maxid

new=[]
nextid=maxid+1
for name,cost,cmc,colors,typ,sub,pow_,tough,rar in entries:
    obj={"name":name,"cost":cost,"cmc":cmc,"color":colors,"type":typ,"rarity":rar,
         "text_fr":"Carte de l'édition LEG. Effet à implémenter.","id":nextid,"sets":["LEG"],
         "keywords":[],"triggers":[],
         "isLand":typ.endswith('Land'),
         "isCreature":'Creature' in typ,
         "isPermanent":('Creature' in typ or typ.endswith('Land') or 'Enchantment' in typ or typ=='Artifact' or typ=='Artifact Creature'),
         "__c88Applied":True,"effectStatus":"unimplemented"}
    if sub: obj['subtype']=sub
    if pow_ is not None:
        obj['power']=pow_; obj['toughness']=tough
    else:
        if 'Creature' in typ:
            obj['power']='*'; obj['toughness']='*'
    new.append(obj); nextid+=1

block='\n'+',\n'.join(json.dumps(o,ensure_ascii=False,indent=2) for o in new)+'\n'
s=s.replace('\n];\n\nexport default CARDS.map(normalizeCard);',',\n'+block+'\n];\n\nexport default CARDS.map(normalizeCard);')
p.write_text(s)
print('added',len(new),'new, final max id',nextid-1)
