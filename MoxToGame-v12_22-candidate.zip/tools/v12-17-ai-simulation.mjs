import { GameFacade } from '../src/core/game-facade.js';
import { effects } from '../src/core/effect-registry.js';
import { installEffects } from '../src/core/effects/index.js';
import CARDS from '../src/data/cards-database.js';
import { AIService } from '../src/core/ai/ai-service.js';
import { pickAiTarget } from '../src/app/ai-controller.js';
import { rngClock } from '../src/core/rng-clock-service.js';

installEffects(effects, globalThis);
const byName = name => CARDS.find(c => c.name === name);
const spellNames = [
  'Savannah Lions','Grizzly Bears','Lightning Bolt','Giant Growth','Healing Salve',
  'Terror','Shatter','Unsummon','Stone Rain','Psionic Blast','Swords to Plowshares',
  'Howl from Beyond','Fireball','Mind Rot','Blue Elemental Blast','Red Elemental Blast'
];
const spells = spellNames.map(byName).filter(Boolean);
const lands = ['Plains','Island','Swamp','Mountain','Forest'].map(byName).filter(Boolean);
const deck = seed => {
  const out = [];
  for (let i = 0; i < 24; i++) out.push({ ...lands[(i + seed) % lands.length] });
  for (let i = 0; i < 36; i++) out.push({ ...spells[(i + seed) % spells.length] });
  return out;
};

function newGame(gameNo) {
  rngClock.configure({ seed: 121700 + gameNo, useLogicalClock: true });
  const game = new GameFacade();
  game.connect();
  game.engine.loadDeck('player', deck(0), { draw: 7 });
  game.engine.loadDeck('ai', deck(3), { draw: 7 });
  game.turnManager.activePlayer = 'player';
  game.turnManager.gotoPhase('untap');
  game.state.activePlayer = 'player';
  game.state.phase = 'untap';
  game.state.priorityHolder = null;
  return game;
}

function validate(game) {
  if (!(game.state.priorityHolder === null &&
        (['untap', 'cleanup'].includes(game.turnManager.phase) || game.state.player.hasLost || game.state.ai.hasLost))) {
    game.engine.validateState();
  }
  for (const side of ['player', 'ai']) {
    const ids = new Set();
    for (const zone of ['library','hand','battlefield','graveyard','exile']) {
      for (const card of game.state[side][zone]) {
        const id = card.uid || card.objectId;
        if (id) {
          if (ids.has(id)) throw new Error(`duplicate object identity ${side}:${zone}:${id}`);
          ids.add(id);
        }
      }
    }
    for (const permanent of game.state[side].battlefield) {
      if (!permanent.uid) throw new Error(`permanent without uid: ${permanent.name}`);
    }
    if (game.state[side].life < 0 && !game.state[side].hasLost) {
      throw new Error(`negative life without hasLost: ${side}:${game.state[side].life}`);
    }
  }
}

function tapLands(game, side) {
  for (const permanent of [...game.state[side].battlefield]) {
    if (!permanent.tapped && (permanent.produces || permanent.tapAbility?.produces)) {
      game.engine.action('tapMana', { permanent, controller: side });
    }
  }
}

function step(game, ais) {
  const phase = game.turnManager.phase;
  const active = game.turnManager.activePlayer;
  const holder = game.state.priorityHolder;

  if (phase === 'declareBlockers' && holder) {
    const defender = active === 'player' ? 'ai' : 'player';
    if (holder === defender) {
      const move = ais[defender].chooseAction();
      game.dispatch('declareBlockers', { blockers: move?.data?.blockers || {} }, defender);
      game.dispatch('passPriority', {}, defender);
      return true;
    }
    game.dispatch('passPriority', {}, holder);
    return true;
  }

  if (!['untap','cleanup'].includes(phase) && holder === active) {
    if (phase === 'main1' || phase === 'main2') {
      tapLands(game, active);
      const move = ais[active].chooseAction();
      if (move?.action === 'playLand') {
        game.dispatch('action', { action:'playLand', data:{ card:move.data.card, controller:active } }, active);
        return true;
      }
      if (move?.action === 'castSpell') {
        const target = pickAiTarget(game, move.data.card);
        game.dispatch('castSpell', { card:move.data.card, target }, active);
        return true;
      }
    }
    if (phase === 'declareAttackers') {
      const move = ais[active].chooseAction();
      game.dispatch('declareAttackers', { attackers: move?.data?.attackers || [] }, active);
      game.dispatch('passPriority', {}, active);
      return true;
    }
    game.dispatch('passPriority', {}, active);
    return true;
  }

  if (holder && holder !== active) {
    const response = game.stack?.size ? ais[holder].chooseResponse() : null;
    if (response?.action === 'castCounter') {
      const target = response.data.target || game.stack.top;
      game.dispatch('castSpell', { card:response.data.card, target }, holder);
      return true;
    }
    game.dispatch('passPriority', {}, holder);
    return true;
  }

  if (['untap','cleanup'].includes(phase)) {
    game.turnManager.runPhase();
    return true;
  }
  return false;
}

const results = [];
const total = 10;
for (let gameNo = 1; gameNo <= total; gameNo++) {
  const game = newGame(gameNo);
  const ais = {
    player: new AIService({ state:()=>game.state, turnManager:game.turnManager, combat:game.combat, stack:game.stack, effects, costs:game.costs, side:'player' }),
    ai: new AIService({ state:()=>game.state, turnManager:game.turnManager, combat:game.combat, stack:game.stack, effects, costs:game.costs, side:'ai' }),
  };
  let steps = 0;
  try {
    while (!game.state.player.hasLost && !game.state.ai.hasLost && steps < 10000) {
      if (!step(game, ais)) throw new Error('simulation made no progress');
      validate(game);
      steps++;
    }
    if (steps >= 10000) throw new Error('simulation step limit reached');
    results.push({ game:gameNo, status:'ok', turns:game.turnManager.turnNumber, steps, winner:game.state.player.hasLost ? 'ai' : 'player' });
  } catch (error) {
    results.push({ game:gameNo, status:'error', turns:game.turnManager.turnNumber, steps, error:error.stack });
  }
}
console.log(JSON.stringify({total, results, summary:{completed:results.filter(r=>r.status==='ok').length, failed:results.filter(r=>r.status==='error').length}}, null, 2));
